using System;
using System.Globalization;
using System.Windows.Forms;
using LibExample;

namespace LabWinForms;

public partial class MainForm : Form
{
    public MainForm()
    {
        InitializeComponent();
    }

    private double ReadDouble(TextBox textBox, string fieldName)
    {
        var text = textBox.Text.Trim();

        if (double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) ||
            double.TryParse(text, NumberStyles.Float, CultureInfo.CurrentCulture, out value))
        {
            return value;
        }

        throw new FormatException($"Некорректное число в поле \"{fieldName}\".");
    }

    private void ShowError(Exception ex)
    {
        MessageBox.Show(this, ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

    private void btnSum_Click(object sender, EventArgs e)
    {
        try
        {
            var a = ReadDouble(txtFirst, "Первое число");
            var b = ReadDouble(txtSecond, "Второе число");
            lblResult.Text = $"Сумма: {Calculator.Add(a, b)}";
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }

    private void btnDifference_Click(object sender, EventArgs e)
    {
        try
        {
            var a = ReadDouble(txtFirst, "Первое число");
            var b = ReadDouble(txtSecond, "Второе число");
            lblResult.Text = $"Разность: {Calculator.Subtract(a, b)}";
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }

    private void btnProduct_Click(object sender, EventArgs e)
    {
        try
        {
            var a = ReadDouble(txtFirst, "Первое число");
            var b = ReadDouble(txtSecond, "Второе число");
            lblResult.Text = $"Произведение: {Calculator.Multiply(a, b)}";
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }

    private void btnQuotient_Click(object sender, EventArgs e)
    {
        try
        {
            var a = ReadDouble(txtFirst, "Первое число");
            var b = ReadDouble(txtSecond, "Второе число");
            lblResult.Text = $"Частное: {Calculator.Divide(a, b)}";
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }

    private void btnPower_Click(object sender, EventArgs e)
    {
        try
        {
            var a = ReadDouble(txtFirst, "Первое число");
            var b = ReadDouble(txtSecond, "Второе число");
            lblResult.Text = $"Степень: {Calculator.Power(a, b)}";
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }

    private void btnHypotenuse_Click(object sender, EventArgs e)
    {
        try
        {
            var a = ReadDouble(txtFirst, "Первое число (катет)");
            var b = ReadDouble(txtSecond, "Второе число (катет)");
            lblResult.Text = $"Гипотенуза: {Calculator.Hypotenuse(a, b)}";
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }

    private void btnAngleFirst_Click(object sender, EventArgs e)
    {
        try
        {
            var a = ReadDouble(txtFirst, "Первый катет");
            var b = ReadDouble(txtSecond, "Второй катет");
            var angle = Calculator.AngleAdjacentToFirst(a, b);
            lblResult.Text = $"Угол при первом катете: {angle:F4}°";
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }

    private void btnAngleSecond_Click(object sender, EventArgs e)
    {
        try
        {
            var a = ReadDouble(txtFirst, "Первый катет");
            var b = ReadDouble(txtSecond, "Второй катет");
            var angle = Calculator.AngleAdjacentToSecond(a, b);
            lblResult.Text = $"Угол при втором катете: {angle:F4}°";
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }
}

