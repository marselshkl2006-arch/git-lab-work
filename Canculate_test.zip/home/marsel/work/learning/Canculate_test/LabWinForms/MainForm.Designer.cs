using System.Windows.Forms;

namespace LabWinForms;

partial class MainForm
{
    private Label lblFirst;
    private Label lblSecond;
    private TextBox txtFirst;
    private TextBox txtSecond;
    private Button btnSum;
    private Button btnDifference;
    private Button btnProduct;
    private Button btnQuotient;
    private Button btnPower;
    private Button btnHypotenuse;
    private Button btnAngleFirst;
    private Button btnAngleSecond;
    private Label lblResultCaption;
    private Label lblResult;

    private void InitializeComponent()
    {
        lblFirst = new Label();
        lblSecond = new Label();
        txtFirst = new TextBox();
        txtSecond = new TextBox();
        btnSum = new Button();
        btnDifference = new Button();
        btnProduct = new Button();
        btnQuotient = new Button();
        btnPower = new Button();
        btnHypotenuse = new Button();
        btnAngleFirst = new Button();
        btnAngleSecond = new Button();
        lblResultCaption = new Label();
        lblResult = new Label();
        SuspendLayout();
        // 
        // lblFirst
        // 
        lblFirst.AutoSize = true;
        lblFirst.Location = new System.Drawing.Point(12, 15);
        lblFirst.Name = "lblFirst";
        lblFirst.Size = new System.Drawing.Size(84, 15);
        lblFirst.TabIndex = 0;
        lblFirst.Text = "Первое число:";
        // 
        // lblSecond
        // 
        lblSecond.AutoSize = true;
        lblSecond.Location = new System.Drawing.Point(12, 47);
        lblSecond.Name = "lblSecond";
        lblSecond.Size = new System.Drawing.Size(90, 15);
        lblSecond.TabIndex = 1;
        lblSecond.Text = "Второе число:";
        // 
        // txtFirst
        // 
        txtFirst.Location = new System.Drawing.Point(120, 12);
        txtFirst.Name = "txtFirst";
        txtFirst.Size = new System.Drawing.Size(150, 23);
        txtFirst.TabIndex = 2;
        // 
        // txtSecond
        // 
        txtSecond.Location = new System.Drawing.Point(120, 44);
        txtSecond.Name = "txtSecond";
        txtSecond.Size = new System.Drawing.Size(150, 23);
        txtSecond.TabIndex = 3;
        // 
        // btnSum
        // 
        btnSum.Location = new System.Drawing.Point(12, 85);
        btnSum.Name = "btnSum";
        btnSum.Size = new System.Drawing.Size(120, 30);
        btnSum.TabIndex = 4;
        btnSum.Text = "1) Сумма";
        btnSum.UseVisualStyleBackColor = true;
        btnSum.Click += btnSum_Click;
        // 
        // btnDifference
        // 
        btnDifference.Location = new System.Drawing.Point(150, 85);
        btnDifference.Name = "btnDifference";
        btnDifference.Size = new System.Drawing.Size(120, 30);
        btnDifference.TabIndex = 5;
        btnDifference.Text = "2) Разность";
        btnDifference.UseVisualStyleBackColor = true;
        btnDifference.Click += btnDifference_Click;
        // 
        // btnProduct
        // 
        btnProduct.Location = new System.Drawing.Point(12, 121);
        btnProduct.Name = "btnProduct";
        btnProduct.Size = new System.Drawing.Size(120, 30);
        btnProduct.TabIndex = 6;
        btnProduct.Text = "3) Произведение";
        btnProduct.UseVisualStyleBackColor = true;
        btnProduct.Click += btnProduct_Click;
        // 
        // btnQuotient
        // 
        btnQuotient.Location = new System.Drawing.Point(150, 121);
        btnQuotient.Name = "btnQuotient";
        btnQuotient.Size = new System.Drawing.Size(120, 30);
        btnQuotient.TabIndex = 7;
        btnQuotient.Text = "4) Деление";
        btnQuotient.UseVisualStyleBackColor = true;
        btnQuotient.Click += btnQuotient_Click;
        // 
        // btnPower
        // 
        btnPower.Location = new System.Drawing.Point(12, 157);
        btnPower.Name = "btnPower";
        btnPower.Size = new System.Drawing.Size(120, 30);
        btnPower.TabIndex = 8;
        btnPower.Text = "5) Степень";
        btnPower.UseVisualStyleBackColor = true;
        btnPower.Click += btnPower_Click;
        // 
        // btnHypotenuse
        // 
        btnHypotenuse.Location = new System.Drawing.Point(150, 157);
        btnHypotenuse.Name = "btnHypotenuse";
        btnHypotenuse.Size = new System.Drawing.Size(120, 30);
        btnHypotenuse.TabIndex = 9;
        btnHypotenuse.Text = "6) Гипотенуза";
        btnHypotenuse.UseVisualStyleBackColor = true;
        btnHypotenuse.Click += btnHypotenuse_Click;
        // 
        // btnAngleFirst
        // 
        btnAngleFirst.Location = new System.Drawing.Point(12, 193);
        btnAngleFirst.Name = "btnAngleFirst";
        btnAngleFirst.Size = new System.Drawing.Size(258, 30);
        btnAngleFirst.TabIndex = 10;
        btnAngleFirst.Text = "7) Угол при первом катете";
        btnAngleFirst.UseVisualStyleBackColor = true;
        btnAngleFirst.Click += btnAngleFirst_Click;
        // 
        // btnAngleSecond
        // 
        btnAngleSecond.Location = new System.Drawing.Point(12, 229);
        btnAngleSecond.Name = "btnAngleSecond";
        btnAngleSecond.Size = new System.Drawing.Size(258, 30);
        btnAngleSecond.TabIndex = 11;
        btnAngleSecond.Text = "8) Угол при втором катете";
        btnAngleSecond.UseVisualStyleBackColor = true;
        btnAngleSecond.Click += btnAngleSecond_Click;
        // 
        // lblResultCaption
        // 
        lblResultCaption.AutoSize = true;
        lblResultCaption.Location = new System.Drawing.Point(12, 275);
        lblResultCaption.Name = "lblResultCaption";
        lblResultCaption.Size = new System.Drawing.Size(67, 15);
        lblResultCaption.TabIndex = 12;
        lblResultCaption.Text = "Результат:";
        // 
        // lblResult
        // 
        lblResult.AutoSize = true;
        lblResult.Location = new System.Drawing.Point(85, 275);
        lblResult.Name = "lblResult";
        lblResult.Size = new System.Drawing.Size(12, 15);
        lblResult.TabIndex = 13;
        lblResult.Text = "-";
        // 
        // MainForm
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(284, 311);
        Controls.Add(lblResult);
        Controls.Add(lblResultCaption);
        Controls.Add(btnAngleSecond);
        Controls.Add(btnAngleFirst);
        Controls.Add(btnHypotenuse);
        Controls.Add(btnPower);
        Controls.Add(btnQuotient);
        Controls.Add(btnProduct);
        Controls.Add(btnDifference);
        Controls.Add(btnSum);
        Controls.Add(txtSecond);
        Controls.Add(txtFirst);
        Controls.Add(lblSecond);
        Controls.Add(lblFirst);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        Name = "MainForm";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "ЛР1 – Вычисления";
        ResumeLayout(false);
        PerformLayout();
    }
}

