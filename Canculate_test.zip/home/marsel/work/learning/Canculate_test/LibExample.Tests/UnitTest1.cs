using NUnit.Framework;

namespace LibExample.Tests;

[TestFixture]
public class CalculatorTests
{
    [TestCase(1, 2, 3)]
    [TestCase(-1, 2, 1)]
    [TestCase(1.5, 2.5, 4.0)]
    public void Add_ReturnsExpected(double first, double second, double expected)
    {
        var result = Calculator.Add(first, second);
        Assert.That(result, Is.EqualTo(expected).Within(1e-9));
    }

    [TestCase(5, 3, 2)]
    [TestCase(0, 2, -2)]
    [TestCase(2.5, 1.5, 1.0)]
    public void Subtract_ReturnsExpected(double first, double second, double expected)
    {
        var result = Calculator.Subtract(first, second);
        Assert.That(result, Is.EqualTo(expected).Within(1e-9));
    }

    [TestCase(2, 3, 6)]
    [TestCase(-2, 3, -6)]
    [TestCase(1.5, 2, 3.0)]
    public void Multiply_ReturnsExpected(double first, double second, double expected)
    {
        var result = Calculator.Multiply(first, second);
        Assert.That(result, Is.EqualTo(expected).Within(1e-9));
    }

    [TestCase(6, 3, 2)]
    [TestCase(-6, 3, -2)]
    [TestCase(1.5, 0.5, 3.0)]
    public void Divide_ReturnsExpected(double dividend, double divisor, double expected)
    {
        var result = Calculator.Divide(dividend, divisor);
        Assert.That(result, Is.EqualTo(expected).Within(1e-9));
    }

    [Test]
    public void Divide_ByZero_Throws()
    {
        Assert.Throws<DivideByZeroException>(() => Calculator.Divide(1, 0));
    }

    [TestCase(2, 3, 8)]
    [TestCase(4, 0.5, 2)]
    [TestCase(9, 0.5, 3)]
    public void Power_ReturnsExpected(double @base, double exponent, double expected)
    {
        var result = Calculator.Power(@base, exponent);
        Assert.That(result, Is.EqualTo(expected).Within(1e-9));
    }

    [TestCase(3, 4, 5)]
    [TestCase(5, 12, 13)]
    public void Hypotenuse_ReturnsExpected(double firstCathetus, double secondCathetus, double expected)
    {
        var result = Calculator.Hypotenuse(firstCathetus, secondCathetus);
        Assert.That(result, Is.EqualTo(expected).Within(1e-9));
    }

    [Test]
    public void Hypotenuse_NegativeCathetus_Throws()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => Calculator.Hypotenuse(-3, 4));
    }

    [TestCase(3, 4)]
    [TestCase(5, 12)]
    public void Angles_SumIsRightAngle(double firstCathetus, double secondCathetus)
    {
        var angle1 = Calculator.AngleAdjacentToFirst(firstCathetus, secondCathetus);
        var angle2 = Calculator.AngleAdjacentToSecond(firstCathetus, secondCathetus);

        Assert.That(angle1 + angle2, Is.EqualTo(90).Within(1e-9));
    }

    [Test]
    public void Angles_NonPositiveCatheti_Throw()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => Calculator.AngleAdjacentToFirst(0, 4));
        Assert.Throws<ArgumentOutOfRangeException>(() => Calculator.AngleAdjacentToSecond(3, 0));
    }
}