using System.Globalization;
using LibExample;

Console.OutputEncoding = System.Text.Encoding.UTF8;

while (true)
{
    Console.WriteLine("Лабораторная работа №1 – вычислительный модуль");
    Console.WriteLine("Введите два вещественных числа (катеты прямоугольного треугольника):");

    var first = ReadDouble("Первое число: ");
    var second = ReadDouble("Второе число: ");

    Console.WriteLine();
    Console.WriteLine("Выберите операцию:");
    Console.WriteLine("1 – сумма чисел");
    Console.WriteLine("2 – разность чисел (первое минус второе)");
    Console.WriteLine("3 – произведение чисел");
    Console.WriteLine("4 – деление первого числа на второе");
    Console.WriteLine("5 – первое число в степени второго");
    Console.WriteLine("6 – длина гипотенузы");
    Console.WriteLine("7 – угол (в градусах), прилежащий к первому катету");
    Console.WriteLine("8 – угол (в градусах), прилежащий ко второму катету");
    Console.WriteLine("0 – выход");
    Console.Write("Ваш выбор: ");

    var choice = Console.ReadLine();
    Console.WriteLine();

    if (choice == "0")
    {
        break;
    }

    try
    {
        switch (choice)
        {
            case "1":
                Console.WriteLine($"Сумма: {Calculator.Add(first, second)}");
                break;
            case "2":
                Console.WriteLine($"Разность: {Calculator.Subtract(first, second)}");
                break;
            case "3":
                Console.WriteLine($"Произведение: {Calculator.Multiply(first, second)}");
                break;
            case "4":
                Console.WriteLine($"Частное: {Calculator.Divide(first, second)}");
                break;
            case "5":
                Console.WriteLine($"Степень: {Calculator.Power(first, second)}");
                break;
            case "6":
                Console.WriteLine($"Гипотенуза: {Calculator.Hypotenuse(first, second)}");
                break;
            case "7":
                Console.WriteLine($"Угол при первом катете: {Calculator.AngleAdjacentToFirst(first, second)}°");
                break;
            case "8":
                Console.WriteLine($"Угол при втором катете: {Calculator.AngleAdjacentToSecond(first, second)}°");
                break;
            default:
                Console.WriteLine("Неизвестная команда. Повторите ввод.");
                break;
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Ошибка вычисления: {ex.Message}");
    }

    Console.WriteLine();
    Console.WriteLine("Нажмите Enter, чтобы продолжить, или введите 0 и Enter для выхода.");
    var exit = Console.ReadLine();
    if (exit == "0")
    {
        break;
    }

    Console.Clear();
}

static double ReadDouble(string prompt)
{
    while (true)
    {
        Console.Write(prompt);
        var input = Console.ReadLine();

        if (double.TryParse(input, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) ||
            double.TryParse(input, NumberStyles.Float, CultureInfo.CurrentCulture, out value))
        {
            return value;
        }

        Console.WriteLine("Некорректный ввод. Попробуйте ещё раз.");
    }
}
