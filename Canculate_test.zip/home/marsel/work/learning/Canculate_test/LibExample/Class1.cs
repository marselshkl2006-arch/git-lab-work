namespace LibExample;

public static class Calculator
{
    public static double Add(double first, double second) => first + second;

    public static double Subtract(double first, double second) => first - second;

    public static double Multiply(double first, double second) => first * second;

    public static double Divide(double dividend, double divisor)
    {
        if (divisor == 0)
        {
            throw new DivideByZeroException("Деление на ноль недопустимо.");
        }

        return dividend / divisor;
    }

    public static double Power(double @base, double exponent) => Math.Pow(@base, exponent);

    public static double Hypotenuse(double firstCathetus, double secondCathetus)
    {
        if (firstCathetus < 0 || secondCathetus < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(firstCathetus),
                "Длины катетов должны быть неотрицательными.");
        }

        return Math.Sqrt(firstCathetus * firstCathetus + secondCathetus * secondCathetus);
    }

    private static double RadiansToDegrees(double radians) => radians * 180.0 / Math.PI;

    /// <summary>
    /// Возвращает величину угла (в градусах) прямоугольного треугольника,
    /// прилежащего к катету, длина которого задана первым числом.
    /// </summary>
    public static double AngleAdjacentToFirst(double firstCathetus, double secondCathetus)
    {
        if (firstCathetus <= 0 || secondCathetus <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(firstCathetus),
                "Длины катетов должны быть положительными.");
        }

        // Тангенс угла при первом катете: противолежащий / прилежащий = second / first
        var radians = Math.Atan2(secondCathetus, firstCathetus);
        return RadiansToDegrees(radians);
    }

    /// <summary>
    /// Возвращает величину угла (в градусах) прямоугольного треугольника,
    /// прилежащего к катету, длина которого задана вторым числом.
    /// </summary>
    public static double AngleAdjacentToSecond(double firstCathetus, double secondCathetus)
    {
        if (firstCathetus <= 0 || secondCathetus <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(secondCathetus),
                "Длины катетов должны быть положительными.");
        }

        // Тангенс угла при втором катете: противолежащий / прилежащий = first / second
        var radians = Math.Atan2(firstCathetus, secondCathetus);
        return RadiansToDegrees(radians);
    }
}
