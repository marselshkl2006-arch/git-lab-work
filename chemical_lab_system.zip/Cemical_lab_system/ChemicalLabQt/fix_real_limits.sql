-- 1. ПЕРВОЕ: УДАЛЯЕМ ВСЕ НЕПРАВИЛЬНЫЕ ДАННЫЕ КОТОРЫЕ ВЫЗЫВАЮТ ПЕРЕГРУЗКУ
DELETE FROM batches WHERE quantity > 1000;
DELETE FROM chemicals WHERE danger_class > 5;

-- 2. ВТОРОЕ: УСТАНАВЛИВАЕМ РЕАЛЬНЫЕ ЛИМИТЫ
UPDATE storage_zones SET 
    max_capacity = CASE 
        WHEN id = 1 THEN 10000   -- Холодное хранение
        WHEN id = 2 THEN 5000    -- Сухое хранение
        WHEN id = 3 THEN 2000    -- Огнеопасные
        WHEN id = 4 THEN 1000    -- Токсичные
        WHEN id = 5 THEN 500     -- Радиоактивные
        ELSE max_capacity
    END;

-- 3. ТРЕТЬЕ: ПЕРЕСЧИТЫВАЕМ ТЕКУЩУЮ ЗАГРУЗКУ ПРАВИЛЬНО
UPDATE storage_zones SET current_load = 0;

WITH zone_loads AS (
    SELECT 
        b.zone_id,
        SUM(b.quantity) as total_quantity
    FROM batches b
    GROUP BY b.zone_id
)
UPDATE storage_zones
SET current_load = (
    SELECT COALESCE(zl.total_quantity, 0)
    FROM zone_loads zl
    WHERE zl.zone_id = storage_zones.id
);

-- 4. ЧЕТВЕРТОЕ: ПРОВЕРЯЕМ ЧТО ВСЁ КОРРЕКТНО
SELECT '=== ФИНАЛЬНАЯ ПРОВЕРКА ===' as "";
SELECT 
    id,
    name,
    current_load,
    max_capacity,
    CASE 
        WHEN current_load > max_capacity THEN '❌ ПЕРЕГРУЗКА'
        WHEN current_load = max_capacity THEN '⚠ НА ГРАНИ'
        ELSE '✅ НОРМА'
    END as status,
    printf('%.1f%%', (current_load * 100.0 / max_capacity)) as usage_percent
FROM storage_zones;

SELECT '';
SELECT '=== ИНФОРМАЦИЯ О БАЗЕ ===' as "";
SELECT 'Всего химикатов: ' || COUNT(*) FROM chemicals;
SELECT 'Всего размещений: ' || COUNT(*) FROM batches;
SELECT 'Размер БД: ' || page_count * page_size || ' байт' 
FROM pragma_page_count(), pragma_page_size();
