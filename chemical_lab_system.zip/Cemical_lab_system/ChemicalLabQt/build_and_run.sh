#!/bin/bash
echo "🧪 ХИМИЧЕСКАЯ ЛАБОРАТОРИЯ - СИСТЕМА СБОРКИ"
echo "========================================"

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Функция вывода с цветом
print_status() {
    echo -e "${BLUE}[$1]${NC} $2"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Проверка зависимостей
print_status "CHECK" "Проверка зависимостей..."

check_dep() {
    if command -v $1 &> /dev/null; then
        echo "  ✅ $1: $(($1 --version 2>/dev/null | head -1) || echo "установлен")"
        return 0
    else
        echo "  ❌ $1: не найден"
        return 1
    fi
}

check_dep cmake
check_dep g++
check_dep make
check_dep qmake6 || check_dep qmake

# Создание директории сборки
print_status "PREPARE" "Подготовка директории сборки..."
mkdir -p build
cd build

# Очистка предыдущей сборки
print_status "CLEAN" "Очистка предыдущей сборки..."
rm -rf *

# Конфигурация
print_status "CONFIGURE" "Конфигурация проекта..."
cmake .. -DCMAKE_BUILD_TYPE=Release

if [ $? -ne 0 ]; then
    print_error "Ошибка конфигурации!"
    exit 1
fi

# Компиляция
print_status "BUILD" "Компиляция проекта..."
CPU_CORES=$(nproc)
print_status "INFO" "Используется ядер: $CPU_CORES"
make -j${CPU_CORES}

if [ $? -ne 0 ]; then
    print_error "Ошибка компиляции!"
    exit 1
fi

# Проверка результата
if [ -f "ChemicalLabQt" ]; then
    echo ""
    print_success "СБОРКА УСПЕШНО ЗАВЕРШЕНА!"
    echo ""
    echo "📊 ИНФОРМАЦИЯ:"
    echo "  • Имя файла: ChemicalLabQt"
    echo "  • Размер: $(du -h ChemicalLabQt | cut -f1)"
    echo "  • Тип: $(file ChemicalLabQt | cut -d: -f2-)"
    echo ""
    
    # Запуск если указан флаг
    if [ "$1" = "run" ]; then
        print_status "RUN" "Запуск программы..."
        echo ""
        ./ChemicalLabQt
    else
        echo "🚀 ДЛЯ ЗАПУСКА:"
        echo "  ./build_and_run.sh run"
        echo "  или"
        echo "  cd build && ./ChemicalLabQt"
    fi
else
    print_error "Исполняемый файл не создан!"
    exit 1
fi
