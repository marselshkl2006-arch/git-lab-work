#!/bin/bash
FILE="mainwindow.cpp"

# 1. Добавляем include в начало файла
sed -i '1s/^/#include "settingsdialog.h"\n#include "thememanager.h"\n/' "$FILE"

# 2. Находим метод backupDatabase и заменяем его
sed -i '/void MainWindow::backupDatabase()/,/^}$/c\
void MainWindow::backupDatabase()\
{\
    if (!db) return;\
    \
    BackupDialog dialog(this, db, false);\
    dialog.exec();\
}' "$FILE"

# 3. Находим метод importFromCSV и заменяем его
# Сначала найдем начало и конец метода
START=$(grep -n "void MainWindow::importFromCSV()" "$FILE" | cut -d: -f1)
if [ ! -z "$START" ]; then
    # Найдем следующий метод после importFromCSV
    NEXT_METHOD=$(awk -v start="$START" 'NR > start && /void MainWindow::/ {print NR; exit}' "$FILE")
    
    if [ ! -z "$NEXT_METHOD" ]; then
        # Удаляем старый метод и вставляем новый
        sed -i "${START},$((NEXT_METHOD-1))d" "$FILE"
        sed -i "${START}i\\
void MainWindow::importFromCSV()\\
{\\
    if (!db) return;\\
    \\
    QString fileName = QFileDialog::getOpenFileName(\\
        this, \"Импорт данных из CSV\",\\
        QDir::homePath(),\\
        \"CSV файлы (*.csv);;Все файлы (*.*)\");\\
    \\
    if (fileName.isEmpty()) return;\\
    \\
    // Простая реализация импорта\\
    QFile file(fileName);\\
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {\\
        showError(\"Не удалось открыть файл: \" + file.errorString());\\
        return;\\
    }\\
    \\
    QTextStream in(&file);\\
    QString header = in.readLine(); // Пропускаем заголовок\\
    \\
    int importedCount = 0;\\
    while (!in.atEnd()) {\\
        QString line = in.readLine();\\
        QStringList fields = line.split(',');\\
        \\
        if (fields.size() >= 2) {\\
            QMap<QString, QVariant> data;\\
            data[\"name\"] = fields[0].trimmed();\\
            data[\"quantity\"] = fields.size() > 1 ? fields[1].toDouble() : 0.0;\\
            data[\"unit\"] = \"г\";\\
            data[\"hazard_class\"] = 3;\\
            \\
            if (db->addChemical(data)) {\\
                importedCount++;\\
            }\\
        }\\
    }\\
    \\
    file.close();\\
    \\
    if (importedCount > 0) {\\
        updateStatus(QString(\"Импортировано %1 записей из CSV\").arg(importedCount), 3000);\\
    }\\
}" "$FILE"
    fi
fi

# 4. Находим метод showSettings и заменяем его
sed -i '/void MainWindow::showSettings()/,/^}$/c\
void MainWindow::showSettings()\
{\
    if (!db) return;\
    \
    SettingsDialog dialog(this, db);\
    dialog.exec();\
}' "$FILE"

echo "Файл $FILE отредактирован"
