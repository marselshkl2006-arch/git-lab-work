void MainWindow::createStatusBar()
{
    QStatusBar *statusBarWidget = QMainWindow::statusBar();
    
    statusLabel = new QLabel("Готов");
    statusBarWidget->addWidget(statusLabel);
    
    progressBar = new QProgressBar();
    progressBar->setMaximumWidth(200);
    progressBar->setVisible(false);
    statusBarWidget->addWidget(progressBar);
    
    QLabel *dbStatus = new QLabel("🟢 База данных подключена");
    statusBarWidget->addPermanentWidget(dbStatus);
}

void MainWindow::updateStatus(const QString &message, int timeout)
{
    QStatusBar *statusBarWidget = QMainWindow::statusBar();
    
    if (statusLabel) {
        statusLabel->setText(message);
    }
    if (timeout > 0) {
        statusBarWidget->showMessage(message, timeout);
    }
}
