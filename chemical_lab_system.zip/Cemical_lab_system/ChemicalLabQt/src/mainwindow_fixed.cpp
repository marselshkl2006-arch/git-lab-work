#include "mainwindow.h"
#include "database.h"
#include <QApplication>
#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QMessageBox>
#include <QStatusBar>
#include <QToolBar>
#include <QTableWidget>
#include <QTabWidget>
#include <QHeaderView>
#include <QLineEdit>
#include <QComboBox>
#include <iostream>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), db(nullptr) {
    std::cout << "MainWindow constructor started" << std::endl;
    
    setWindowTitle("Химическая Лаборатория v2.1");
    resize(1200, 800);
    
    try {
        std::cout << "Getting database instance..." << std::endl;
        db = &Database::instance();
        
        std::cout << "Initializing database..." << std::endl;
        if (!db->initializeDatabase()) {
            std::cerr << "Database initialization failed!" << std::endl;
            QMessageBox::critical(this, "Ошибка", "Не удалось инициализировать базу данных!");
            return;
        }
        
        std::cout << "Database initialized successfully" << std::endl;
        
    } catch (const std::exception &e) {
        std::cerr << "Exception in MainWindow: " << e.what() << std::endl;
        QMessageBox::critical(this, "Ошибка", QString("Исключение: %1").arg(e.what()));
        return;
    }
    
    // Создаем интерфейс
    createMenu();
    createToolBar();
    createCentralWidget();
    createStatusBar();
    
    std::cout << "MainWindow created successfully" << std::endl;
}

MainWindow::~MainWindow() {
    std::cout << "MainWindow destroyed" << std::endl;
}

void MainWindow::createMenu() {
    // Меню Файл
    QMenu *fileMenu = menuBar()->addMenu("📁 Файл");
    
    QAction *newChemicalAction = fileMenu->addAction("➕ Новый химикат");
    newChemicalAction->setShortcut(QKeySequence::New);
    connect(newChemicalAction, &QAction::triggered, this, &MainWindow::addChemical);
    
    fileMenu->addSeparator();
    
    QAction *exportAction = fileMenu->addAction("📤 Экспорт в CSV");
    exportAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_E));
    connect(exportAction, &QAction::triggered, this, &MainWindow::exportToCSV);
    
    fileMenu->addSeparator();
    
    QAction *backupAction = fileMenu->addAction("💾 Создать резервную копию");
    backupAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_B));
    connect(backupAction, &QAction::triggered, this, &MainWindow::backupDatabase);
    
    fileMenu->addSeparator();
    
    QAction *exitAction = fileMenu->addAction("🚪 Выход");
    exitAction->setShortcut(QKeySequence::Quit);
    connect(exitAction, &QAction::triggered, this, &MainWindow::quitApplication);
    
    // Меню Редактирование
    QMenu *editMenu = menuBar()->addMenu("✏️ Редактирование");
    
    QAction *editChemicalAction = editMenu->addAction("✏️ Редактировать химикат");
    editChemicalAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_E));
    connect(editChemicalAction, &QAction::triggered, this, &MainWindow::editChemical);
    
    QAction *deleteChemicalAction = editMenu->addAction("🗑️ Удалить химикат");
    deleteChemicalAction->setShortcut(QKeySequence::Delete);
    connect(deleteChemicalAction, &QAction::triggered, this, &MainWindow::deleteChemical);
    
    editMenu->addSeparator();
    
    QAction *addZoneAction = editMenu->addAction("🏗️ Добавить зону хранения");
    connect(addZoneAction, &QAction::triggered, this, &MainWindow::addStorageZone);
    
    QAction *editZoneAction = editMenu->addAction("⚙️ Редактировать зону");
    connect(editZoneAction, &QAction::triggered, this, &MainWindow::editStorageZone);
    
    QAction *deleteZoneAction = editMenu->addAction("❌ Удалить зону");
    connect(deleteZoneAction, &QAction::triggered, this, &MainWindow::deleteStorageZone);
    
    editMenu->addSeparator();
    
    QAction *distributeAction = editMenu->addAction("📦 Распределить по зонам");
    distributeAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_D));
    connect(distributeAction, &QAction::triggered, this, &MainWindow::distributeChemicalToZone);
    
    // Меню Вид
    QMenu *viewMenu = menuBar()->addMenu("👁️ Вид");
    
    QAction *refreshAction = viewMenu->addAction("🔄 Обновить");
    refreshAction->setShortcut(QKeySequence::Refresh);
    connect(refreshAction, &QAction::triggered, this, &MainWindow::refreshAll);
    
    viewMenu->addSeparator();
    
    QAction *showChemicalsAction = viewMenu->addAction("🧪 Химикаты");
    showChemicalsAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_1));
    connect(showChemicalsAction, &QAction::triggered, this, &MainWindow::showChemicals);
    
    QAction *showZonesAction = viewMenu->addAction("🏢 Зоны хранения");
    showZonesAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_2));
    connect(showZonesAction, &QAction::triggered, this, &MainWindow::showStorageZones);
    
    QAction *showDistributionAction = viewMenu->addAction("📊 Распределение");
    showDistributionAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_3));
    connect(showDistributionAction, &QAction::triggered, this, &MainWindow::showDistribution);
    
    QAction *showStatisticsAction = viewMenu->addAction("📈 Статистика");
    showStatisticsAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_4));
    connect(showStatisticsAction, &QAction::triggered, this, &MainWindow::showStatistics);
    
    QAction *showAlertsAction = viewMenu->addAction("⚠️ Оповещения");
    showAlertsAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_5));
    connect(showAlertsAction, &QAction::triggered, this, &MainWindow::showAlerts);
    
    QAction *showLogAction = viewMenu->addAction("📝 Журнал действий");
    showLogAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_6));
    connect(showLogAction, &QAction::triggered, this, &MainWindow::showActivityLog);
    
    // Меню Справка
    QMenu *helpMenu = menuBar()->addMenu("❓ Справка");
    
    QAction *aboutAction = helpMenu->addAction("ℹ️ О программе");
    connect(aboutAction, &QAction::triggered, this, &MainWindow::showAbout);
}

void MainWindow::createToolBar() {
    QToolBar *toolBar = new QToolBar("Основная панель", this);
    toolBar->setMovable(false);
    toolBar->setIconSize(QSize(24, 24));
    addToolBar(toolBar);
    
    // Кнопка добавления химиката
    QAction *addChemicalAction = toolBar->addAction("➕ Добавить");
    addChemicalAction->setToolTip("Добавить новый химикат (Ctrl+N)");
    addChemicalAction->setShortcut(QKeySequence::New);
    connect(addChemicalAction, &QAction::triggered, this, &MainWindow::addChemical);
    
    // Кнопка редактирования
    QAction *editChemicalAction = toolBar->addAction("✏️ Редактировать");
    editChemicalAction->setToolTip("Редактировать выбранный химикат (Ctrl+E)");
    editChemicalAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_E));
    connect(editChemicalAction, &QAction::triggered, this, &MainWindow::editChemical);
    
    // Кнопка удаления
    QAction *deleteChemicalAction = toolBar->addAction("🗑️ Удалить");
    deleteChemicalAction->setToolTip("Удалить выбранный химикат (Del)");
    deleteChemicalAction->setShortcut(QKeySequence::Delete);
    connect(deleteChemicalAction, &QAction::triggered, this, &MainWindow::deleteChemical);
    
    toolBar->addSeparator();
    
    // Кнопка распределения
    QAction *distributeAction = toolBar->addAction("📦 Распределить");
    distributeAction->setToolTip("Распределить химикат по зонам (Ctrl+D)");
    distributeAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_D));
    connect(distributeAction, &QAction::triggered, this, &MainWindow::distributeChemicalToZone);
    
    toolBar->addSeparator();
    
    // Экспорт
    QAction *exportAction = toolBar->addAction("📤 Экспорт");
    exportAction->setToolTip("Экспорт данных в CSV (Ctrl+Shift+E)");
    exportAction->setShortcut(QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_E));
    connect(exportAction, &QAction::triggered, this, &MainWindow::exportToCSV);
    
    // Резервное копирование
    QAction *backupAction = toolBar->addAction("💾 Бекап");
    backupAction->setToolTip("Создать резервную копию (Ctrl+B)");
    backupAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_B));
    connect(backupAction, &QAction::triggered, this, &MainWindow::backupDatabase);
    
    toolBar->addSeparator();
    
    // Обновление
    QAction *refreshAction = toolBar->addAction("🔄 Обновить");
    refreshAction->setToolTip("Обновить данные (F5)");
    refreshAction->setShortcut(QKeySequence::Refresh);
    connect(refreshAction, &QAction::triggered, this, &MainWindow::refreshAll);
    
    // Поиск
    toolBar->addSeparator();
    toolBar->addWidget(new QLabel(" Поиск: "));
    
    searchChemicalEdit = new QLineEdit();
    searchChemicalEdit->setPlaceholderText("Название, формула, CAS...");
    searchChemicalEdit->setMaximumWidth(300);
    toolBar->addWidget(searchChemicalEdit);
    connect(searchChemicalEdit, &QLineEdit::textChanged, this, &MainWindow::searchChemicals);
    
    // Фильтр по классу опасности
    toolBar->addWidget(new QLabel(" Класс опасности: "));
    
    hazardClassFilter = new QComboBox();
    hazardClassFilter->addItem("Все классы", 0);
    for (int i = 1; i <= 5; i++) {
        hazardClassFilter->addItem(QString("Класс %1").arg(i), i);
    }
    hazardClassFilter->setMaximumWidth(150);
    toolBar->addWidget(hazardClassFilter);
    connect(hazardClassFilter, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::searchChemicals);
}

void MainWindow::createCentralWidget() {
    tabWidget = new QTabWidget(this);
    setCentralWidget(tabWidget);
    
    // Вкладка химикатов
    QWidget *chemicalsTab = new QWidget();
    QVBoxLayout *chemicalsLayout = new QVBoxLayout(chemicalsTab);
    
    chemicalTable = new QTableWidget();
    chemicalTable->setColumnCount(10);
    QStringList chemicalHeaders = {"ID", "Название", "Формула", "CAS", "Производитель", 
                                  "Чистота %", "Количество", "Ед.изм", "Класс опасности", "Срок годности"};
    chemicalTable->setHorizontalHeaderLabels(chemicalHeaders);
    chemicalTable->horizontalHeader()->setStretchLastSection(true);
    chemicalTable->setAlternatingRowColors(true);
    
    chemicalsLayout->addWidget(chemicalTable);
    tabWidget->addTab(chemicalsTab, "🧪 Химикаты");
    
    // Вкладка зон хранения
    QWidget *zonesTab = new QWidget();
    QVBoxLayout *zonesLayout = new QVBoxLayout(zonesTab);
    
    zoneTable = new QTableWidget();
    zoneTable->setColumnCount(8);
    QStringList zoneHeaders = {"ID", "Название", "Описание", "Температура", "Емкость", 
                              "Загрузка", "Загрузка %", "Статус"};
    zoneTable->setHorizontalHeaderLabels(zoneHeaders);
    zoneTable->horizontalHeader()->setStretchLastSection(true);
    zoneTable->setAlternatingRowColors(true);
    
    zonesLayout->addWidget(zoneTable);
    tabWidget->addTab(zonesTab, "🏢 Зоны хранения");
    
    // Вкладка распределения
    QWidget *distributionTab = new QWidget();
    QVBoxLayout *distributionLayout = new QVBoxLayout(distributionTab);
    
    distributionTable = new QTableWidget();
    distributionTable->setColumnCount(6);
    QStringList distributionHeaders = {"ID", "Химикат", "Зона", "Количество", "Дата размещения", "Примечания"};
    distributionTable->setHorizontalHeaderLabels(distributionHeaders);
    distributionTable->horizontalHeader()->setStretchLastSection(true);
    distributionTable->setAlternatingRowColors(true);
    
    distributionLayout->addWidget(distributionTable);
    tabWidget->addTab(distributionTab, "📊 Распределение");
    
    // Вкладка статистики
    QWidget *statsTab = new QWidget();
    QVBoxLayout *statsLayout = new QVBoxLayout(statsTab);
    
    QLabel *statsLabel = new QLabel("📈 СТАТИСТИКА\n\n"
                                   "Общее количество химикатов: 0\n"
                                   "Общее количество зон: 0\n"
                                   "Общая масса химикатов: 0 г\n"
                                   "Средний класс опасности: 0\n"
                                   "Химикатов с истекающим сроком: 0\n"
                                   "Химикатов с низким запасом: 0\n"
                                   "Активных оповещений: 0");
    statsLabel->setAlignment(Qt::AlignCenter);
    statsLabel->setStyleSheet("font-size: 14px; padding: 20px;");
    
    statsLayout->addWidget(statsLabel);
    tabWidget->addTab(statsTab, "📈 Статистика");
    
    // Вкладка оповещений
    QWidget *alertsTab = new QWidget();
    QVBoxLayout *alertsLayout = new QVBoxLayout(alertsTab);
    
    alertsTable = new QTableWidget();
    alertsTable->setColumnCount(4);
    QStringList alertsHeaders = {"Дата", "Тип", "Сообщение", "Важность"};
    alertsTable->setHorizontalHeaderLabels(alertsHeaders);
    alertsTable->horizontalHeader()->setStretchLastSection(true);
    alertsTable->setAlternatingRowColors(true);
    
    alertsLayout->addWidget(alertsTable);
    tabWidget->addTab(alertsTab, "⚠️ Оповещения");
    
    // Вкладка журнала действий
    QWidget *logTab = new QWidget();
    QVBoxLayout *logLayout = new QVBoxLayout(logTab);
    
    activityLogTable = new QTableWidget();
    activityLogTable->setColumnCount(4);
    QStringList logHeaders = {"Время", "Пользователь", "Действие", "Детали"};
    activityLogTable->setHorizontalHeaderLabels(logHeaders);
    activityLogTable->horizontalHeader()->setStretchLastSection(true);
    activityLogTable->setAlternatingRowColors(true);
    
    logLayout->addWidget(activityLogTable);
    tabWidget->addTab(logTab, "📝 Журнал действий");
}

void MainWindow::createStatusBar() {
    QStatusBar *sb = statusBar();
    sb->showMessage("Система готова к работе", 5000);
}

void MainWindow::testDatabase() {
    if (!db) {
        QMessageBox::warning(this, "Ошибка", "База данных не инициализирована");
        return;
    }
    
    try {
        int chemicals = db->getChemicalCount();
        int zones = db->getZoneCount();
        
        std::cout << "Database test:" << std::endl;
        std::cout << "  Chemicals: " << chemicals << std::endl;
        std::cout << "  Zones: " << zones << std::endl;
        std::cout << "  Path: " << db->getDatabasePath().toStdString() << std::endl;
        
        QMessageBox::information(this, "Тест базы данных",
            QString("База данных работает!\n\n"
                   "Химикатов: %1\n"
                   "Зон хранения: %2\n"
                   "Путь: %3")
                   .arg(chemicals)
                   .arg(zones)
                   .arg(db->getDatabasePath()));
        
        QStatusBar *sb = statusBar();
        sb->showMessage(
            QString("База данных: %1 химикатов, %2 зон")
            .arg(chemicals).arg(zones), 3000);
            
    } catch (const std::exception &e) {
        std::cerr << "Database test failed: " << e.what() << std::endl;
        QMessageBox::critical(this, "Ошибка", 
            QString("Ошибка теста базы данных:\n%1").arg(e.what()));
    }
}

void MainWindow::quitApplication() {
    QApplication::quit();
}

void MainWindow::showAbout() { 
    QMessageBox::about(this, "О программе", 
        "Химическая Лаборатория v2.1\n"
        "Система управления химическими реактивами\n\n"
        "Функции:\n"
        "- Управление химикатами\n"
        "- Управление зонами хранения\n"
        "- Распределение по зонам\n"
        "- Резервное копирование\n"
        "- Экспорт отчетов\n\n"
        "© 2024"); 
}

// Реализации остальных методов с исправленным вызовом statusBar()
void MainWindow::refreshAll() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Обновление данных...", 2000); 
    std::cout << "Refreshing all data..." << std::endl;
}

void MainWindow::showChemicals() { 
    if (tabWidget) tabWidget->setCurrentIndex(0); 
    QStatusBar *sb = statusBar();
    sb->showMessage("Просмотр химикатов", 2000);
}

void MainWindow::showStorageZones() { 
    if (tabWidget) tabWidget->setCurrentIndex(1); 
    QStatusBar *sb = statusBar();
    sb->showMessage("Просмотр зон хранения", 2000);
}

void MainWindow::showDistribution() { 
    if (tabWidget) tabWidget->setCurrentIndex(2); 
    QStatusBar *sb = statusBar();
    sb->showMessage("Просмотр распределения", 2000);
}

void MainWindow::showStatistics() { 
    if (tabWidget) tabWidget->setCurrentIndex(3); 
    QStatusBar *sb = statusBar();
    sb->showMessage("Просмотр статистики", 2000);
}

void MainWindow::showAlerts() { 
    if (tabWidget) tabWidget->setCurrentIndex(4); 
    QStatusBar *sb = statusBar();
    sb->showMessage("Просмотр оповещений", 2000);
}

void MainWindow::showActivityLog() { 
    if (tabWidget) tabWidget->setCurrentIndex(5); 
    QStatusBar *sb = statusBar();
    sb->showMessage("Просмотр журнала действий", 2000);
}

void MainWindow::addChemical() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Добавление химиката...", 2000); 
    std::cout << "Adding chemical..." << std::endl;
    QMessageBox::information(this, "Информация", "Функция добавления химиката будет реализована в следующей версии");
}

void MainWindow::editChemical() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Редактирование химиката...", 2000); 
    std::cout << "Editing chemical..." << std::endl;
    QMessageBox::information(this, "Информация", "Функция редактирования химиката будет реализована в следующей версии");
}

void MainWindow::deleteChemical() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Удаление химиката...", 2000); 
    std::cout << "Deleting chemical..." << std::endl;
    QMessageBox::information(this, "Информация", "Функция удаления химиката будет реализована в следующей версии");
}

void MainWindow::searchChemicals() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Поиск химикатов...", 2000); 
    std::cout << "Searching chemicals..." << std::endl;
}

void MainWindow::exportChemicalsToCSV() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Экспорт химикатов в CSV...", 2000); 
    std::cout << "Exporting chemicals to CSV..." << std::endl;
    QMessageBox::information(this, "Информация", "Функция экспорта будет реализована в следующей версии");
}

void MainWindow::addStorageZone() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Добавление зоны хранения...", 2000); 
    std::cout << "Adding storage zone..." << std::endl;
    QMessageBox::information(this, "Информация", "Функция добавления зоны хранения будет реализована в следующей версии");
}

void MainWindow::editStorageZone() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Редактирование зоны...", 2000); 
    std::cout << "Editing storage zone..." << std::endl;
    QMessageBox::information(this, "Информация", "Функция редактирования зоны будет реализована в следующей версии");
}

void MainWindow::deleteStorageZone() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Удаление зоны...", 2000); 
    std::cout << "Deleting storage zone..." << std::endl;
    QMessageBox::information(this, "Информация", "Функция удаления зоны будет реализована в следующей версии");
}

void MainWindow::distributeChemicalToZone() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Распределение по зонам...", 2000); 
    std::cout << "Distributing chemical to zone..." << std::endl;
    QMessageBox::information(this, "Информация", "Функция распределения будет реализована в следующей версии");
}

void MainWindow::backupDatabase() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Создание резервной копии...", 2000); 
    std::cout << "Creating database backup..." << std::endl;
    QMessageBox::information(this, "Информация", "Функция резервного копирования будет реализована в следующей версии");
}

void MainWindow::restoreBackup() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Восстановление из копии...", 2000); 
    std::cout << "Restoring from backup..." << std::endl;
    QMessageBox::information(this, "Информация", "Функция восстановления будет реализована в следующей версии");
}

void MainWindow::showBackupManager() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Управление бэкапами...", 2000); 
    std::cout << "Showing backup manager..." << std::endl;
    QMessageBox::information(this, "Информация", "Функция управления бэкапами будет реализована в следующей версии");
}

void MainWindow::exportToCSV() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Экспорт данных в CSV...", 2000); 
    std::cout << "Exporting to CSV..." << std::endl;
    QMessageBox::information(this, "Информация", "Функция экспорта в CSV будет реализована в следующей версии");
}

void MainWindow::importFromCSV() { 
    QStatusBar *sb = statusBar();
    sb->showMessage("Импорт данных из CSV...", 2000); 
    std::cout << "Importing from CSV..." << std::endl;
    QMessageBox::information(this, "Информация", "Функция импорта из CSV будет реализована в следующей версии");
}

// Остальные методы-заглушки
void MainWindow::updateChemicalTable() {}
void MainWindow::updateZoneTable() {}
void MainWindow::updateDistributionTable() {}
void MainWindow::updateStatistics() {}
void MainWindow::updateAlerts() {}
void MainWindow::updateActivityLog() {}
void MainWindow::showChemicalContextMenu(const QPoint &) {}
void MainWindow::showZoneContextMenu(const QPoint &) {}
void MainWindow::showDistributionContextMenu(const QPoint &) {}
void MainWindow::chemicalCellChanged(int, int) {}
void MainWindow::zoneCellChanged(int, int) {}
void MainWindow::setupDatabase() {}
void MainWindow::setupConnections() {}
void MainWindow::loadInitialData() {}
void MainWindow::setupChemicalTable() {}
void MainWindow::setupZoneTable() {}
void MainWindow::setupDistributionTable() {}
void MainWindow::setupStatisticsTab() {}
void MainWindow::setupAlertsTable() {}
void MainWindow::setupActivityLogTable() {}
void MainWindow::showAddChemicalDialog() {}
void MainWindow::showEditChemicalDialog(int) {}
void MainWindow::showAddZoneDialog() {}
void MainWindow::showEditZoneDialog(int) {}
void MainWindow::showDistributeDialog() {}
void MainWindow::showBackupRestoreDialog() {}

void MainWindow::updateStatus(const QString &msg, int timeout) { 
    QStatusBar *sb = statusBar();
    sb->showMessage(msg, timeout); 
}

void MainWindow::showError(const QString &msg) { 
    QMessageBox::critical(this, "Ошибка", msg); 
}

void MainWindow::showInfo(const QString &msg) { 
    QMessageBox::information(this, "Информация", msg); 
}

QColor MainWindow::getHazardClassColor(int hazardClass) { 
    switch(hazardClass) {
        case 1: return QColor(255, 100, 100); // Красный
        case 2: return QColor(255, 200, 100); // Оранжевый
        case 3: return QColor(255, 255, 100); // Желтый
        case 4: return QColor(200, 255, 100); // Светло-зеленый
        case 5: return QColor(100, 255, 100); // Зеленый
        default: return Qt::white;
    }
}

QColor MainWindow::getZoneLoadColor(double loadPercent) { 
    if (loadPercent > 90) return QColor(255, 100, 100); // Красный
    if (loadPercent > 70) return QColor(255, 200, 100); // Оранжевый
    return QColor(100, 255, 100); // Зеленый
}
