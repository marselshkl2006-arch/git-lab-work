#include "thememanager.h"
#include "database.h"
#include <QApplication>
#include <QFile>
#include <QDir>
#include <QStandardPaths>
#include <QDebug>

ThemeManager::ThemeManager(QObject *parent) : QObject(parent)
{
    loadThemes();
}

ThemeManager& ThemeManager::instance()
{
    static ThemeManager instance;
    return instance;
}

void ThemeManager::loadThemes()
{
    m_themeStyles.clear();
    
    // Светлая тема
    m_themeStyles["light"] = R"(
        QMainWindow {
            background-color: #f0f0f0;
        }
        QTabWidget::pane {
            border: 1px solid #cccccc;
            background-color: white;
        }
        QTabBar::tab {
            background: #e0e0e0;
            padding: 8px 16px;
            margin-right: 2px;
        }
        QTabBar::tab:selected {
            background: white;
            border-bottom: 2px solid #2196F3;
        }
        QTableWidget {
            background-color: white;
            alternate-background-color: #f9f9f9;
            gridline-color: #e0e0e0;
        }
        QHeaderView::section {
            background-color: #f5f5f5;
            padding: 5px;
            border: 1px solid #e0e0e0;
        }
        QToolBar {
            background-color: #ffffff;
            border-bottom: 1px solid #dddddd;
            spacing: 5px;
        }
        QStatusBar {
            background-color: #f5f5f5;
            color: #333333;
        }
        QPushButton {
            background-color: #2196F3;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
        }
        QPushButton:hover {
            background-color: #1976D2;
        }
        QLineEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {
            border: 1px solid #cccccc;
            padding: 4px;
            border-radius: 3px;
            background-color: white;
        }
        QGroupBox {
            border: 1px solid #dddddd;
            border-radius: 5px;
            margin-top: 10px;
            padding-top: 10px;
            font-weight: bold;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px 0 5px;
        }
    )";
    
    // Темная тема
    m_themeStyles["dark"] = R"(
        QMainWindow {
            background-color: #2b2b2b;
            color: #e0e0e0;
        }
        QTabWidget::pane {
            border: 1px solid #444444;
            background-color: #353535;
        }
        QTabBar::tab {
            background: #3c3c3c;
            color: #e0e0e0;
            padding: 8px 16px;
            margin-right: 2px;
        }
        QTabBar::tab:selected {
            background: #2b2b2b;
            color: white;
            border-bottom: 2px solid #64B5F6;
        }
        QTableWidget {
            background-color: #353535;
            color: #e0e0e0;
            alternate-background-color: #3c3c3c;
            gridline-color: #444444;
        }
        QHeaderView::section {
            background-color: #2b2b2b;
            color: #e0e0e0;
            padding: 5px;
            border: 1px solid #444444;
        }
        QToolBar {
            background-color: #353535;
            border-bottom: 1px solid #444444;
            spacing: 5px;
        }
        QStatusBar {
            background-color: #2b2b2b;
            color: #e0e0e0;
        }
        QPushButton {
            background-color: #64B5F6;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
        }
        QPushButton:hover {
            background-color: #42A5F5;
        }
        QLineEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {
            border: 1px solid #555555;
            padding: 4px;
            border-radius: 3px;
            background-color: #3c3c3c;
            color: #e0e0e0;
        }
        QGroupBox {
            border: 1px solid #444444;
            border-radius: 5px;
            margin-top: 10px;
            padding-top: 10px;
            font-weight: bold;
            color: #e0e0e0;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px 0 5px;
            color: #e0e0e0;
        }
    )";
    
    // Синяя тема (лабораторная)
    m_themeStyles["blue"] = R"(
        QMainWindow {
            background-color: #e3f2fd;
        }
        QTabWidget::pane {
            border: 1px solid #bbdefb;
            background-color: white;
        }
        QTabBar::tab {
            background: #bbdefb;
            color: #1565C0;
            padding: 8px 16px;
            margin-right: 2px;
        }
        QTabBar::tab:selected {
            background: white;
            border-bottom: 2px solid #2196F3;
            color: #0D47A1;
        }
        QTableWidget {
            background-color: white;
            alternate-background-color: #f3f9ff;
            gridline-color: #bbdefb;
        }
        QHeaderView::section {
            background-color: #e3f2fd;
            color: #1565C0;
            padding: 5px;
            border: 1px solid #bbdefb;
        }
        QToolBar {
            background-color: #bbdefb;
            border-bottom: 1px solid #90caf9;
            spacing: 5px;
        }
        QStatusBar {
            background-color: #e3f2fd;
            color: #1565C0;
        }
        QPushButton {
            background-color: #2196F3;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
        }
        QPushButton:hover {
            background-color: #1976D2;
        }
        QLineEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {
            border: 1px solid #bbdefb;
            padding: 4px;
            border-radius: 3px;
            background-color: white;
        }
        QGroupBox {
            border: 1px solid #bbdefb;
            border-radius: 5px;
            margin-top: 10px;
            padding-top: 10px;
            font-weight: bold;
            color: #1565C0;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px 0 5px;
            color: #1565C0;
        }
    )";
    
    // Зеленая тема (безопасность)
    m_themeStyles["green"] = R"(
        QMainWindow {
            background-color: #e8f5e9;
        }
        QTabWidget::pane {
            border: 1px solid #c8e6c9;
            background-color: white;
        }
        QTabBar::tab {
            background: #c8e6c9;
            color: #2e7d32;
            padding: 8px 16px;
            margin-right: 2px;
        }
        QTabBar::tab:selected {
            background: white;
            border-bottom: 2px solid #4CAF50;
            color: #1b5e20;
        }
        QTableWidget {
            background-color: white;
            alternate-background-color: #f9fdf9;
            gridline-color: #c8e6c9;
        }
        QHeaderView::section {
            background-color: #e8f5e9;
            color: #2e7d32;
            padding: 5px;
            border: 1px solid #c8e6c9;
        }
        QToolBar {
            background-color: #c8e6c9;
            border-bottom: 1px solid #a5d6a7;
            spacing: 5px;
        }
        QStatusBar {
            background-color: #e8f5e9;
            color: #2e7d32;
        }
        QPushButton {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
        }
        QPushButton:hover {
            background-color: #388E3C;
        }
        QLineEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {
            border: 1px solid #c8e6c9;
            padding: 4px;
            border-radius: 3px;
            background-color: white;
        }
        QGroupBox {
            border: 1px solid #c8e6c9;
            border-radius: 5px;
            margin-top: 10px;
            padding-top: 10px;
            font-weight: bold;
            color: #2e7d32;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px 0 5px;
            color: #2e7d32;
        }
    )";
    
    // Загружаем тему из настроек
    Database& db = Database::instance();
    m_currentTheme = db.getSetting("theme", "light").toString();
}

QStringList ThemeManager::getAvailableThemes() const
{
    return m_themeStyles.keys();
}

QString ThemeManager::getCurrentTheme() const
{
    return m_currentTheme;
}

void ThemeManager::applyTheme(const QString &themeName)
{
    if (!m_themeStyles.contains(themeName)) {
        qWarning() << "Тема" << themeName << "не найдена";
        return;
    }
    
    m_currentTheme = themeName;
    
    // Применяем стили
    qApp->setStyleSheet(m_themeStyles[themeName]);
    
    // Сохраняем в настройки
    Database& db = Database::instance();
    db.setSetting("theme", themeName);
    
    emit themeChanged(themeName);
}

void ThemeManager::loadThemeFromSettings()
{
    Database& db = Database::instance();
    QString savedTheme = db.getSetting("theme", "light").toString();
    applyTheme(savedTheme);
}

QMap<QString, QString> ThemeManager::getThemeStyles() const
{
    return m_themeStyles;
}
