#!/bin/bash
FILE="mainwindow.cpp"

# Находим метод createStatusBar и заменяем его
sed -i '/void MainWindow::createStatusBar()/,/^}/c\
void MainWindow::createStatusBar()\
{\
    QStatusBar *statusBarWidget = QMainWindow::statusBar();\
    statusBarWidget->addWidget(statusLabel);\
    \
    progressBar = new QProgressBar();\
    progressBar->setMaximumWidth(200);\
    progressBar->setVisible(false);\
    statusBarWidget->addWidget(progressBar);\
    \
    QLabel *dbStatus = new QLabel("🟢 База данных подключена");\
    statusBarWidget->addPermanentWidget(dbStatus);\
}' "$FILE"

echo "Метод createStatusBar исправлен"
