#include "mainwindow.h"
#include "database.h"
#include "dialogs.h"
#include "settingsdialog.h"
#include "thememanager.h"

#include <QApplication>
#include <QTabWidget>
#include <QTableWidget>
#include <QToolBar>
#include <QStatusBar>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QHeaderView>
#include <QMessageBox>
#include <QFileDialog>
#include <QInputDialog>
#include <QColor>
#include <QBrush>
#include <QDate>
#include <QDateTime>
#include <QTimer>
#include <QProgressBar>
#include <QLabel>
#include <QLineEdit>
#include <QComboBox>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QGroupBox>
#include <QTextEdit>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDoubleSpinBox>
#include <QSpinBox>
#include <QDateEdit>
#include <QCheckBox>
#include <QDir>
#include <QStandardPaths>
#include <QTextStream>
#include <QGuiApplication>
#include <QScreen>
#include <iostream>

// ============ КОНСТРУКТОР И ДЕСТРУКТОР ============

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , tabWidget(nullptr)
    , chemicalTable(nullptr)
    , zoneTable(nullptr)
    , distributionTable(nullptr)
    , alertsTable(nullptr)
    , activityLogTable(nullptr)
    , mainToolBar(nullptr)
    , statusLabel(nullptr)
    , progressBar(nullptr)
    , searchChemicalEdit(nullptr)
    , hazardClassFilter(nullptr)
    , db(nullptr)
    , autoUpdateTimer(nullptr)
    , alertCheckTimer(nullptr)
{
    std::cout << "MainWindow constructor started" << std::endl;
    
    // Настройка главного окна
    setWindowTitle("Химическая Лаборатория v2.1");
    setMinimumSize(1400, 900);
    
    // Центрируем окно
    QRect screenGeometry = QGuiApplication::primaryScreen()->geometry();
    int x = (screenGeometry.width() - 1400) / 2;
    int y = (screenGeometry.height() - 900) / 2;
    move(x, y);
    
    try {
        std::cout << "Setting up database..." << std::endl;
        setupDatabase();
        
        std::cout << "Creating menu..." << std::endl;
        createMenu();
        
        std::cout << "Creating toolbar..." << std::endl;
        createToolBar();
        
        std::cout << "Creating central widget..." << std::endl;
        createCentralWidget();
        
        std::cout << "Creating status bar..." << std::endl;
        createStatusBar();
        
        std::cout << "Setting up connections..." << std::endl;
        setupConnections();
        
        std::cout << "Setting up auto updates..." << std::endl;
        setupAutoUpdates();
        
        std::cout << "Loading initial data..." << std::endl;
        loadInitialData();
        
        // Загружаем тему из настроек
        ThemeManager::instance().loadThemeFromSettings();
        
        updateStatus("✅ Система готова к работе", 2000);
        std::cout << "MainWindow created successfully" << std::endl;
        
    } catch (const std::exception &e) {
        std::cerr << "Exception in MainWindow constructor: " << e.what() << std::endl;
        QMessageBox::critical(this, "Критическая ошибка", 
            QString("Не удалось создать главное окно:\n%1").arg(e.what()));
    }
}

MainWindow::~MainWindow()
{
    std::cout << "MainWindow destroyed" << std::endl;
    
    if (autoUpdateTimer) {
        autoUpdateTimer->stop();
        delete autoUpdateTimer;
    }
    if (alertCheckTimer) {
        alertCheckTimer->stop();
        delete alertCheckTimer;
    }
}

// ============ ИНИЦИАЛИЗАЦИЯ ============

void MainWindow::setupDatabase()
{
    try {
        db = &Database::instance();
        if (!db->initializeDatabase()) {
            QMessageBox::critical(this, "❌ Критическая ошибка", 
                "Не удалось инициализировать базу данных!\n\n"
                "Причина: " + db->getLastError() + "\n\n"
                "Проверьте права доступа к файловой системе.");
            qApp->quit();
            return;
        }
        
        // Подключаем сигналы от базы данных
        connect(db, &Database::dataChanged, this, &MainWindow::refreshAll);
        
    } catch (const std::exception &e) {
        QMessageBox::critical(this, "❌ Исключение", 
            QString("Исключение при инициализации БД:\n%1").arg(e.what()));
        qApp->quit();
    }
}

void MainWindow::createMenu()
{
    // Меню Файл
    QMenu *fileMenu = menuBar()->addMenu("📁 Файл");
    
    QAction *newChemicalAction = fileMenu->addAction("🧪 Добавить химикат");
    newChemicalAction->setShortcut(QKeySequence::New);
    newChemicalAction->setStatusTip("Добавить новый химикат в базу данных");
    connect(newChemicalAction, &QAction::triggered, this, &MainWindow::addChemical);
    
    QAction *newZoneAction = fileMenu->addAction("🏢 Добавить зону хранения");
    newZoneAction->setStatusTip("Добавить новую зону хранения");
    connect(newZoneAction, &QAction::triggered, this, &MainWindow::addStorageZone);
    
    fileMenu->addSeparator();
    
    QAction *exportAction = fileMenu->addAction("📤 Экспорт данных");
    exportAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_E));
    exportAction->setStatusTip("Экспорт всех данных в CSV файл");
    connect(exportAction, &QAction::triggered, this, &MainWindow::exportToCSV);
    
    QAction *importAction = fileMenu->addAction("📥 Импорт данных");
    importAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_I));
    importAction->setStatusTip("Импорт данных из CSV файла");
    connect(importAction, &QAction::triggered, this, &MainWindow::importFromCSV);
    
    fileMenu->addSeparator();
    
    QAction *backupAction = fileMenu->addAction("💾 Создать резервную копию");
    backupAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_B));
    backupAction->setStatusTip("Создать резервную копию базы данных");
    connect(backupAction, &QAction::triggered, this, &MainWindow::backupDatabase);
    
    QAction *restoreAction = fileMenu->addAction("🔄 Восстановить из копии");
    restoreAction->setStatusTip("Восстановить базу данных из резервной копии");
    connect(restoreAction, &QAction::triggered, this, &MainWindow::restoreDatabase);
    
    QAction *manageBackupsAction = fileMenu->addAction("📊 Управление бэкапами");
    manageBackupsAction->setStatusTip("Просмотр и управление резервными копиями");
    connect(manageBackupsAction, &QAction::triggered, this, &MainWindow::manageBackups);
    
    fileMenu->addSeparator();
    
    QAction *settingsAction = fileMenu->addAction("⚙️ Настройки");
    settingsAction->setShortcut(QKeySequence::Preferences);
    settingsAction->setStatusTip("Настройки приложения");
    connect(settingsAction, &QAction::triggered, this, &MainWindow::showSettings);
    
    fileMenu->addSeparator();
    
    QAction *exitAction = fileMenu->addAction("🚪 Выход");
    exitAction->setShortcut(QKeySequence::Quit);
    exitAction->setStatusTip("Выйти из приложения");
    connect(exitAction, &QAction::triggered, qApp, &QApplication::quit);
    
    // Меню Редактирование
    QMenu *editMenu = menuBar()->addMenu("✏️ Редактирование");
    
    QAction *editChemicalAction = editMenu->addAction("✏️ Редактировать химикат");
    editChemicalAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_E));
    editChemicalAction->setStatusTip("Редактировать выбранный химикат");
    connect(editChemicalAction, &QAction::triggered, this, &MainWindow::editChemical);
    
    QAction *deleteChemicalAction = editMenu->addAction("🗑️ Удалить химикат");
    deleteChemicalAction->setShortcut(QKeySequence::Delete);
    deleteChemicalAction->setStatusTip("Удалить выбранный химикат");
    connect(deleteChemicalAction, &QAction::triggered, this, &MainWindow::deleteChemical);
    
    editMenu->addSeparator();
    
    QAction *editZoneAction = editMenu->addAction("⚙️ Редактировать зону");
    editZoneAction->setStatusTip("Редактировать выбранную зону хранения");
    connect(editZoneAction, &QAction::triggered, this, &MainWindow::editStorageZone);
    
    QAction *deleteZoneAction = editMenu->addAction("❌ Удалить зону");
    deleteZoneAction->setStatusTip("Удалить выбранную зону хранения");
    connect(deleteZoneAction, &QAction::triggered, this, &MainWindow::deleteStorageZone);
    
    editMenu->addSeparator();
    
    QAction *distributeAction = editMenu->addAction("📦 Распределить химикат");
    distributeAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_D));
    distributeAction->setStatusTip("Распределить химикат по зонам хранения");
    connect(distributeAction, &QAction::triggered, this, &MainWindow::distributeChemical);
    
    QAction *removeDistAction = editMenu->addAction("↩️ Удалить распределение");
    removeDistAction->setStatusTip("Удалить распределение химиката из зоны");
    connect(removeDistAction, &QAction::triggered, this, &MainWindow::removeDistribution);
    
    // Меню Вид
    QMenu *viewMenu = menuBar()->addMenu("👁️ Вид");
    
    QAction *refreshAction = viewMenu->addAction("🔄 Обновить");
    refreshAction->setShortcut(QKeySequence::Refresh);
    refreshAction->setStatusTip("Обновить все данные");
    connect(refreshAction, &QAction::triggered, this, &MainWindow::refreshAll);
    
    viewMenu->addSeparator();
    
    QAction *showChemicalsAction = viewMenu->addAction("🧪 Химикаты");
    showChemicalsAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_1));
    showChemicalsAction->setStatusTip("Показать вкладку химикатов");
    connect(showChemicalsAction, &QAction::triggered, this, [this]() { 
        if (tabWidget) tabWidget->setCurrentIndex(0); 
        updateStatus("🧪 Просмотр химикатов", 2000);
    });
    
    QAction *showZonesAction = viewMenu->addAction("🏢 Зоны хранения");
    showZonesAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_2));
    showZonesAction->setStatusTip("Показать вкладку зон хранения");
    connect(showZonesAction, &QAction::triggered, this, [this]() { 
        if (tabWidget) tabWidget->setCurrentIndex(1); 
        updateStatus("🏢 Просмотр зон хранения", 2000);
    });
    
    QAction *showDistributionAction = viewMenu->addAction("📊 Распределение");
    showDistributionAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_3));
    showDistributionAction->setStatusTip("Показать вкладку распределения");
    connect(showDistributionAction, &QAction::triggered, this, [this]() { 
        if (tabWidget) tabWidget->setCurrentIndex(2); 
        updateStatus("📊 Просмотр распределения", 2000);
    });
    
    QAction *showStatisticsAction = viewMenu->addAction("📈 Статистика");
    showStatisticsAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_4));
    showStatisticsAction->setStatusTip("Показать вкладку статистики");
    connect(showStatisticsAction, &QAction::triggered, this, [this]() { 
        if (tabWidget) tabWidget->setCurrentIndex(3); 
        updateStatus("📈 Просмотр статистики", 2000);
    });
    
    QAction *showAlertsAction = viewMenu->addAction("⚠️ Оповещения");
    showAlertsAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_5));
    showAlertsAction->setStatusTip("Показать вкладку оповещений");
    connect(showAlertsAction, &QAction::triggered, this, [this]() { 
        if (tabWidget) tabWidget->setCurrentIndex(4); 
        updateStatus("⚠️ Просмотр оповещений", 2000);
    });
    
    QAction *showLogAction = viewMenu->addAction("📝 Журнал действий");
    showLogAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_6));
    showLogAction->setStatusTip("Показать вкладку журнала действий");
    connect(showLogAction, &QAction::triggered, this, [this]() { 
        if (tabWidget) tabWidget->setCurrentIndex(5); 
        updateStatus("📝 Просмотр журнала действий", 2000);
    });
    
    // Меню Справка
    QMenu *helpMenu = menuBar()->addMenu("❓ Справка");
    
    QAction *aboutAction = helpMenu->addAction("ℹ️ О программе");
    aboutAction->setStatusTip("Информация о программе");
    connect(aboutAction, &QAction::triggered, this, &MainWindow::showAbout);
    
    QAction *aboutQtAction = helpMenu->addAction("О Qt");
    aboutQtAction->setStatusTip("О Qt");
    connect(aboutQtAction, &QAction::triggered, qApp, &QApplication::aboutQt);
}

void MainWindow::createToolBar()
{
    // Главная панель инструментов
    mainToolBar = new QToolBar("Основная панель", this);
    mainToolBar->setMovable(false);
    mainToolBar->setIconSize(QSize(32, 32));
    mainToolBar->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
    addToolBar(mainToolBar);
    
    // Кнопка добавления химиката
    QAction *addChemicalAction = mainToolBar->addAction("➕ Добавить");
    addChemicalAction->setToolTip("Добавить новый химикат (Ctrl+N)");
    connect(addChemicalAction, &QAction::triggered, this, &MainWindow::addChemical);
    
    // Кнопка редактирования химиката
    QAction *editChemicalAction = mainToolBar->addAction("✏️ Редактировать");
    editChemicalAction->setToolTip("Редактировать выбранный химикат (Ctrl+E)");
    connect(editChemicalAction, &QAction::triggered, this, &MainWindow::editChemical);
    
    // Кнопка удаления химиката
    QAction *deleteChemicalAction = mainToolBar->addAction("🗑️ Удалить");
    deleteChemicalAction->setToolTip("Удалить выбранный химикат (Del)");
    connect(deleteChemicalAction, &QAction::triggered, this, &MainWindow::deleteChemical);
    
    mainToolBar->addSeparator();
    
    // Кнопка распределения
    QAction *distributeAction = mainToolBar->addAction("📦 Распределить");
    distributeAction->setToolTip("Распределить химикат по зонам (Ctrl+D)");
    connect(distributeAction, &QAction::triggered, this, &MainWindow::distributeChemical);
    
    mainToolBar->addSeparator();
    
    // Кнопка экспорта
    QAction *exportAction = mainToolBar->addAction("📤 Экспорт");
    exportAction->setToolTip("Экспорт данных (Ctrl+E)");
    connect(exportAction, &QAction::triggered, this, &MainWindow::exportToCSV);
    
    // Кнопка резервного копирования
    QAction *backupAction = mainToolBar->addAction("💾 Бекап");
    backupAction->setToolTip("Создать резервную копию (Ctrl+B)");
    connect(backupAction, &QAction::triggered, this, &MainWindow::backupDatabase);
    
    mainToolBar->addSeparator();
    
    // Кнопка обновления
    QAction *refreshAction = mainToolBar->addAction("🔄 Обновить");
    refreshAction->setToolTip("Обновить данные (F5)");
    connect(refreshAction, &QAction::triggered, this, &MainWindow::refreshAll);
    
    mainToolBar->addSeparator();
    
    // Поиск химикатов
    mainToolBar->addWidget(new QLabel(" 🔍 Поиск:"));
    
    searchChemicalEdit = new QLineEdit();
    searchChemicalEdit->setPlaceholderText("Название, формула, CAS...");
    searchChemicalEdit->setMinimumWidth(250);
    searchChemicalEdit->setMaximumWidth(350);
    mainToolBar->addWidget(searchChemicalEdit);
    connect(searchChemicalEdit, &QLineEdit::textChanged, this, &MainWindow::searchChemicals);
    
    // Фильтр по классу опасности
    mainToolBar->addWidget(new QLabel(" ⚠️ Класс:"));
    
    hazardClassFilter = new QComboBox();
    hazardClassFilter->addItem("Все классы", 0);
    hazardClassFilter->addItem("1 - Чрезвычайно опасный", 1);
    hazardClassFilter->addItem("2 - Высокоопасный", 2);
    hazardClassFilter->addItem("3 - Умеренно опасный", 3);
    hazardClassFilter->addItem("4 - Малоопасный", 4);
    hazardClassFilter->addItem("5 - Практически неопасный", 5);
    hazardClassFilter->setMaximumWidth(200);
    mainToolBar->addWidget(hazardClassFilter);
    connect(hazardClassFilter, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::searchChemicals);
}

void MainWindow::createCentralWidget()
{
    tabWidget = new QTabWidget(this);
    tabWidget->setTabPosition(QTabWidget::North);
    tabWidget->setDocumentMode(true);
    tabWidget->setTabShape(QTabWidget::Triangular);
    setCentralWidget(tabWidget);
    
    // Создаем вкладки
    setupChemicalTable();
    setupZoneTable();
    setupDistributionTable();
    setupStatisticsTab();
    setupAlertsTable();
    setupActivityLogTable();
}

void MainWindow::setupChemicalTable()
{
    QWidget *chemicalTab = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(chemicalTab);
    
    // Создаем таблицу химикатов
    chemicalTable = new QTableWidget();
    chemicalTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    chemicalTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    chemicalTable->setSelectionMode(QAbstractItemView::SingleSelection);
    chemicalTable->setAlternatingRowColors(true);
    chemicalTable->setSortingEnabled(true);
    chemicalTable->setContextMenuPolicy(Qt::CustomContextMenu);
    
    // Настраиваем заголовки
    QStringList headers = {"ID", "Название", "Формула", "CAS", "Производитель", 
                          "Чистота %", "Количество", "Ед.изм", "Класс опасности", 
                          "Срок годности", "Дата поступления", "Статус"};
    chemicalTable->setColumnCount(headers.size());
    chemicalTable->setHorizontalHeaderLabels(headers);
    
    layout->addWidget(chemicalTable);
    tabWidget->addTab(chemicalTab, "🧪 Химикаты");
    
    connect(chemicalTable, &QTableWidget::customContextMenuRequested,
            this, &MainWindow::showChemicalContextMenu);
    connect(chemicalTable, &QTableWidget::cellDoubleClicked,
            this, &MainWindow::chemicalCellDoubleClicked);
}

void MainWindow::setupZoneTable()
{
    QWidget *zoneTab = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(zoneTab);
    
    zoneTable = new QTableWidget();
    zoneTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    zoneTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    zoneTable->setSelectionMode(QAbstractItemView::SingleSelection);
    zoneTable->setAlternatingRowColors(true);
    zoneTable->setSortingEnabled(true);
    zoneTable->setContextMenuPolicy(Qt::CustomContextMenu);
    
    QStringList headers = {"ID", "Название", "Описание", "Температура", "Влажность", 
                          "Освещение", "Безопасность", "Макс. емкость", "Текущая загрузка", 
                          "Загрузка %", "Статус", "Химикатов"};
    zoneTable->setColumnCount(headers.size());
    zoneTable->setHorizontalHeaderLabels(headers);
    
    layout->addWidget(zoneTable);
    tabWidget->addTab(zoneTab, "🏢 Зоны хранения");
    
    connect(zoneTable, &QTableWidget::customContextMenuRequested,
            this, &MainWindow::showZoneContextMenu);
    connect(zoneTable, &QTableWidget::cellDoubleClicked,
            this, &MainWindow::zoneCellDoubleClicked);
}

void MainWindow::setupDistributionTable()
{
    QWidget *distributionTab = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(distributionTab);
    
    distributionTable = new QTableWidget();
    distributionTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    distributionTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    distributionTable->setSelectionMode(QAbstractItemView::SingleSelection);
    distributionTable->setAlternatingRowColors(true);
    distributionTable->setSortingEnabled(true);
    distributionTable->setContextMenuPolicy(Qt::CustomContextMenu);
    
    QStringList headers = {"ID", "Химикат", "Формула", "Зона хранения", "Количество", 
                          "Ед.изм", "Дата размещения", "Срок годности", "Примечания"};
    distributionTable->setColumnCount(headers.size());
    distributionTable->setHorizontalHeaderLabels(headers);
    
    layout->addWidget(distributionTable);
    tabWidget->addTab(distributionTab, "📊 Распределение");
    
    connect(distributionTable, &QTableWidget::customContextMenuRequested,
            this, &MainWindow::showDistributionContextMenu);
}

void MainWindow::setupStatisticsTab()
{
    QWidget *statisticsTab = new QWidget();
    QVBoxLayout *mainLayout = new QVBoxLayout(statisticsTab);
    
    QLabel *titleLabel = new QLabel("📊 Статистика системы");
    titleLabel->setStyleSheet("font-size: 20px; font-weight: bold; margin: 10px;");
    titleLabel->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(titleLabel);
    
    QGridLayout *gridLayout = new QGridLayout();
    
    statTotalChemicals = new QLabel("Химикатов: 0");
    statTotalZones = new QLabel("Зон хранения: 0");
    statTotalQuantity = new QLabel("Общее количество: 0 г");
    statAverageHazard = new QLabel("Средний класс опасности: 0");
    statExpiringSoon = new QLabel("Истекает скоро: 0");
    statLowStock = new QLabel("Низкий запас: 0");
    statMostLoadedZone = new QLabel("Самая загруженная зона: -");
    statLeastLoadedZone = new QLabel("Самая свободная зона: -");
    statActiveAlerts = new QLabel("Активных оповещений: 0");
    statDatabaseSize = new QLabel("Размер БД: 0 МБ");
    statLastBackup = new QLabel("Последний бекап: никогда");
    
    QString labelStyle = "font-size: 14px; padding: 5px;";
    statTotalChemicals->setStyleSheet(labelStyle);
    statTotalZones->setStyleSheet(labelStyle);
    statTotalQuantity->setStyleSheet(labelStyle);
    statAverageHazard->setStyleSheet(labelStyle);
    statExpiringSoon->setStyleSheet(labelStyle);
    statLowStock->setStyleSheet(labelStyle);
    statMostLoadedZone->setStyleSheet(labelStyle);
    statLeastLoadedZone->setStyleSheet(labelStyle);
    statActiveAlerts->setStyleSheet(labelStyle);
    statDatabaseSize->setStyleSheet(labelStyle);
    statLastBackup->setStyleSheet(labelStyle);
    
    gridLayout->addWidget(statTotalChemicals, 0, 0);
    gridLayout->addWidget(statTotalZones, 0, 1);
    gridLayout->addWidget(statTotalQuantity, 1, 0);
    gridLayout->addWidget(statAverageHazard, 1, 1);
    gridLayout->addWidget(statExpiringSoon, 2, 0);
    gridLayout->addWidget(statLowStock, 2, 1);
    gridLayout->addWidget(statMostLoadedZone, 3, 0);
    gridLayout->addWidget(statLeastLoadedZone, 3, 1);
    gridLayout->addWidget(statActiveAlerts, 4, 0);
    gridLayout->addWidget(statDatabaseSize, 4, 1);
    gridLayout->addWidget(statLastBackup, 5, 0, 1, 2);
    
    mainLayout->addLayout(gridLayout);
    mainLayout->addStretch();
    
    tabWidget->addTab(statisticsTab, "📈 Статистика");
}

void MainWindow::setupAlertsTable()
{
    QWidget *alertsTab = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(alertsTab);
    
    alertsTable = new QTableWidget();
    alertsTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    alertsTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    alertsTable->setSelectionMode(QAbstractItemView::SingleSelection);
    alertsTable->setAlternatingRowColors(true);
    alertsTable->setSortingEnabled(true);
    alertsTable->setContextMenuPolicy(Qt::CustomContextMenu);
    
    QStringList headers = {"ID", "Дата создания", "Тип", "Сообщение", "Серьезность", 
                          "Статус", "Решено", "Решено кем", "Дата решения"};
    alertsTable->setColumnCount(headers.size());
    alertsTable->setHorizontalHeaderLabels(headers);
    
    layout->addWidget(alertsTable);
    tabWidget->addTab(alertsTab, "⚠️ Оповещения");
    
    connect(alertsTable, &QTableWidget::customContextMenuRequested,
            this, &MainWindow::showAlertContextMenu);
}

void MainWindow::setupActivityLogTable()
{
    QWidget *logTab = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(logTab);
    
    activityLogTable = new QTableWidget();
    activityLogTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    activityLogTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    activityLogTable->setAlternatingRowColors(true);
    activityLogTable->setSortingEnabled(true);
    
    QStringList headers = {"ID", "Время", "Пользователь", "Действие", "Детали"};
    activityLogTable->setColumnCount(headers.size());
    activityLogTable->setHorizontalHeaderLabels(headers);
    
    layout->addWidget(activityLogTable);
    tabWidget->addTab(logTab, "📝 Журнал действий");
}


void MainWindow::setupConnections()
{
    connect(searchChemicalEdit, &QLineEdit::textChanged, this, &MainWindow::searchChemicals);
    connect(hazardClassFilter, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::searchChemicals);
    connect(tabWidget, &QTabWidget::currentChanged, this, &MainWindow::tabChanged);
}

void MainWindow::setupAutoUpdates()
{
    autoUpdateTimer = new QTimer(this);
    connect(autoUpdateTimer, &QTimer::timeout, this, [this]() {
        if (tabWidget && tabWidget->currentIndex() == 0) {
            updateChemicalTable();
        }
    });
    autoUpdateTimer->start(30000);
    
    alertCheckTimer = new QTimer(this);
    connect(alertCheckTimer, &QTimer::timeout, this, [this]() {
        if (db) {
            // Базовая проверка оповещений
        }
    });
    alertCheckTimer->start(60000);
}

void MainWindow::loadInitialData()
{
    refreshAll();
    
    QTimer::singleShot(1000, this, [this]() {
        if (db) {
            int chemicalCount = db->getChemicalCount();
            int zoneCount = db->getZoneCount();
            updateStatus(QString("✅ Загружено %1 химикатов и %2 зон хранения")
                        .arg(chemicalCount).arg(zoneCount), 3000);
        }
    });
}

// ============ ОСНОВНЫЕ ФУНКЦИИ ============

void MainWindow::refreshAll()
{
    updateStatus("🔄 Обновление данных...", 1000);
    
    updateChemicalTable();
    updateZoneTable();
    updateDistributionTable();
    updateStatistics();
    updateAlerts();
    updateActivityLog();
    
    QTimer::singleShot(1000, this, [this]() {
        updateStatus("✅ Данные обновлены", 2000);
    });
}

void MainWindow::updateChemicalTable()
{
    if (!db || !chemicalTable) return;
    
    progressBar->setVisible(true);
    progressBar->setRange(0, 0);
    
    try {
        QList<QMap<QString, QVariant>> chemicals;
        QString searchText = searchChemicalEdit ? searchChemicalEdit->text().trimmed() : "";
        int hazardFilter = hazardClassFilter ? hazardClassFilter->currentData().toInt() : 0;
        
        if (searchText.isEmpty() && hazardFilter == 0) {
            chemicals = db->getAllChemicals();
        } else {
            chemicals = db->searchChemicals(searchText, hazardFilter);
        }
        
        chemicalTable->setRowCount(0);
        chemicalTable->setRowCount(chemicals.size());
        
        for (int i = 0; i < chemicals.size(); ++i) {
            const auto &chem = chemicals[i];
            
            // ID
            QTableWidgetItem *idItem = new QTableWidgetItem(chem["id"].toString());
            idItem->setTextAlignment(Qt::AlignCenter);
            chemicalTable->setItem(i, 0, idItem);
            
            // Название
            QTableWidgetItem *nameItem = new QTableWidgetItem(chem["name"].toString());
            chemicalTable->setItem(i, 1, nameItem);
            
            // Формула
            chemicalTable->setItem(i, 2, new QTableWidgetItem(chem["formula"].toString()));
            
            // CAS номер
            chemicalTable->setItem(i, 3, new QTableWidgetItem(chem["cas_number"].toString()));
            
            // Производитель
            chemicalTable->setItem(i, 4, new QTableWidgetItem(chem["manufacturer"].toString()));
            
            // Чистота
            QTableWidgetItem *purityItem = new QTableWidgetItem(
                QString::number(chem["purity"].toDouble(), 'f', 1) + " %");
            purityItem->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
            chemicalTable->setItem(i, 5, purityItem);
            
            // Количество
            QTableWidgetItem *qtyItem = new QTableWidgetItem(
                QString::number(chem["quantity"].toDouble(), 'f', 2));
            qtyItem->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
            chemicalTable->setItem(i, 6, qtyItem);
            
            // Единица измерения
            chemicalTable->setItem(i, 7, new QTableWidgetItem(chem["unit"].toString()));
            
            // Класс опасности
            int hazardClass = chem["hazard_class"].toInt();
            QTableWidgetItem *hazardItem = new QTableWidgetItem(
                QString::number(hazardClass));
            hazardItem->setBackground(getHazardClassColor(hazardClass));
            hazardItem->setTextAlignment(Qt::AlignCenter);
            hazardItem->setToolTip(getHazardClassTooltip(hazardClass));
            chemicalTable->setItem(i, 8, hazardItem);
            
            // Срок годности
            QDate expDate = chem["expiration_date"].toDate();
            QTableWidgetItem *expItem = new QTableWidgetItem(
                expDate.isValid() ? expDate.toString("dd.MM.yyyy") : "Нет");
            if (expDate.isValid() && expDate < QDate::currentDate()) {
                expItem->setBackground(Qt::red);
                expItem->setForeground(Qt::white);
            }
            expItem->setTextAlignment(Qt::AlignCenter);
            chemicalTable->setItem(i, 9, expItem);
            
            // Дата поступления
            QDate arrDate = chem["arrival_date"].toDate();
            chemicalTable->setItem(i, 10, new QTableWidgetItem(
                arrDate.toString("dd.MM.yyyy")));
            
            // Статус
            QString status = "";
            QDate today = QDate::currentDate();
            
            if (expDate.isValid() && expDate < today) {
                status = "⚠️ ПРОСРОЧЕН";
            } else if (expDate.isValid() && expDate <= today.addDays(30)) {
                status = "⚠️ Истекает";
            } else if (chem["quantity"].toDouble() < 10.0) {
                status = "⚠️ Мало";
            } else {
                status = "✅ OK";
            }
            
            QTableWidgetItem *statusItem = new QTableWidgetItem(status);
            if (status.contains("ПРОСРОЧЕН")) {
                statusItem->setBackground(Qt::red);
                statusItem->setForeground(Qt::white);
            } else if (status.contains("⚠️")) {
                statusItem->setBackground(QColor(255, 165, 0));
            } else {
                statusItem->setBackground(QColor(144, 238, 144));
            }
            statusItem->setTextAlignment(Qt::AlignCenter);
            chemicalTable->setItem(i, 11, statusItem);
        }
        
    } catch (const std::exception &e) {
        showError(QString("Ошибка при загрузке химикатов:\n%1").arg(e.what()));
    }
    
    progressBar->setVisible(false);
}

void MainWindow::updateZoneTable()
{
    if (!db || !zoneTable) return;
    
    try {
        QList<QMap<QString, QVariant>> zones = db->getAllStorageZones();
        zoneTable->setRowCount(0);
        zoneTable->setRowCount(zones.size());
        
        for (int i = 0; i < zones.size(); ++i) {
            const auto &zone = zones[i];
            
            // ID
            QTableWidgetItem *idItem = new QTableWidgetItem(zone["id"].toString());
            idItem->setTextAlignment(Qt::AlignCenter);
            zoneTable->setItem(i, 0, idItem);
            
            // Название
            QTableWidgetItem *nameItem = new QTableWidgetItem(zone["name"].toString());
            zoneTable->setItem(i, 1, nameItem);
            
            // Описание
            zoneTable->setItem(i, 2, new QTableWidgetItem(zone["description"].toString()));
            
            // Температура
            double tempMin = zone["temperature_min"].toDouble();
            double tempMax = zone["temperature_max"].toDouble();
            QString tempStr = tempMin != 0 || tempMax != 0 ? 
                QString("%1°C - %2°C").arg(tempMin).arg(tempMax) : "Не задано";
            zoneTable->setItem(i, 3, new QTableWidgetItem(tempStr));
            
            // Влажность
            double humMin = zone["humidity_min"].toDouble();
            double humMax = zone["humidity_max"].toDouble();
            QString humStr = humMin != 0 || humMax != 0 ? 
                QString("%1% - %2%").arg(humMin).arg(humMax) : "Не задано";
            zoneTable->setItem(i, 4, new QTableWidgetItem(humStr));
            
            // Освещение
            zoneTable->setItem(i, 5, new QTableWidgetItem(zone["lighting_conditions"].toString()));
            
            // Безопасность
            int security = zone["security_level"].toInt();
            QTableWidgetItem *securityItem = new QTableWidgetItem(QString::number(security));
            securityItem->setTextAlignment(Qt::AlignCenter);
            zoneTable->setItem(i, 6, securityItem);
            
            // Максимальная емкость
            QTableWidgetItem *capacityItem = new QTableWidgetItem(
                QString::number(zone["max_capacity"].toDouble(), 'f', 2));
            capacityItem->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
            zoneTable->setItem(i, 7, capacityItem);
            
            // Текущая загрузка
            QTableWidgetItem *loadItem = new QTableWidgetItem(
                QString::number(zone["current_load"].toDouble(), 'f', 2));
            loadItem->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
            zoneTable->setItem(i, 8, loadItem);
            
            // Загрузка в процентах
            double loadPercent = zone["load_percentage"].toDouble();
            QTableWidgetItem *percentItem = new QTableWidgetItem(
                QString::number(loadPercent, 'f', 1) + " %");
            percentItem->setBackground(getZoneLoadColor(loadPercent));
            percentItem->setTextAlignment(Qt::AlignCenter);
            zoneTable->setItem(i, 9, percentItem);
            
            // Статус
            bool isActive = zone["is_active"].toBool();
            QTableWidgetItem *statusItem = new QTableWidgetItem(isActive ? "✅ Активна" : "❌ Неактивна");
            statusItem->setTextAlignment(Qt::AlignCenter);
            zoneTable->setItem(i, 10, statusItem);
            
            // Количество химикатов
            int chemicalCount = zone["chemical_count"].toInt();
            zoneTable->setItem(i, 11, new QTableWidgetItem(QString::number(chemicalCount)));
        }
        
    } catch (const std::exception &e) {
        showError(QString("Ошибка при загрузке зон хранения:\n%1").arg(e.what()));
    }
}

void MainWindow::updateDistributionTable()
{
    if (!db || !distributionTable) return;
    
    try {
        QList<QMap<QString, QVariant>> batches = db->getAllBatches();
        distributionTable->setRowCount(0);
        distributionTable->setRowCount(batches.size());
        
        for (int i = 0; i < batches.size(); ++i) {
            const auto &batch = batches[i];
            
            // ID
            QTableWidgetItem *idItem = new QTableWidgetItem(batch["id"].toString());
            idItem->setTextAlignment(Qt::AlignCenter);
            distributionTable->setItem(i, 0, idItem);
            
            // Химикат
            distributionTable->setItem(i, 1, new QTableWidgetItem(batch["chemical_name"].toString()));
            
            // Формула (получаем из таблицы chemicals)
            int chemicalId = batch["chemical_id"].toInt();
            QMap<QString, QVariant> chemical = db->getChemicalById(chemicalId);
            QString formula = chemical.value("formula").toString();
            distributionTable->setItem(i, 2, new QTableWidgetItem(formula));
            
            // Зона хранения
            distributionTable->setItem(i, 3, new QTableWidgetItem(batch["zone_name"].toString()));
            
            // Количество
            QTableWidgetItem *qtyItem = new QTableWidgetItem(
                QString::number(batch["quantity"].toDouble(), 'f', 2));
            qtyItem->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
            distributionTable->setItem(i, 4, qtyItem);
            
            // Единица измерения
            QString unit = chemical.value("unit", "г").toString();
            distributionTable->setItem(i, 5, new QTableWidgetItem(unit));
            
            // Дата размещения
            QDate placedDate = batch["placed_date"].toDate();
            distributionTable->setItem(i, 6, new QTableWidgetItem(
                placedDate.toString("dd.MM.yyyy")));
            
            // Срок годности
            QDate expDate = chemical["expiration_date"].toDate();
            distributionTable->setItem(i, 7, new QTableWidgetItem(
                expDate.isValid() ? expDate.toString("dd.MM.yyyy") : "Нет"));
            
            // Примечания
            distributionTable->setItem(i, 8, new QTableWidgetItem(batch["notes"].toString()));
        }
        
    } catch (const std::exception &e) {
        showError(QString("Ошибка при загрузке распределения:\n%1").arg(e.what()));
    }
}

void MainWindow::updateStatistics()
{
    if (!db) return;
    
    try {
        int chemicalCount = db->getChemicalCount();
        int zoneCount = db->getZoneCount();
        
        statTotalChemicals->setText(QString("Химикатов: %1").arg(chemicalCount));
        statTotalZones->setText(QString("Зон хранения: %1").arg(zoneCount));
        
        // Получаем все химикаты для расчета общей массы
        QList<QMap<QString, QVariant>> chemicals = db->getAllChemicals();
        double totalQuantity = 0.0;
        double totalHazard = 0.0;
        int expiringSoon = 0;
        int lowStock = 0;
        
        for (const auto &chem : chemicals) {
            totalQuantity += chem["quantity"].toDouble();
            totalHazard += chem["hazard_class"].toInt();
            
            QDate expDate = chem["expiration_date"].toDate();
            if (expDate.isValid() && expDate <= QDate::currentDate().addDays(30)) {
                expiringSoon++;
            }
            
            if (chem["quantity"].toDouble() < 10.0) {
                lowStock++;
            }
        }
        
        double avgHazard = chemicalCount > 0 ? totalHazard / chemicalCount : 0;
        
        statTotalQuantity->setText(QString("Общее количество: %1 г").arg(totalQuantity, 0, 'f', 2));
        statAverageHazard->setText(QString("Средний класс опасности: %1").arg(avgHazard, 0, 'f', 1));
        statExpiringSoon->setText(QString("Истекает скоро: %1").arg(expiringSoon));
        statLowStock->setText(QString("Низкий запас: %1").arg(lowStock));
        
        // Получаем зоны для анализа загрузки
        QList<QMap<QString, QVariant>> zones = db->getAllStorageZones();
        QString mostLoadedZone = "-";
        QString leastLoadedZone = "-";
        double maxLoad = 0.0;
        double minLoad = 100.0;
        
        for (const auto &zone : zones) {
            double load = zone["load_percentage"].toDouble();
            if (load > maxLoad && zone["is_active"].toBool()) {
                maxLoad = load;
                mostLoadedZone = zone["name"].toString();
            }
            if (load < minLoad && zone["is_active"].toBool()) {
                minLoad = load;
                leastLoadedZone = zone["name"].toString();
            }
        }
        
        statMostLoadedZone->setText(QString("Самая загруженная зона: %1 (%2%)").arg(mostLoadedZone).arg(maxLoad, 0, 'f', 1));
        statLeastLoadedZone->setText(QString("Самая свободная зона: %1 (%2%)").arg(leastLoadedZone).arg(minLoad, 0, 'f', 1));
        
        // Размер базы данных
        QString dbPath = db->getDatabasePath();
        QFileInfo dbFile(dbPath);
        double dbSizeMB = dbFile.size() / (1024.0 * 1024.0);
        statDatabaseSize->setText(QString("Размер БД: %1 МБ").arg(dbSizeMB, 0, 'f', 2));
        
        // Последний бекап
        QList<QMap<QString, QVariant>> backups = db->getAllBackups();
        if (!backups.isEmpty()) {
            QString lastBackup = backups.first()["local_timestamp"].toString();
            statLastBackup->setText(QString("Последний бекап: %1").arg(lastBackup));
        } else {
            statLastBackup->setText("Последний бекап: никогда");
        }
        
    } catch (const std::exception &e) {
        qWarning() << "Error updating statistics:" << e.what();
    }
}

void MainWindow::updateAlerts()
{
    // Базовая реализация
    if (!db || !alertsTable) return;
    
    try {
        QList<QMap<QString, QVariant>> alerts = db->getActiveAlerts();
        alertsTable->setRowCount(0);
        alertsTable->setRowCount(alerts.size());
        
        for (int i = 0; i < alerts.size(); ++i) {
            const auto &alert = alerts[i];
            
            alertsTable->setItem(i, 0, new QTableWidgetItem(alert["id"].toString()));
            alertsTable->setItem(i, 1, new QTableWidgetItem(alert["local_created"].toString()));
            alertsTable->setItem(i, 2, new QTableWidgetItem(alert["alert_type"].toString()));
            alertsTable->setItem(i, 3, new QTableWidgetItem(alert["message"].toString()));
        }
        
    } catch (const std::exception &e) {
        showError(QString("Ошибка при загрузке оповещений:\n%1").arg(e.what()));
    }
}

void MainWindow::updateActivityLog()
{
    if (!db || !activityLogTable) return;
    
    try {
        QList<QMap<QString, QVariant>> logs = db->getDetailedActivityLog(100);
        activityLogTable->setRowCount(0);
        activityLogTable->setRowCount(logs.size());
        
        for (int i = 0; i < logs.size(); ++i) {
            const auto &log = logs[i];
            
            activityLogTable->setItem(i, 0, new QTableWidgetItem(log["id"].toString()));
            activityLogTable->setItem(i, 1, new QTableWidgetItem(log["local_time"].toString()));
            activityLogTable->setItem(i, 2, new QTableWidgetItem(log["user"].toString()));
            activityLogTable->setItem(i, 3, new QTableWidgetItem(log["action"].toString()));
            activityLogTable->setItem(i, 4, new QTableWidgetItem(log["details"].toString()));
        }
        
    } catch (const std::exception &e) {
        showError(QString("Ошибка при загрузке журнала:\n%1").arg(e.what()));
    }
}

// ============ ФУНКЦИИ ХИМИКАТОВ ============

void MainWindow::addChemical()
{
    if (!db) return;
    
    ChemicalDialog dialog(this, db, -1);
    if (dialog.exec() == QDialog::Accepted) {
        updateChemicalTable();
        updateStatistics();
        updateStatus("✅ Химикат успешно добавлен", 2000);
    }
}

void MainWindow::editChemical()
{
    if (!db || !chemicalTable) return;
    
    int id = getSelectedChemicalId();
    if (id <= 0) {
        showError("Пожалуйста, выберите химикат для редактирования");
        return;
    }
    
    ChemicalDialog dialog(this, db, id);
    if (dialog.exec() == QDialog::Accepted) {
        updateChemicalTable();
        updateStatistics();
        updateStatus("✅ Химикат успешно обновлен", 2000);
    }
}

void MainWindow::deleteChemical()
{
    if (!db) return;
    
    int id = getSelectedChemicalId();
    if (id <= 0) {
        showError("Пожалуйста, выберите химикат для удаления");
        return;
    }
    
    QMap<QString, QVariant> chemical = db->getChemicalById(id);
    if (chemical.isEmpty()) {
        showError("Химикат не найден");
        return;
    }
    
    QString name = chemical["name"].toString();
    QString message = QString("Вы уверены, что хотите удалить химикат?\n\n"
                            "Название: %1\n\n"
                            "Это действие нельзя отменить!").arg(name);
    
    QMessageBox::StandardButton reply = QMessageBox::question(
        this, "Подтверждение удаления", message,
        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    
    if (reply == QMessageBox::Yes) {
        if (db->deleteChemical(id)) {
            updateChemicalTable();
            updateDistributionTable();
            updateStatistics();
            updateStatus("✅ Химикат успешно удален", 2000);
        } else {
            showError("Не удалось удалить химикат: " + db->getLastError());
        }
    }
}

void MainWindow::searchChemicals()
{
    updateChemicalTable();
}

void MainWindow::exportChemicalsToCSV()
{
    if (!db) return;
    
    QString fileName = QFileDialog::getSaveFileName(
        this, "Экспорт химикатов в CSV", 
        QDir::homePath() + "/chemicals_export.csv",
        "CSV файлы (*.csv);;Все файлы (*.*)");
    
    if (fileName.isEmpty()) return;
    
    if (!fileName.endsWith(".csv", Qt::CaseInsensitive)) {
        fileName += ".csv";
    }
    
    progressBar->setVisible(true);
    progressBar->setRange(0, 0);
    
    QTimer::singleShot(100, this, [this, fileName]() {
        if (db->exportChemicalsToCSV(fileName)) {
            showSuccess(QString("Химикаты успешно экспортированы в файл:\n%1").arg(fileName));
        } else {
            showError("Не удалось экспортировать химикаты: " + db->getLastError());
        }
        
        progressBar->setVisible(false);
    });
}

void MainWindow::showChemicalDetails()
{
    if (!db) return;
    
    int id = getSelectedChemicalId();
    if (id <= 0) {
        showError("Пожалуйста, выберите химикат для просмотра деталей");
        return;
    }
    
    QMap<QString, QVariant> chemical = db->getChemicalById(id);
    if (chemical.isEmpty()) {
        showError("Химикат не найден");
        return;
    }
    
    QString details = QString("🧪 Химикат: %1\n"
                             "Формула: %2\n"
                             "CAS: %3\n"
                             "Количество: %4 %5\n"
                             "Класс опасности: %6\n"
                             "Производитель: %7\n"
                             "Срок годности: %8")
                             .arg(chemical["name"].toString())
                             .arg(chemical["formula"].toString())
                             .arg(chemical["cas_number"].toString())
                             .arg(chemical["quantity"].toDouble())
                             .arg(chemical["unit"].toString())
                             .arg(chemical["hazard_class"].toString())
                             .arg(chemical["manufacturer"].toString())
                             .arg(chemical["expiration_date"].toDate().toString("dd.MM.yyyy"));
    
    QMessageBox::information(this, "Детали химиката", details);
}

void MainWindow::showChemicalContextMenu(const QPoint &pos)
{
    if (!chemicalTable) return;
    
    QModelIndex index = chemicalTable->indexAt(pos);
    
    if (index.isValid()) {
        QMenu menu(this);
        
        menu.addAction("✏️ Редактировать", this, &MainWindow::editChemical);
        menu.addAction("🗑️ Удалить", this, &MainWindow::deleteChemical);
        menu.addSeparator();
        menu.addAction("🔍 Подробности", this, &MainWindow::showChemicalDetails);
        
        menu.exec(chemicalTable->viewport()->mapToGlobal(pos));
    }
}

void MainWindow::chemicalCellDoubleClicked(int row, int column)
{
    Q_UNUSED(column);
    if (chemicalTable) {
        chemicalTable->setCurrentCell(row, 0);
        editChemical();
    }
}

// ============ ФУНКЦИИ ЗОН ХРАНЕНИЯ ============

void MainWindow::addStorageZone()
{
    if (!db) return;
    
    ZoneDialog dialog(this, db, -1);
    if (dialog.exec() == QDialog::Accepted) {
        updateZoneTable();
        updateStatistics();
        updateStatus("✅ Зона хранения успешно добавлена", 2000);
    }
}

void MainWindow::editStorageZone()
{
    if (!db || !zoneTable) return;
    
    int id = getSelectedZoneId();
    if (id <= 0) {
        showError("Пожалуйста, выберите зону хранения для редактирования");
        return;
    }
    
    ZoneDialog dialog(this, db, id);
    if (dialog.exec() == QDialog::Accepted) {
        updateZoneTable();
        updateStatistics();
        updateStatus("✅ Зона хранения успешно обновлена", 2000);
    }
}

void MainWindow::deleteStorageZone()
{
    if (!db) return;
    
    int id = getSelectedZoneId();
    if (id <= 0) {
        showError("Пожалуйста, выберите зону хранения для удаления");
        return;
    }
    
    QMap<QString, QVariant> zone = db->getZoneById(id);
    if (zone.isEmpty()) {
        showError("Зона не найдена");
        return;
    }
    
    QString name = zone["name"].toString();
    QString message = QString("Вы уверены, что хотите удалить зону хранения?\n\n"
                            "Название: %1\n\n"
                            "Это действие нельзя отменить!").arg(name);
    
    QMessageBox::StandardButton reply = QMessageBox::question(
        this, "Подтверждение удаления", message,
        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    
    if (reply == QMessageBox::Yes) {
        if (db->deleteZone(id)) {
            updateZoneTable();
            updateStatistics();
            updateStatus("✅ Зона хранения успешно удалена", 2000);
        } else {
            showError("Не удалось удалить зону: " + db->getLastError());
        }
    }
}

void MainWindow::showZoneContextMenu(const QPoint &pos)
{
    if (!zoneTable) return;
    
    QModelIndex index = zoneTable->indexAt(pos);
    
    if (index.isValid()) {
        QMenu menu(this);
        
        menu.addAction("✏️ Редактировать", this, &MainWindow::editStorageZone);
        menu.addAction("🗑️ Удалить", this, &MainWindow::deleteStorageZone);
        
        menu.exec(zoneTable->viewport()->mapToGlobal(pos));
    }
}

void MainWindow::zoneCellDoubleClicked(int row, int column)
{
    Q_UNUSED(column);
    if (zoneTable) {
        zoneTable->setCurrentCell(row, 0);
        editStorageZone();
    }
}

// ============ ФУНКЦИИ РАСПРЕДЕЛЕНИЯ ============

void MainWindow::distributeChemical()
{
    if (!db) return;
    
    DistributeDialog dialog(this, db);
    if (dialog.exec() == QDialog::Accepted) {
        updateChemicalTable();
        updateZoneTable();
        updateDistributionTable();
        updateStatistics();
        updateStatus("✅ Химикат успешно распределен", 2000);
    }
}

void MainWindow::removeDistribution()
{
    if (!db) return;
    
    int id = getSelectedBatchId();
    if (id <= 0) {
        showError("Пожалуйста, выберите распределение для удаления");
        return;
    }
    
    QMap<QString, QVariant> batch = db->getBatchById(id);
    if (batch.isEmpty()) {
        showError("Распределение не найдено");
        return;
    }
    
    QString chemicalName = batch["chemical_name"].toString();
    QString zoneName = batch["zone_name"].toString();
    double quantity = batch["quantity"].toDouble();
    
    QString message = QString("Вы уверены, что хотите удалить распределение?\n\n"
                            "Химикат: %1\n"
                            "Зона: %2\n"
                            "Количество: %3")
                            .arg(chemicalName)
                            .arg(zoneName)
                            .arg(quantity);
    
    QMessageBox::StandardButton reply = QMessageBox::question(
        this, "Подтверждение удаления", message,
        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    
    if (reply == QMessageBox::Yes) {
        if (db->removeFromZone(id, quantity)) {
            updateChemicalTable();
            updateZoneTable();
            updateDistributionTable();
            updateStatistics();
            updateStatus("✅ Распределение успешно удалено", 2000);
        } else {
            showError("Не удалось удалить распределение: " + db->getLastError());
        }
    }
}

void MainWindow::showDistributionContextMenu(const QPoint &pos)
{
    if (!distributionTable) return;
    
    QModelIndex index = distributionTable->indexAt(pos);
    
    if (index.isValid()) {
        QMenu menu(this);
        
        menu.addAction("↩️ Удалить распределение", this, &MainWindow::removeDistribution);
        
        menu.exec(distributionTable->viewport()->mapToGlobal(pos));
    }
}

// ============ СИСТЕМНЫЕ ФУНКЦИИ ============

void MainWindow::backupDatabase()
{
    if (!db) return;
    
    BackupDialog dialog(this, db, false);
    dialog.exec();
}

void MainWindow::restoreDatabase()
{
    if (!db) return;
    
    BackupDialog dialog(this, db);
    if (dialog.exec() == QDialog::Accepted) {
        refreshAll();
        updateStatus("✅ База данных успешно восстановлена", 3000);
    }
}

void MainWindow::manageBackups()
{
    if (!db) return;
    
    BackupDialog dialog(this, db, true);
    dialog.exec();
}

void MainWindow::exportToCSV()
{
    if (!db) return;
    
    QString fileName = QFileDialog::getSaveFileName(
        this, "Экспорт всех данных в CSV", 
        QDir::homePath() + "/chemical_lab_full_export.csv",
        "CSV файлы (*.csv);;Все файлы (*.*)");
    
    if (fileName.isEmpty()) return;
    
    if (!fileName.endsWith(".csv", Qt::CaseInsensitive)) {
        fileName += ".csv";
    }
    
    progressBar->setVisible(true);
    progressBar->setRange(0, 0);
    
    QTimer::singleShot(100, this, [this, fileName]() {
        if (db->exportToCSV(fileName)) {
            showSuccess(QString("Все данные успешно экспортированы в файл:\n%1").arg(fileName));
        } else {
            showError("Не удалось экспортировать данные: " + db->getLastError());
        }
        
        progressBar->setVisible(false);
    });
}

void MainWindow::importFromCSV()
{
    if (!db) return;
    
    QString fileName = QFileDialog::getOpenFileName(
        this, "Импорт данных из CSV",
        QDir::homePath(),
        "CSV файлы (*.csv);;Все файлы (*.*)");
    
    if (fileName.isEmpty()) return;
    
    // Простая реализация импорта
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        showError("Не удалось открыть файл: " + file.errorString());
        return;
    }
    
    QTextStream in(&file);
    QString header = in.readLine(); // Пропускаем заголовок
    
    int importedCount = 0;
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList fields = line.split(',');
        
        if (fields.size() >= 2) {
            QMap<QString, QVariant> data;
            data["name"] = fields[0].trimmed();
            data["quantity"] = fields.size() > 1 ? fields[1].toDouble() : 0.0;
            data["unit"] = "г";
            data["hazard_class"] = 3;
            
            if (db->addChemical(data)) {
                importedCount++;
            }
        }
    }
    
    file.close();
    
    if (importedCount > 0) {
        updateStatus(QString("Импортировано %1 записей из CSV").arg(importedCount), 3000);
        refreshAll();
    }
}

void MainWindow::showSettings()
{
    if (!db) return;
    
    SettingsDialog dialog(this, db);
    dialog.exec();
}

// ============ УТИЛИТЫ ============


void MainWindow::showError(const QString &message)
{
    QMessageBox::critical(this, "❌ Ошибка", message);
    updateStatus("❌ " + message, 5000);
}

void MainWindow::showInfo(const QString &message)
{
    QMessageBox::information(this, "ℹ️ Информация", message);
}

void MainWindow::showSuccess(const QString &message)
{
    QMessageBox::information(this, "✅ Успех", message);
    updateStatus("✅ " + message, 3000);
}

QColor MainWindow::getHazardClassColor(int hazardClass) const
{
    switch (hazardClass) {
    case 1: return QColor(255, 0, 0, 100);
    case 2: return QColor(255, 165, 0, 100);
    case 3: return QColor(255, 255, 0, 100);
    case 4: return QColor(0, 255, 0, 100);
    case 5: return QColor(0, 0, 255, 50);
    default: return Qt::white;
    }
}

QString MainWindow::getHazardClassTooltip(int hazardClass) const
{
    switch (hazardClass) {
    case 1: return "1 - Чрезвычайно опасный";
    case 2: return "2 - Высокоопасный";
    case 3: return "3 - Умеренно опасный";
    case 4: return "4 - Малоопасный";
    case 5: return "5 - Практически неопасный";
    default: return "Неизвестный класс опасности";
    }
}

QColor MainWindow::getZoneLoadColor(double loadPercent) const
{
    if (loadPercent > 90) return QColor(255, 0, 0, 100);
    if (loadPercent > 70) return QColor(255, 165, 0, 100);
    if (loadPercent > 50) return QColor(255, 255, 0, 100);
    return QColor(0, 255, 0, 100);
}

QColor MainWindow::getAlertSeverityColor(int severity) const
{
    switch (severity) {
    case 1: return QColor(144, 238, 144, 100);
    case 2: return QColor(255, 255, 0, 100);
    case 3: return QColor(255, 0, 0, 100);
    default: return Qt::white;
    }
}

int MainWindow::getSelectedChemicalId() const
{
    if (!chemicalTable) return -1;
    
    QList<QTableWidgetItem*> selected = chemicalTable->selectedItems();
    if (selected.isEmpty()) return -1;
    
    int row = selected.first()->row();
    QTableWidgetItem *idItem = chemicalTable->item(row, 0);
    return idItem ? idItem->text().toInt() : -1;
}

int MainWindow::getSelectedZoneId() const
{
    if (!zoneTable) return -1;
    
    QList<QTableWidgetItem*> selected = zoneTable->selectedItems();
    if (selected.isEmpty()) return -1;
    
    int row = selected.first()->row();
    QTableWidgetItem *idItem = zoneTable->item(row, 0);
    return idItem ? idItem->text().toInt() : -1;
}

int MainWindow::getSelectedBatchId() const
{
    if (!distributionTable) return -1;
    
    QList<QTableWidgetItem*> selected = distributionTable->selectedItems();
    if (selected.isEmpty()) return -1;
    
    int row = selected.first()->row();
    QTableWidgetItem *idItem = distributionTable->item(row, 0);
    return idItem ? idItem->text().toInt() : -1;
}

int MainWindow::getSelectedAlertId() const
{
    if (!alertsTable) return -1;
    
    QList<QTableWidgetItem*> selected = alertsTable->selectedItems();
    if (selected.isEmpty()) return -1;
    
    int row = selected.first()->row();
    QTableWidgetItem *idItem = alertsTable->item(row, 0);
    return idItem ? idItem->text().toInt() : -1;
}

void MainWindow::tabChanged(int index)
{
    switch (index) {
    case 0: updateChemicalTable(); break;
    case 1: updateZoneTable(); break;
    case 2: updateDistributionTable(); break;
    case 3: updateStatistics(); break;
    case 4: updateAlerts(); break;
    case 5: updateActivityLog(); break;
    }
}

void MainWindow::exportStatistics()
{
    // Базовая реализация
    QMessageBox::information(this, "Экспорт статистики", "Функция экспорта статистики будет реализована в следующей версии");
}

void MainWindow::markAlertAsResolved()
{
    if (!db) return;
    
    int id = getSelectedAlertId();
    if (id <= 0) {
        showError("Пожалуйста, выберите оповещение для отметки как решенное");
        return;
    }
    
    if (db->markAlertAsResolved(id, "пользователь")) {
        updateAlerts();
        updateStatistics();
        updateStatus("✅ Оповещение отмечено как решенное", 2000);
    } else {
        showError("Не удалось отметить оповещение как решенное: " + db->getLastError());
    }
}

void MainWindow::showAlertContextMenu(const QPoint &pos)
{
    if (!alertsTable) return;
    
    QModelIndex index = alertsTable->indexAt(pos);
    
    if (index.isValid()) {
        QMenu menu(this);
        
        menu.addAction("✅ Решено", this, &MainWindow::markAlertAsResolved);
        
        menu.exec(alertsTable->viewport()->mapToGlobal(pos));
    }
}

void MainWindow::clearOldLogs()
{
    if (!db) return;
    
    QMessageBox::StandardButton reply = QMessageBox::question(
        this, "Очистка журнала",
        "Вы уверены, что хотите очистить старые записи журнала (старше 30 дней)?",
        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    
    if (reply == QMessageBox::Yes) {
        if (db->clearOldLogs(30)) {
            updateActivityLog();
            updateStatus("✅ Старые записи журнала очищены", 2000);
        } else {
            showError("Не удалось очистить журнал: " + db->getLastError());
        }
    }
}

void MainWindow::showAbout()
{
    QMessageBox::about(this, "О программе",
        "<html>"
        "<h2>Химическая Лаборатория v2.1</h2>"
        "<p><b>Полная система управления химическими реактивами</b></p>"
        "<p>Версия: 2.1.0</p>"
        "<p>© 2024 ChemicalLab Systems</p>"
        "<hr>"
        "<h3>Функции:</h3>"
        "<ul>"
        "<li>🧪 Управление химикатами</li>"
        "<li>🏢 Управление зонами хранения</li>"
        "<li>📦 Распределение химикатов</li>"
        "<li>📊 Статистика и отчеты</li>"
        "<li>⚠️ Система оповещений</li>"
        "<li>💾 Резервное копирование</li>"
        "<li>📤 Экспорт данных</li>"
        "<li>⚙️ Настройки и темы оформления</li>"
        "</ul>"
        "<p><i>Профессиональное решение для лабораторий</i></p>"
        "</html>");
}
void MainWindow::createStatusBar()
{
    QStatusBar *statusBarWidget = QMainWindow::statusBar();
    
    statusLabel = new QLabel("Готов");
    statusBarWidget->addWidget(statusLabel);
    
    progressBar = new QProgressBar();
    progressBar->setMaximumWidth(200);
    progressBar->setVisible(false);
    statusBarWidget->addWidget(progressBar);
    
    QLabel *dbStatus = new QLabel("🟢 База данных подключена");
    statusBarWidget->addPermanentWidget(dbStatus);
}

void MainWindow::updateStatus(const QString &message, int timeout)
{
    QStatusBar *statusBarWidget = QMainWindow::statusBar();
    
    if (statusLabel) {
        statusLabel->setText(message);
    }
    if (timeout > 0) {
        statusBarWidget->showMessage(message, timeout);
    }
}
