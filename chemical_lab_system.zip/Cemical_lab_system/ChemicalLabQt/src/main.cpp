#include <QApplication>
#include <QStyleFactory>
#include <QFont>
#include <QDebug>
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    
    // Настройка стиля
    app.setStyle(QStyleFactory::create("Fusion"));
    
    // Настройка шрифтов
    QFont font("Arial", 10);
    app.setFont(font);
    
    // Настройка приложения
    app.setApplicationName("Химическая Лаборатория");
    app.setApplicationVersion("2.1.0");
    app.setOrganizationName("ChemicalLab");
    
    // Создаем главное окно
    MainWindow window;
    window.show();
    
    return app.exec();
}
