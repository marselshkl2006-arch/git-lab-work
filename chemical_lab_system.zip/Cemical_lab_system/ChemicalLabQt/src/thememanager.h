#ifndef THEMEMANAGER_H
#define THEMEMANAGER_H

#include <QObject>
#include <QString>
#include <QMap>

class ThemeManager : public QObject
{
    Q_OBJECT
    
public:
    static ThemeManager& instance();
    
    QStringList getAvailableThemes() const;
    QString getCurrentTheme() const;
    void applyTheme(const QString &themeName);
    void loadThemeFromSettings();
    
    QMap<QString, QString> getThemeStyles() const;
    
signals:
    void themeChanged(const QString &themeName);
    
private:
    ThemeManager(QObject *parent = nullptr);
    ThemeManager(const ThemeManager&) = delete;
    ThemeManager& operator=(const ThemeManager&) = delete;
    
    QString m_currentTheme;
    QMap<QString, QString> m_themeStyles;
    
    void loadThemes();
};

#endif // THEMEMANAGER_H
