#ifndef SETTINGSDIALOG_H
#define SETTINGSDIALOG_H

#include <QDialog>

QT_BEGIN_NAMESPACE
class QComboBox;
QT_END_NAMESPACE

class Database;

class SettingsDialog : public QDialog
{
    Q_OBJECT
    
public:
    SettingsDialog(QWidget *parent, Database *db);
    
private slots:
    void applySettings();
    
private:
    Database *m_db;
    QComboBox *themeCombo;
};

#endif // SETTINGSDIALOG_H
