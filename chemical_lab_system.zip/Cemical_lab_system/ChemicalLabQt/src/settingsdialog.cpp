#include "settingsdialog.h"
#include "database.h"
#include "thememanager.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QGroupBox>
#include <QComboBox>
#include <QLabel>
#include <QPushButton>
#include <QMessageBox>

SettingsDialog::SettingsDialog(QWidget *parent, Database *db)
    : QDialog(parent), m_db(db)
{
    setWindowTitle("⚙️ Настройки");
    setMinimumWidth(400);
    
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    
    // Настройки темы
    QGroupBox *themeGroup = new QGroupBox("🎨 Тема оформления");
    QFormLayout *themeLayout = new QFormLayout(themeGroup);
    
    themeCombo = new QComboBox();
    themeCombo->addItems(ThemeManager::instance().getAvailableThemes());
    themeCombo->setCurrentText(ThemeManager::instance().getCurrentTheme());
    
    themeLayout->addRow("Тема:", themeCombo);
    mainLayout->addWidget(themeGroup);
    
    // Кнопки
    QHBoxLayout *buttonLayout = new QHBoxLayout();
    QPushButton *applyButton = new QPushButton("💾 Применить");
    QPushButton *cancelButton = new QPushButton("❌ Отмена");
    
    buttonLayout->addStretch();
    buttonLayout->addWidget(applyButton);
    buttonLayout->addWidget(cancelButton);
    
    mainLayout->addLayout(buttonLayout);
    
    // Подключаем сигналы
    connect(applyButton, &QPushButton::clicked, this, &SettingsDialog::applySettings);
    connect(cancelButton, &QPushButton::clicked, this, &QDialog::reject);
}

void SettingsDialog::applySettings()
{
    // Применяем тему
    ThemeManager::instance().applyTheme(themeCombo->currentText());
    
    QMessageBox::information(this, "Настройки", "Настройки успешно применены");
    accept();
}
