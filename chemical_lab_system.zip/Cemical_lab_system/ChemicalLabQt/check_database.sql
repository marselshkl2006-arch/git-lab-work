-- Проверка структуры БД
SELECT '=== СТРУКТУРА БАЗЫ ДАННЫХ ===';

SELECT 'Таблицы:' as " ";
SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;

SELECT '';
SELECT '=== ХИМИКАТЫ ===';
SELECT COUNT(*) as "Всего записей" FROM chemicals;
SELECT * FROM chemicals LIMIT 3;

SELECT '';
SELECT '=== ЗОНЫ ХРАНЕНИЯ ===';
SELECT * FROM storage_zones;

SELECT '';
SELECT '=== РАЗМЕЩЕНИЯ ===';
SELECT COUNT(*) as "Всего размещений" FROM batches;
SELECT * FROM batches LIMIT 3;

SELECT '';
SELECT '=== ПРОВЕРКА ЦЕЛОСТНОСТИ ===';
SELECT 'Зоны с перегрузкой:' as " ", 
    CASE WHEN EXISTS(
        SELECT 1 FROM storage_zones WHERE current_load > max_capacity
    ) THEN 'ДА' ELSE 'НЕТ' END as result;
    
SELECT 'Химикаты без типа:' as " ",
    COUNT(*) as count FROM chemicals WHERE type IS NULL OR type = '';
