#!/bin/bash
echo "🧪 Сборка Химической Лаборатории..."
echo ""

# Создаем директорию сборки
mkdir -p build
cd build

# Конфигурация CMake
echo "⚙️  Конфигурируем проект..."
cmake ..

# Сборка
echo "🔧 Компилируем..."
make

# Проверка результата
if [ -f "ChemicalLabQt" ]; then
    echo ""
    echo "✅ СБОРКА УСПЕШНА!"
    echo ""
    echo "🚀 Запуск: ./ChemicalLabQt"
    echo ""
    
    # Запускаем если передано run
    if [ "$1" = "run" ]; then
        ./ChemicalLabQt
    fi
else
    echo "❌ Ошибка сборки!"
    exit 1
fi
