#!/bin/bash
echo "🔧 Тестовый запуск программы..."
echo ""

# Убедимся что есть билд
if [ ! -d "build" ]; then
    mkdir build
fi

cd build

# Очищаем и пересобираем
echo "🧹 Очистка..."
rm -rf *
echo ""

echo "🔨 CMake..."
cmake .. 2>&1 | grep -i "error\|warning\|found\|using"
echo ""

echo "📦 Компиляция..."
make -j4 2>&1 | tail -20
echo ""

if [ -f "ChemicalLabQt" ]; then
    echo "✅ Программа собрана!"
    echo "🚀 Запуск с выводом логов..."
    echo "========================================"
    
    # Запускаем с перенаправлением stderr в stdout
    ./ChemicalLabQt 2>&1
else
    echo "❌ Ошибка сборки!"
    exit 1
fi
