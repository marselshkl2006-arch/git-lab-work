#!/bin/bash
cd "$(dirname "$0")"

if [ -f "build/ChemicalLabQt" ]; then
    echo "🚀 Запуск Химической Лаборатории v2.1..."
    cd build && ./ChemicalLabQt
else
    echo "❌ Исполняемый файл не найден!"
    echo "Сначала выполните сборку:"
    echo "./build_and_run.sh"
    exit 1
fi
