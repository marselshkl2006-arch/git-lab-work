#include "safetychecker.h"
#include <QSqlQuery>
#include <QDate>

SafetyChecker::SafetyChecker(Database *db, QObject *parent)
    : QObject(parent), m_db(db)
{
}

QList<SafetyAlert> SafetyChecker::checkAll()
{
    QList<SafetyAlert> alerts;
    
    // 1. Проверка истекающих сроков
    alerts.append(checkExpiringBatches());
    
    // 2. Проверка перегруженных зон
    alerts.append(checkOverloadedZones());
    
    // 3. Проверка температурного режима
    alerts.append(checkTemperatureViolations());
    
    // 4. Проверка совместимости
    alerts.append(checkCompatibility());
    
    return alerts;
}

QList<SafetyAlert> SafetyChecker::checkExpiringBatches(int daysThreshold)
{
    QList<SafetyAlert> alerts;
    
    QSqlQuery query;
    query.prepare(
        "SELECT b.id, c.name, b.expiration_date, "
        "julianday(b.expiration_date) - julianday('now') as days_left "
        "FROM batches b "
        "JOIN chemicals c ON b.chemical_id = c.id "
        "WHERE days_left <= :threshold AND days_left >= 0 "
        "ORDER BY days_left"
    );
    query.bindValue(":threshold", daysThreshold);
    
    if (query.exec()) {
        while (query.next()) {
            SafetyAlert alert;
            alert.type = "Истекающий срок";
            alert.severity = query.value(3).toInt() <= 7 ? "КРИТИЧЕСКИЙ" : "ВНИМАНИЕ";
            alert.message = QString("%1 истекает через %2 дней (%3)")
                               .arg(query.value(1).toString())
                               .arg(query.value(3).toInt())
                               .arg(query.value(2).toString());
            alert.entityId = query.value(0).toInt();
            alert.entityType = "batch";
            alerts.append(alert);
        }
    }
    
    return alerts;
}

QList<SafetyAlert> SafetyChecker::checkOverloadedZones(double thresholdPercent)
{
    QList<SafetyAlert> alerts;
    
    QSqlQuery query;
    query.prepare(
        "SELECT id, name, current_load, max_capacity, "
        "ROUND((current_load * 100.0 / max_capacity), 1) as percent "
        "FROM storage_zones "
        "WHERE (current_load * 100.0 / max_capacity) >= :threshold "
        "ORDER BY percent DESC"
    );
    query.bindValue(":threshold", thresholdPercent);
    
    if (query.exec()) {
        while (query.next()) {
            SafetyAlert alert;
            alert.type = "Перегруженная зона";
            alert.severity = query.value(4).toDouble() >= 95 ? "КРИТИЧЕСКИЙ" : "ВНИМАНИЕ";
            alert.message = QString("Зона '%1' заполнена на %2% (%3/%4)")
                               .arg(query.value(1).toString())
                               .arg(query.value(4).toString())
                               .arg(query.value(2).toString())
                               .arg(query.value(3).toString());
            alert.entityId = query.value(0).toInt();
            alert.entityType = "zone";
            alerts.append(alert);
        }
    }
    
    return alerts;
}

QList<SafetyAlert> SafetyChecker::checkTemperatureViolations(double maxDiff)
{
    QList<SafetyAlert> alerts;
    
    QSqlQuery query;
    query.prepare(
        "SELECT p.id, c.name, c.storage_temp, z.name as zone_name, z.temperature as zone_temp, "
        "ROUND(ABS(c.storage_temp - z.temperature), 1) as diff "
        "FROM placements p "
        "JOIN batches b ON p.batch_id = b.id "
        "JOIN chemicals c ON b.chemical_id = c.id "
        "JOIN storage_zones z ON p.zone_id = z.id "
        "WHERE ABS(c.storage_temp - z.temperature) > :maxDiff "
        "ORDER BY diff DESC"
    );
    query.bindValue(":maxDiff", maxDiff);
    
    if (query.exec()) {
        while (query.next()) {
            SafetyAlert alert;
            alert.type = "Температурное нарушение";
            alert.severity = "ВНИМАНИЕ";
            alert.message = QString("%1 хранится при %2°C вместо требуемых %3°C (зона: %4)")
                               .arg(query.value(1).toString())
                               .arg(query.value(4).toString())
                               .arg(query.value(2).toString())
                               .arg(query.value(3).toString());
            alert.entityId = query.value(0).toInt();
            alert.entityType = "placement";
            alerts.append(alert);
        }
    }
    
    return alerts;
}