#include "chemicalmodel.h"
#include <QBrush>
#include <QColor>

ChemicalModel::ChemicalModel(Database *db, QObject *parent)
    : QAbstractTableModel(parent), m_db(db)
{
    refresh();
}

int ChemicalModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    return m_chemicals.size();
}

int ChemicalModel::columnCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    return 9; // ID, Название, Формула, Тип, Класс, Температура, Количество, Единица, Контейнер
}

QVariant ChemicalModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() >= m_chemicals.size())
        return QVariant();

    const Chemical &chem = m_chemicals.at(index.row());

    if (role == Qt::DisplayRole) {
        switch (index.column()) {
            case 0: return chem.id;
            case 1: return chem.name;
            case 2: return chem.formula;
            case 3: return chem.type;
            case 4: return chem.dangerClass;
            case 5: return QString("%1°C").arg(chem.storageTemp);
            case 6: return chem.quantity;
            case 7: return chem.unit;
            case 8: return chem.container;
        }
    } else if (role == Qt::BackgroundRole) {
        // Цвет фона в зависимости от класса опасности
        switch (chem.dangerClass) {
            case 1: return QBrush(QColor(255, 200, 200)); // Красный
            case 2: return QBrush(QColor(255, 225, 200)); // Оранжевый
            case 3: return QBrush(QColor(255, 255, 200)); // Желтый
            case 4: return QBrush(QColor(200, 255, 200)); // Зеленый
            case 5: return QBrush(QColor(200, 200, 255)); // Синий
        }
    } else if (role == Qt::ToolTipRole) {
        return QString("Добавлен: %1\nКонтейнер: %2").arg(chem.createdAt).arg(chem.container);
    }

    return QVariant();
}

QVariant ChemicalModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole) {
        switch (section) {
            case 0: return "ID";
            case 1: return "Название";
            case 2: return "Формула";
            case 3: return "Тип";
            case 4: return "Класс";
            case 5: return "Температура";
            case 6: return "Количество";
            case 7: return "Единица";
            case 8: return "Контейнер";
        }
    }
    return QVariant();
}

void ChemicalModel::refresh()
{
    beginResetModel();
    m_chemicals = m_db->getAllChemicals();
    endResetModel();
}

Chemical ChemicalModel::getChemicalAt(int row) const
{
    if (row >= 0 && row < m_chemicals.size()) {
        return m_chemicals.at(row);
    }
    return Chemical();
}