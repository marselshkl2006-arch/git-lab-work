#ifndef CHEMICALMODEL_H
#define CHEMICALMODEL_H

#include <QAbstractTableModel>
#include <QVector>
#include "database.h"

class ChemicalModel : public QAbstractTableModel
{
    Q_OBJECT

public:
    explicit ChemicalModel(Database *db, QObject *parent = nullptr);
    
    // Переопределение методов модели
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    int columnCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    QVariant headerData(int section, Qt::Orientation orientation, int role) const override;
    
    // Обновление данных
    void refresh();
    Chemical getChemicalAt(int row) const;

private:
    Database *m_db;
    QVector<Chemical> m_chemicals;
};

#endif // CHEMICALMODEL_H