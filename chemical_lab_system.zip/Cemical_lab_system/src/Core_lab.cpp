#include <iostream>
#include <string>
#include <sqlite3.h>
#include <iomanip>
#include <ctime>
#include <cmath>
#include <vector>
#include <ncurses.h>

using namespace std;

// ==================== КЛАСС ДЛЯ РАБОТЫ С БАЗОЙ ДАННЫХ ====================

class Database {
private:
    sqlite3* db;
    
public:
    Database(const string& filename) : db(nullptr) {
        if (sqlite3_open(filename.c_str(), &db) != SQLITE_OK) {
            throw runtime_error("Не удалось открыть базу данных!");
        }
        executeSQL("PRAGMA foreign_keys = ON;");
    }
    
    ~Database() {
        if (db) sqlite3_close(db);
    }
    
    bool executeSQL(const string& sql) {
        char* errMsg = nullptr;
        if (sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg) != SQLITE_OK) {
            // Не выводим ошибки в ncurses режиме
            if (errMsg) sqlite3_free(errMsg);
            return false;
        }
        return true;
    }
    
    sqlite3* getHandle() { return db; }
    
    vector<vector<string>> query(const string& sql) {
        vector<vector<string>> results;
        sqlite3_stmt* stmt;
        
        if (sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr) == SQLITE_OK) {
            int cols = sqlite3_column_count(stmt);
            
            while (sqlite3_step(stmt) == SQLITE_ROW) {
                vector<string> row;
                for (int i = 0; i < cols; i++) {
                    const char* text = (const char*)sqlite3_column_text(stmt, i);
                    row.push_back(text ? text : "");
                }
                results.push_back(row);
            }
            sqlite3_finalize(stmt);
        }
        return results;
    }
};

// ==================== КЛАСС ДЛЯ ИНТЕРФЕЙСА NCURSES ====================

class NCursesUI {
private:
    int screenWidth, screenHeight;
    
    void initColors() {
        start_color();
        init_pair(1, COLOR_WHITE, COLOR_BLUE);    // Header
        init_pair(2, COLOR_GREEN, COLOR_BLACK);   // Success
        init_pair(3, COLOR_RED, COLOR_BLACK);     // Error
        init_pair(4, COLOR_YELLOW, COLOR_BLACK);  // Warning
        init_pair(5, COLOR_CYAN, COLOR_BLACK);    // Info
        init_pair(6, COLOR_MAGENTA, COLOR_BLACK); // Highlight
        init_pair(7, COLOR_BLACK, COLOR_WHITE);   // Selected item
    }
    
public:
    NCursesUI() {
        initscr();
        raw();
        keypad(stdscr, TRUE);
        noecho();
        curs_set(0);
        
        getmaxyx(stdscr, screenHeight, screenWidth);
        initColors();
    }
    
    ~NCursesUI() {
        endwin();
    }
    
    void clearScreen() {
        clear();
    }
    
    void drawHeader(const string& title) {
        attron(COLOR_PAIR(1));
        mvhline(0, 0, ' ', screenWidth);
        mvprintw(0, (screenWidth - title.length()) / 2, "%s", title.c_str());
        attroff(COLOR_PAIR(1));
        
        mvhline(2, 0, '-', screenWidth);
        refresh();
    }
    
    void drawFooter(const string& message) {
        mvhline(screenHeight - 2, 0, '-', screenWidth);
        mvprintw(screenHeight - 1, 0, " %s", message.c_str());
        refresh();
    }
    
    int showMenu(const string& title, const vector<string>& options) {
        int selected = 0;
        int startY = 5;
        
        while (true) {
            clearScreen();
            drawHeader("СИСТЕМА УПРАВЛЕНИЯ ХИМИЧЕСКОЙ ЛАБОРАТОРИЕЙ");
            
            // Отображаем заголовок меню
            attron(A_BOLD);
            mvprintw(startY - 2, (screenWidth - title.length()) / 2, "%s", title.c_str());
            attroff(A_BOLD);
            
            // Отображаем опции
            for (size_t i = 0; i < options.size(); i++) {
                int x = screenWidth / 3;
                int y = startY + i * 2;
                
                if (i == selected) {
                    attron(COLOR_PAIR(7));
                    mvprintw(y, x - 2, "> ");
                    mvprintw(y, x, "%s", options[i].c_str());
                    mvprintw(y, x + options[i].length() + 2, " <");
                    attroff(COLOR_PAIR(7));
                } else {
                    mvprintw(y, x, "%s", options[i].c_str());
                }
            }
            
            drawFooter("↑↓ - Выбор, Enter - Подтвердить, ESC - Выход");
            
            int ch = getch();
            switch (ch) {
                case KEY_UP:
                    selected = (selected > 0) ? selected - 1 : options.size() - 1;
                    break;
                case KEY_DOWN:
                    selected = (selected < (int)options.size() - 1) ? selected + 1 : 0;
                    break;
                case 10: // Enter
                    return selected;
                case 27: // ESC
                    return -1;
            }
        }
    }
    
    string getInput(const string& prompt, int y) {
        echo();
        curs_set(1);
        
        mvprintw(y, 2, "%s:", prompt.c_str());
        char input[256];
        mvgetnstr(y, prompt.length() + 4, input, 255);
        
        noecho();
        curs_set(0);
        
        return string(input);
    }
    
    void showMessage(const string& message, int colorPair = 2) {
        clearScreen();
        drawHeader("СИСТЕМА УПРАВЛЕНИЯ ХИМИЧЕСКОЙ ЛАБОРАТОРИЕЙ");
        
        attron(COLOR_PAIR(colorPair));
        mvprintw(screenHeight / 2, (screenWidth - message.length()) / 2, "%s", message.c_str());
        attroff(COLOR_PAIR(colorPair));
        
        drawFooter("Нажмите любую клавишу для продолжения...");
        getch();
    }
    
    void showTable(const vector<string>& headers, const vector<vector<string>>& data, 
                  const string& title = "ТАБЛИЦА ДАННЫХ") {
        clearScreen();
        drawHeader("СИСТЕМА УПРАВЛЕНИЯ ХИМИЧЕСКОЙ ЛАБОРАТОРИЕЙ");
        
        // Заголовок таблицы
        attron(A_BOLD | COLOR_PAIR(5));
        mvprintw(4, (screenWidth - title.length()) / 2, "%s", title.c_str());
        attroff(A_BOLD | COLOR_PAIR(5));
        
        // Заголовки столбцов
        int startY = 6;
        int colWidth = screenWidth / headers.size() - 2;
        int currentX = 2;
        
        attron(A_BOLD);
        for (size_t i = 0; i < headers.size(); i++) {
            string header = headers[i];
            if (header.length() > colWidth) {
                header = header.substr(0, colWidth - 3) + "...";
            }
            mvprintw(startY, currentX, "%s", header.c_str());
            currentX += colWidth;
        }
        attroff(A_BOLD);
        
        // Разделитель
        mvhline(startY + 1, 2, '-', screenWidth - 4);
        
        // Данные
        int maxRows = min((int)data.size(), screenHeight - startY - 6);
        for (int row = 0; row < maxRows; row++) {
            currentX = 2;
            for (size_t col = 0; col < headers.size(); col++) {
                string cell = data[row][col];
                if (cell.length() > colWidth) {
                    cell = cell.substr(0, colWidth - 3) + "...";
                }
                mvprintw(startY + row + 3, currentX, "%s", cell.c_str());
                currentX += colWidth;
            }
        }
        
        // Информация о количестве записей
        string info = "Показано: " + to_string(maxRows) + " из " + to_string(data.size()) + " записей";
        mvprintw(screenHeight - 3, 2, "%s", info.c_str());
        
        drawFooter("Нажмите любую клавишу для продолжения...");
        getch();
    }
    
    void showChemicalDetails(const vector<string>& data) {
        clearScreen();
        drawHeader("ДЕТАЛЬНАЯ ИНФОРМАЦИЯ О ХИМИКАТЕ");
        
        if (data.size() >= 8) {
            int y = 5;
            mvprintw(y++, 5, "Название: %s", data[1].c_str());
            mvprintw(y++, 5, "Формула: %s", data[2].c_str());
            mvprintw(y++, 5, "Тип: %s", data[3].c_str());
            mvprintw(y++, 5, "Класс опасности: %s", data[4].c_str());
            mvprintw(y++, 5, "Температура хранения: %s°C", data[5].c_str());
            mvprintw(y++, 5, "Количество: %s %s", data[6].c_str(), data[7].c_str());
            
            if (data.size() > 8) {
                mvprintw(y++, 5, "Контейнер: %s", data[8].c_str());
            }
        }
        
        drawFooter("Нажмите любую клавишу для продолжения...");
        getch();
    }
    
    bool confirmDialog(const string& message) {
        clearScreen();
        drawHeader("ПОДТВЕРЖДЕНИЕ ДЕЙСТВИЯ");
        
        mvprintw(screenHeight / 2 - 1, (screenWidth - message.length()) / 2, "%s", message.c_str());
        mvprintw(screenHeight / 2 + 1, (screenWidth - 10) / 2, "[Y] Да  [N] Нет");
        
        drawFooter("Выберите действие");
        
        while (true) {
            int ch = getch();
            if (ch == 'y' || ch == 'Y' || ch == 'н' || ch == 'Н') {
                return true;
            } else if (ch == 'n' || ch == 'N' || ch == 'т' || ch == 'Т') {
                return false;
            }
        }
    }
    
    void progressBar(int progress, const string& message) {
        clearScreen();
        drawHeader("СИСТЕМА УПРАВЛЕНИЯ ХИМИЧЕСКОЙ ЛАБОРАТОРИЕЙ");
        
        int barWidth = screenWidth - 20;
        int pos = (barWidth * progress) / 100;
        
        mvprintw(screenHeight / 2 - 2, (screenWidth - message.length()) / 2, "%s", message.c_str());
        mvprintw(screenHeight / 2, 10, "[");
        mvprintw(screenHeight / 2, 10 + barWidth + 1, "]");
        
        attron(COLOR_PAIR(2));
        for (int i = 0; i < pos; i++) {
            mvaddch(screenHeight / 2, 11 + i, '=');
        }
        attroff(COLOR_PAIR(2));
        
        string percent = to_string(progress) + "%";
        mvprintw(screenHeight / 2, 12 + barWidth, "%s", percent.c_str());
        
        refresh();
    }
};

// ==================== КЛАСС ДЛЯ УПРАВЛЕНИЯ ХИМИКАТАМИ ====================

class ChemicalManager {
private:
    Database& db;
    NCursesUI& ui;
    
public:
    ChemicalManager(Database& database, NCursesUI& userInterface) 
        : db(database), ui(userInterface) {}
    
    void showAllChemicals() {
        vector<vector<string>> results = db.query(
            "SELECT id, name, formula, type, danger_class, "
            "storage_temp, quantity, unit FROM chemicals ORDER BY name;"
        );
        
        vector<string> headers = {"ID", "Название", "Формула", "Тип", "Класс", "Темп.", "Кол-во", "Ед."};
        ui.showTable(headers, results, "ВСЕ ХИМИКАТЫ");
    }
    
    void addChemical() {
        ui.clearScreen();
        ui.drawHeader("ДОБАВЛЕНИЕ НОВОГО ХИМИКАТА");
        
        int y = 5;
        string name = ui.getInput("Название", y++);
        string formula = ui.getInput("Химическая формула", y++);
        string type = ui.getInput("Тип (acid/base/organic/inorganic/oxide)", y++);
        string danger = ui.getInput("Класс опасности (0-5)", y++);
        string temp = ui.getInput("Температура хранения (°C)", y++);
        string shelf = ui.getInput("Срок годности (месяцев)", y++);
        string quantity = ui.getInput("Количество", y++);
        string unit = ui.getInput("Единица измерения (г/мл/л)", y++);
        string container = ui.getInput("Тип контейнера", y++);
        
        string sql = "INSERT INTO chemicals (name, formula, type, danger_class, "
                    "storage_temp, shelf_life_months, quantity, unit, container_type) "
                    "VALUES ('" + name + "', '" + formula + "', '" + type + "', " +
                    danger + ", " + temp + ", " + shelf + ", " + quantity + ", '" +
                    unit + "', '" + container + "');";
        
        if (db.executeSQL(sql)) {
            ui.showMessage("✓ Химикат добавлен успешно!", 2);
        } else {
            ui.showMessage("✗ Ошибка добавления химиката!", 3);
        }
    }
    
    void findChemical() {
        vector<string> options = {
            "По названию",
            "По типу",
            "По классу опасности",
            "По температуре хранения"
        };
        
        int choice = ui.showMenu("ПОИСК ХИМИКАТА", options);
        
        if (choice == -1) return;
        
        ui.clearScreen();
        ui.drawHeader("ПОИСК ХИМИКАТА");
        
        vector<vector<string>> results;
        string sql;
        
        switch (choice) {
            case 0: { // По названию
                string name = ui.getInput("Введите название", 5);
                sql = "SELECT id, name, formula, type, danger_class, "
                      "storage_temp, quantity, unit FROM chemicals "
                      "WHERE name LIKE '%" + name + "%' ORDER BY name;";
                break;
            }
            case 1: { // По типу
                string type = ui.getInput("Введите тип (acid/base/organic/inorganic/oxide)", 5);
                sql = "SELECT id, name, formula, type, danger_class, "
                      "storage_temp, quantity, unit FROM chemicals "
                      "WHERE type = '" + type + "' ORDER BY name;";
                break;
            }
            case 2: { // По классу опасности
                string danger = ui.getInput("Введите класс опасности (0-5)", 5);
                sql = "SELECT id, name, formula, type, danger_class, "
                      "storage_temp, quantity, unit FROM chemicals "
                      "WHERE danger_class = " + danger + " ORDER BY name;";
                break;
            }
            case 3: { // По температуре
                string temp = ui.getInput("Введите температуру (°C)", 5);
                sql = "SELECT id, name, formula, type, danger_class, "
                      "storage_temp, quantity, unit FROM chemicals "
                      "WHERE storage_temp = " + temp + " ORDER BY name;";
                break;
            }
        }
        
        results = db.query(sql);
        
        if (results.empty()) {
            ui.showMessage("Химикаты не найдены", 4);
        } else {
            vector<string> headers = {"ID", "Название", "Формула", "Тип", "Класс", "Темп.", "Кол-во", "Ед."};
            ui.showTable(headers, results, "РЕЗУЛЬТАТЫ ПОИСКА");
        }
    }
    
    void deleteChemical() {
        string id = ui.getInput("Введите ID химиката для удаления", 5);
        
        if (ui.confirmDialog("Вы уверены что хотите удалить химикат ID: " + id + "?")) {
            string sql = "DELETE FROM chemicals WHERE id = " + id + ";";
            if (db.executeSQL(sql)) {
                ui.showMessage("✓ Химикат удален успешно!", 2);
            } else {
                ui.showMessage("✗ Ошибка удаления химиката!", 3);
            }
        }
    }
    
    void showExpiringBatches() {
        vector<vector<string>> results = db.query(
            "SELECT b.id, c.name, b.quantity, b.expiration_date, "
            "julianday(b.expiration_date) - julianday('now') as days_left "
            "FROM batches b "
            "JOIN chemicals c ON b.chemical_id = c.id "
            "WHERE days_left <= 30 AND days_left >= 0 "
            "ORDER BY days_left;"
        );
        
        vector<string> headers = {"ID партии", "Название", "Количество", "Истекает", "Дней осталось"};
        ui.showTable(headers, results, "ИСТЕКАЮЩИЕ ПАРТИИ");
    }
    
    void run() {
        while (true) {
            vector<string> options = {
                "Показать все химикаты",
                "Добавить новый химикат",
                "Найти химикат",
                "Удалить химикат",
                "Показать истекающие партии",
                "Назад в главное меню"
            };
            
            int choice = ui.showMenu("УПРАВЛЕНИЕ ХИМИКАТАМИ", options);
            
            switch (choice) {
                case 0: showAllChemicals(); break;
                case 1: addChemical(); break;
                case 2: findChemical(); break;
                case 3: deleteChemical(); break;
                case 4: showExpiringBatches(); break;
                case 5: return;
                case -1: return;
            }
        }
    }
};

// ==================== КЛАСС ДЛЯ УПРАВЛЕНИЯ ЗОНАМИ ХРАНЕНИЯ ====================

class StorageManager {
private:
    Database& db;
    NCursesUI& ui;
    
public:
    StorageManager(Database& database, NCursesUI& userInterface) 
        : db(database), ui(userInterface) {
        // Создаем таблицы если их нет
        initDatabase();
    }
    
    void initDatabase() {
        db.executeSQL(
            "CREATE TABLE IF NOT EXISTS storage_zones ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "name TEXT UNIQUE NOT NULL,"
            "temperature REAL NOT NULL,"
            "max_capacity REAL NOT NULL,"
            "current_load REAL DEFAULT 0,"
            "zone_type TEXT);"
        );
        
        db.executeSQL(
            "CREATE TABLE IF NOT EXISTS placements ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "batch_id INTEGER NOT NULL,"
            "zone_id INTEGER NOT NULL,"
            "quantity REAL NOT NULL,"
            "placed_date DATE DEFAULT CURRENT_DATE,"
            "placed_by TEXT);"
        );
        
        // Добавляем тестовые зоны если их нет
        vector<vector<string>> zones = db.query("SELECT COUNT(*) FROM storage_zones;");
        if (zones.empty() || zones[0][0] == "0") {
            db.executeSQL(
                "INSERT INTO storage_zones (name, temperature, max_capacity, zone_type) VALUES "
                "('Холодильник кислот', 4.0, 50.0, 'refrigerator'), "
                "('Основное хранилище', 20.0, 200.0, 'room_temp'), "
                "('Пожароопасная зона', 15.0, 40.0, 'flammable'), "
                "('Морозильник', -18.0, 30.0, 'freezer'), "
                "('Щелочная зона', 25.0, 60.0, 'base');"
            );
        }
    }
    
    void showAllZones() {
        vector<vector<string>> results = db.query(
            "SELECT id, name, temperature, current_load || '/' || max_capacity as load, "
            "ROUND((current_load * 100.0 / max_capacity), 1) as percent, zone_type "
            "FROM storage_zones ORDER BY name;"
        );
        
        vector<string> headers = {"ID", "Название", "Температура", "Загрузка", "%", "Тип"};
        ui.showTable(headers, results, "ЗОНЫ ХРАНЕНИЯ");
    }
    
    void addZone() {
        ui.clearScreen();
        ui.drawHeader("ДОБАВЛЕНИЕ НОВОЙ ЗОНЫ");
        
        int y = 5;
        string name = ui.getInput("Название зоны", y++);
        string temp = ui.getInput("Температура (°C)", y++);
        string capacity = ui.getInput("Максимальная вместимость", y++);
        
        vector<string> typeOptions = {"refrigerator", "freezer", "room_temp", "flammable", "acid", "base"};
        string type = ui.getInput("Тип зоны (refrigerator/freezer/room_temp/flammable/acid/base)", y++);
        
        string sql = "INSERT INTO storage_zones (name, temperature, max_capacity, zone_type) "
                    "VALUES ('" + name + "', " + temp + ", " + capacity + ", '" + type + "');";
        
        if (db.executeSQL(sql)) {
            ui.showMessage("✓ Зона добавлена успешно!", 2);
        } else {
            ui.showMessage("✗ Ошибка добавления зоны!", 3);
        }
    }
    
    void placeChemical() {
        ui.clearScreen();
        ui.drawHeader("РАЗМЕЩЕНИЕ ХИМИКАТА В ЗОНЕ");
        
        int y = 5;
        string batchId = ui.getInput("ID партии", y++);
        string zoneId = ui.getInput("ID зоны", y++);
        string quantity = ui.getInput("Количество", y++);
        string placedBy = ui.getInput("Ваше имя", y++);
        
        // Проверяем существование партии
        vector<vector<string>> batch = db.query(
            "SELECT chemical_id FROM batches WHERE id = " + batchId + ";"
        );
        
        if (batch.empty()) {
            ui.showMessage("✗ Партия не найдена!", 3);
            return;
        }
        
        // Проверяем существование зоны
        vector<vector<string>> zone = db.query(
            "SELECT max_capacity, current_load FROM storage_zones WHERE id = " + zoneId + ";"
        );
        
        if (zone.empty()) {
            ui.showMessage("✗ Зона не найдена!", 3);
            return;
        }
        
        double maxCap = stod(zone[0][0]);
        double current = stod(zone[0][1]);
        double qty = stod(quantity);
        
        if (current + qty > maxCap) {
            ui.showMessage("✗ Недостаточно места в зоне!", 3);
            return;
        }
        
        // Добавляем размещение
        string sql = "INSERT INTO placements (batch_id, zone_id, quantity, placed_by) "
                    "VALUES (" + batchId + ", " + zoneId + ", " + quantity + ", '" + placedBy + "');";
        
        if (db.executeSQL(sql)) {
            // Обновляем загрузку зоны
            db.executeSQL(
                "UPDATE storage_zones SET current_load = current_load + " + quantity + 
                " WHERE id = " + zoneId + ";"
            );
            ui.showMessage("✓ Химикат размещен успешно!", 2);
        } else {
            ui.showMessage("✗ Ошибка размещения!", 3);
        }
    }
    
    void showZoneContents() {
        string zoneId = ui.getInput("Введите ID зоны", 5);
        
        vector<vector<string>> results = db.query(
            "SELECT p.id, c.name, c.formula, p.quantity, c.danger_class, p.placed_date "
            "FROM placements p "
            "JOIN batches b ON p.batch_id = b.id "
            "JOIN chemicals c ON b.chemical_id = c.id "
            "WHERE p.zone_id = " + zoneId + " "
            "ORDER BY c.name;"
        );
        
        if (results.empty()) {
            ui.showMessage("Зона пуста или не существует", 4);
        } else {
            vector<string> headers = {"ID", "Название", "Формула", "Количество", "Класс", "Дата размещения"};
            ui.showTable(headers, results, "СОДЕРЖИМОЕ ЗОНЫ #" + zoneId);
        }
    }
    
    void run() {
        while (true) {
            vector<string> options = {
                "Показать все зоны",
                "Добавить новую зону",
                "Разместить химикат в зоне",
                "Показать содержимое зоны",
                "Назад в главное меню"
            };
            
            int choice = ui.showMenu("УПРАВЛЕНИЕ ЗОНАМИ ХРАНЕНИЯ", options);
            
            switch (choice) {
                case 0: showAllZones(); break;
                case 1: addZone(); break;
                case 2: placeChemical(); break;
                case 3: showZoneContents(); break;
                case 4: return;
                case -1: return;
            }
        }
    }
};

// ==================== КЛАСС ДЛЯ СИСТЕМЫ БЕЗОПАСНОСТИ ====================

class SafetySystem {
private:
    Database& db;
    NCursesUI& ui;
    
public:
    SafetySystem(Database& database, NCursesUI& userInterface) 
        : db(database), ui(userInterface) {}
    
    void checkExpiring() {
        vector<vector<string>> results = db.query(
            "SELECT b.id, c.name, b.expiration_date, "
            "julianday(b.expiration_date) - julianday('now') as days_left "
            "FROM batches b "
            "JOIN chemicals c ON b.chemical_id = c.id "
            "WHERE days_left <= 30 AND days_left >= 0 "
            "ORDER BY days_left;"
        );
        
        if (results.empty()) {
            ui.showMessage("✓ Нет партий с истекающим сроком", 2);
        } else {
            vector<string> headers = {"ID", "Название", "Истекает", "Дней осталось"};
            ui.showTable(headers, results, "🔔 ИСТЕКАЮЩИЕ ПАРТИИ");
        }
    }
    
    void checkOverloadedZones() {
        vector<vector<string>> results = db.query(
            "SELECT id, name, current_load || '/' || max_capacity as load, "
            "ROUND((current_load * 100.0 / max_capacity), 1) as percent "
            "FROM storage_zones "
            "WHERE (current_load * 100.0 / max_capacity) >= 90 "
            "ORDER BY percent DESC;"
        );
        
        if (results.empty()) {
            ui.showMessage("✓ Нет перегруженных зон", 2);
        } else {
            vector<string> headers = {"ID", "Название", "Загрузка", "%"};
            ui.showTable(headers, results, "⚠ ПЕРЕГРУЖЕННЫЕ ЗОНЫ");
        }
    }
    
    void checkTemperature() {
        vector<vector<string>> results = db.query(
            "SELECT p.id, c.name, c.storage_temp, z.name as zone_name, z.temperature as zone_temp, "
            "ROUND(ABS(c.storage_temp - z.temperature), 1) as diff "
            "FROM placements p "
            "JOIN batches b ON p.batch_id = b.id "
            "JOIN chemicals c ON b.chemical_id = c.id "
            "JOIN storage_zones z ON p.zone_id = z.id "
            "WHERE ABS(c.storage_temp - z.temperature) > 5 "
            "ORDER BY diff DESC;"
        );
        
        if (results.empty()) {
            ui.showMessage("✓ Нарушений температурного режима нет", 2);
        } else {
            vector<string> headers = {"ID", "Химикат", "Требуемая", "Зона", "Фактическая", "Отклонение"};
            ui.showTable(headers, results, "🌡 НАРУШЕНИЯ ТЕМПЕРАТУРЫ");
        }
    }
    
    void fullSafetyCheck() {
        ui.progressBar(0, "Начинаем проверку безопасности...");
        
        ui.progressBar(25, "Проверяем истекающие сроки...");
        vector<vector<string>> expiring = db.query(
            "SELECT COUNT(*) FROM batches WHERE "
            "julianday(expiration_date) - julianday('now') <= 30 AND "
            "julianday(expiration_date) - julianday('now') >= 0;"
        );
        
        ui.progressBar(50, "Проверяем загрузку зон...");
        vector<vector<string>> overloaded = db.query(
            "SELECT COUNT(*) FROM storage_zones WHERE "
            "(current_load * 100.0 / max_capacity) >= 90;"
        );
        
        ui.progressBar(75, "Проверяем температурный режим...");
        vector<vector<string>> tempViolations = db.query(
            "SELECT COUNT(*) FROM placements p "
            "JOIN batches b ON p.batch_id = b.id "
            "JOIN chemicals c ON b.chemical_id = c.id "
            "JOIN storage_zones z ON p.zone_id = z.id "
            "WHERE ABS(c.storage_temp - z.temperature) > 5;"
        );
        
        ui.progressBar(100, "Завершаем проверку...");
        
        // Показываем результаты
        ui.clearScreen();
        ui.drawHeader("📊 РЕЗУЛЬТАТЫ ПРОВЕРКИ БЕЗОПАСНОСТИ");
        
        int y = 5;
        ui.showMessage("✓ Проверка безопасности завершена", 2);
        
        string expCount = expiring.empty() ? "0" : expiring[0][0];
        string overCount = overloaded.empty() ? "0" : overloaded[0][0];
        string tempCount = tempViolations.empty() ? "0" : tempViolations[0][0];
        
        vector<vector<string>> summary = {
            {"Истекающие партии (30 дней)", expCount},
            {"Перегруженные зоны (>90%)", overCount},
            {"Температурные нарушения (>5°C)", tempCount}
        };
        
        vector<string> headers = {"Проверка", "Найдено"};
        ui.showTable(headers, summary, "СВОДКА БЕЗОПАСНОСТИ");
    }
    
    void run() {
        while (true) {
            vector<string> options = {
                "Проверить истекающие сроки",
                "Проверить перегруженные зоны",
                "Проверить температурный режим",
                "Полная проверка безопасности",
                "Назад в главное меню"
            };
            
            int choice = ui.showMenu("СИСТЕМА БЕЗОПАСНОСТИ", options);
            
            switch (choice) {
                case 0: checkExpiring(); break;
                case 1: checkOverloadedZones(); break;
                case 2: checkTemperature(); break;
                case 3: fullSafetyCheck(); break;
                case 4: return;
                case -1: return;
            }
        }
    }
};

// ==================== КЛАСС ДЛЯ ОТЧЕТОВ ====================

class ReportSystem {
private:
    Database& db;
    NCursesUI& ui;
    
public:
    ReportSystem(Database& database, NCursesUI& userInterface) 
        : db(database), ui(userInterface) {}
    
    void dailyReport() {
        time_t now = time(nullptr);
        tm* local_time = localtime(&now);
        char date[100];
        strftime(date, sizeof(date), "%Y-%m-%d", local_time);
        
        // Собираем статистику
        vector<vector<string>> chemStats = db.query(
            "SELECT COUNT(*), SUM(quantity) FROM chemicals;"
        );
        
        vector<vector<string>> zoneStats = db.query(
            "SELECT COUNT(*), AVG(current_load * 100.0 / max_capacity) FROM storage_zones;"
        );
        
        vector<vector<string>> batchStats = db.query(
            "SELECT COUNT(*), "
            "SUM(CASE WHEN julianday(expiration_date) - julianday('now') <= 30 THEN 1 ELSE 0 END) "
            "FROM batches;"
        );
        
        // Отображаем отчет
        ui.clearScreen();
        ui.drawHeader("📊 ЕЖЕДНЕВНЫЙ ОТЧЕТ - " + string(date));
        
        int y = 5;
        if (!chemStats.empty()) {
            mvprintw(y++, 5, "Химикаты: %s шт, всего %s ед.", 
                    chemStats[0][0].c_str(), chemStats[0][1].c_str());
        }
        
        if (!zoneStats.empty()) {
            double avgLoad = zoneStats[0][1].empty() ? 0 : stod(zoneStats[0][1]);
            mvprintw(y++, 5, "Зоны хранения: %s шт, средняя загрузка: %.1f%%", 
                    zoneStats[0][0].c_str(), avgLoad);
        }
        
        if (!batchStats.empty()) {
            mvprintw(y++, 5, "Партии: %s шт, истекают в течение месяца: %s шт", 
                    batchStats[0][0].c_str(), batchStats[0][1].c_str());
        }
        
        // Критические проблемы
        y += 2;
        mvprintw(y++, 5, "Критические проблемы:");
        
        vector<vector<string>> critical = db.query(
            "SELECT 'Перегруженные зоны', COUNT(*) FROM storage_zones "
            "WHERE (current_load * 100.0 / max_capacity) >= 95 "
            "UNION ALL "
            "SELECT 'Срочно истекающие', COUNT(*) FROM batches "
            "WHERE julianday(expiration_date) - julianday('now') <= 7 AND "
            "julianday(expiration_date) - julianday('now') >= 0;"
        );
        
        for (const auto& row : critical) {
            if (row[1] != "0") {
                attron(COLOR_PAIR(3));
                mvprintw(y++, 10, "⚠ %s: %s", row[0].c_str(), row[1].c_str());
                attroff(COLOR_PAIR(3));
            }
        }
        
        ui.drawFooter("Нажмите любую клавишу для продолжения...");
        getch();
    }
    
    void inventoryReport() {
        vector<vector<string>> results = db.query(
            "SELECT type, COUNT(*) as count, SUM(quantity) as total_qty, "
            "AVG(danger_class) as avg_danger "
            "FROM chemicals "
            "GROUP BY type "
            "ORDER BY type;"
        );
        
        vector<string> headers = {"Тип", "Количество", "Суммарное кол-во", "Ср. класс опасности"};
        ui.showTable(headers, results, "ОТЧЕТ ПО ИНВЕНТАРИЗАЦИИ");
    }
    
    void run() {
        while (true) {
            vector<string> options = {
                "Ежедневный отчет",
                "Отчет по инвентаризации",
                "Назад в главное меню"
            };
            
            int choice = ui.showMenu("СИСТЕМА ОТЧЕТОВ", options);
            
            switch (choice) {
                case 0: dailyReport(); break;
                case 1: inventoryReport(); break;
                case 2: return;
                case -1: return;
            }
        }
    }
};

// ==================== ГЛАВНОЕ МЕНЮ ====================

class MainMenu {
private:
    Database& db;
    NCursesUI ui;
    ChemicalManager chemManager;
    StorageManager storageManager;
    SafetySystem safetySystem;
    ReportSystem reportSystem;
    
public:
    MainMenu(Database& database) 
        : db(database),
          chemManager(database, ui),
          storageManager(database, ui),
          safetySystem(database, ui),
          reportSystem(database, ui) {}
    
    void run() {
        while (true) {
            vector<string> options = {
                "Управление химикатами",
                "Управление зонами хранения",
                "Система безопасности",
                "Система отчетов",
                "Выход из программы"
            };
            
            int choice = ui.showMenu("ГЛАВНОЕ МЕНЮ", options);
            
            switch (choice) {
                case 0: chemManager.run(); break;
                case 1: storageManager.run(); break;
                case 2: safetySystem.run(); break;
                case 3: reportSystem.run(); break;
                case 4: return;
                case -1: return;
            }
        }
    }
};

// ==================== ГЛАВНАЯ ФУНКЦИЯ ====================

int main() {
    try {
        // Инициализация базы данных
        Database db("data/laboratory.db");
        
        // Создаем необходимые таблицы
        db.executeSQL(
            "CREATE TABLE IF NOT EXISTS chemicals ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "name TEXT NOT NULL,"
            "formula TEXT,"
            "type TEXT,"
            "danger_class INTEGER CHECK(danger_class BETWEEN 0 AND 5),"
            "storage_temp REAL NOT NULL,"
            "shelf_life_months INTEGER,"
            "quantity REAL DEFAULT 0,"
            "unit TEXT DEFAULT 'г',"
            "container_type TEXT,"
            "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);"
        );
        
        db.executeSQL(
            "CREATE TABLE IF NOT EXISTS batches ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "chemical_id INTEGER NOT NULL,"
            "quantity REAL NOT NULL CHECK(quantity > 0),"
            "production_date TEXT,"
            "expiration_date TEXT,"
            "FOREIGN KEY (chemical_id) REFERENCES chemicals(id) ON DELETE CASCADE);"
        );
        
        // Добавляем тестовые данные если таблицы пусты
        vector<vector<string>> chemCheck = db.query("SELECT COUNT(*) FROM chemicals;");
        if (chemCheck.empty() || chemCheck[0][0] == "0") {
            db.executeSQL(
                "INSERT INTO chemicals (name, formula, type, danger_class, storage_temp, quantity, unit) VALUES "
                "('Серная кислота', 'H2SO4', 'acid', 1, 20.0, 5000.0, 'мл'), "
                "('Этанол', 'C2H5OH', 'organic', 3, 15.0, 10000.0, 'мл'), "
                "('Гидроксид натрия', 'NaOH', 'base', 2, 25.0, 2000.0, 'г'), "
                "('Ацетон', 'C3H6O', 'organic', 3, 20.0, 3000.0, 'мл'), "
                "('Перекись водорода', 'H2O2', 'oxide', 1, 4.0, 2000.0, 'мл');"
            );
            
            db.executeSQL(
                "INSERT INTO batches (chemical_id, quantity, production_date, expiration_date) VALUES "
                "(1, 1000, '2024-01-15', '2025-01-15'), "
                "(2, 2000, '2024-02-01', '2024-08-01'), "
                "(3, 500, '2024-01-01', '2026-01-01');"
            );
        }
        
        // Запуск главного меню
        MainMenu mainMenu(db);
        mainMenu.run();
        
    } catch (const exception& e) {
        endwin(); // Завершаем ncurses если была ошибка
        cerr << "Ошибка: " << e.what() << endl;
        cerr << "Убедитесь что база данных существует: make init_db" << endl;
        return 1;
    }
    
    return 0;
}