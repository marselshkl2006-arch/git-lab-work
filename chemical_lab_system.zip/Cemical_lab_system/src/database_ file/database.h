#ifndef DATABASE_H
#define DATABASE_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include <QVector>
#include <QMap>

struct Chemical {
    int id;
    QString name;
    QString formula;
    QString type;
    int dangerClass;
    double storageTemp;
    int shelfLife;
    double quantity;
    QString unit;
    QString container;
    QString createdAt;
};

struct StorageZone {
    int id;
    QString name;
    double temperature;
    double maxCapacity;
    double currentLoad;
    QString zoneType;
    QString description;
};

struct Batch {
    int id;
    int chemicalId;
    int zoneId;
    double quantity;
    QString productionDate;
    QString expirationDate;
    QString supplier;
};

class Database : public QObject
{
    Q_OBJECT

public:
    explicit Database(QObject *parent = nullptr);
    ~Database();

    bool initialize();
    bool isOpen() const;

    // Химикаты
    QVector<Chemical> getAllChemicals();
    Chemical getChemicalById(int id);
    bool addChemical(const Chemical &chem);
    bool updateChemical(const Chemical &chem);
    bool deleteChemical(int id);

    // Зоны хранения
    QVector<StorageZone> getAllStorageZones();
    StorageZone getStorageZoneById(int id);
    bool addStorageZone(const StorageZone &zone);
    bool updateStorageZone(const StorageZone &zone);
    bool deleteStorageZone(int id);

    // Партии
    QVector<Batch> getAllBatches();
    QVector<Batch> getExpiringBatches(int daysThreshold = 30);
    bool addBatch(const Batch &batch);
    bool moveBatch(int batchId, int newZoneId, double quantity);

    // Статистика
    QMap<QString, QVariant> getStatistics();
    QVector<QMap<QString, QVariant>> getSafetyAlerts();

private:
    QSqlDatabase db;
    bool createTables();
    bool populateTestData();
};

#endif // DATABASE_H