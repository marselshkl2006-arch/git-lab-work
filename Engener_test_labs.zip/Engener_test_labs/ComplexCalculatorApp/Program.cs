using System;
using ComplexCalculatorNS;

namespace ComplexCalculatorApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            var calculator = new ComplexCalculatorNS.ComplexCalculator();
            calculator.Run();
        }
    }
}
