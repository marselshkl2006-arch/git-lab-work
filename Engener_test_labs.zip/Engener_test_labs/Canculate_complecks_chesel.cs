using System;
using System.Collections.Generic;

namespace ComplexCalculator
{
    /// <summary>
    
    /// </summary>
    public class ComplexNumber
    {
        public double Real { get; }
        public double Imaginary { get; }

        public ComplexNumber(double real, double imaginary)
        {
            Real = real;
            Imaginary = imaginary;
        }

        public ComplexNumber Add(ComplexNumber other)
        {
            return new ComplexNumber(Real + other.Real, Imaginary + other.Imaginary);
        }

        public ComplexNumber Subtract(ComplexNumber other)
        {
            return new ComplexNumber(Real - other.Real, Imaginary - other.Imaginary);
        }

        public ComplexNumber Multiply(ComplexNumber other)
        {
            double real = Real * other.Real - Imaginary * other.Imaginary;
            double imaginary = Real * other.Imaginary + Imaginary * other.Real;
            return new ComplexNumber(real, imaginary);
        }

        public ComplexNumber Divide(ComplexNumber other)
        {
            double denominator = other.Real * other.Real + other.Imaginary * other.Imaginary;
            if (denominator == 0)
                throw new DivideByZeroException("Деление на ноль невозможно");

            double real = (Real * other.Real + Imaginary * other.Imaginary) / denominator;
            double imaginary = (Imaginary * other.Real - Real * other.Imaginary) / denominator;
            return new ComplexNumber(real, imaginary);
        }

        public double Modulus()
        {
            return Math.Sqrt(Real * Real + Imaginary * Imaginary);
        }

        public bool IsGreaterThan(ComplexNumber other)
        {
            return Modulus() > other.Modulus();
        }

        public bool IsLessThan(ComplexNumber other)
        {
            return Modulus() < other.Modulus();
        }

        public bool IsGreaterOrEqual(ComplexNumber other)
        {
            return Modulus() >= other.Modulus();
        }

        public bool IsLessOrEqual(ComplexNumber other)
        {
            return Modulus() <= other.Modulus();
        }

        public bool IsEqual(ComplexNumber other)
        {
            return Math.Abs(Modulus() - other.Modulus()) < 0.000001;
        }

        public static ComplexNumber operator +(ComplexNumber a, ComplexNumber b) => a.Add(b);
        public static ComplexNumber operator -(ComplexNumber a, ComplexNumber b) => a.Subtract(b);
        public static ComplexNumber operator *(ComplexNumber a, ComplexNumber b) => a.Multiply(b);
        public static ComplexNumber operator /(ComplexNumber a, ComplexNumber b) => a.Divide(b);

        public override string ToString()
        {
            if (Imaginary == 0)
                return $"{Real}";
            if (Real == 0)
                return $"{Imaginary}i";
            
            string sign = Imaginary > 0 ? "+" : "";
            return $"{Real}{sign}{Imaginary}i";
        }
    }

    public static class ComplexParser
{
    public static ComplexNumber Parse(string input)
    {
        if (string.IsNullOrWhiteSpace(input))
            throw new ArgumentException("Пустая строка");

        
        input = input.Replace(" ", "").ToLower();
        
        // Обработка спец случаев
        if (input == "i") return new ComplexNumber(0, 1);
        if (input == "-i") return new ComplexNumber(0, -1);
        if (input == "+i") return new ComplexNumber(0, 1);
        
        // Ищем позицию i
        int iPos = input.IndexOf('i');
        
        if (iPos >= 0)
        {
            // Часть до i (может быть мнимой или содержать действительную часть)
            string beforeI = input.Substring(0, iPos);
            // Часть после i (действительная часть, если есть)
            string afterI = input.Substring(iPos + 1);
            
            double real = 0;
            double imag = 0;
            
            // Парсим часть до i
            if (!string.IsNullOrEmpty(beforeI))
            {
                
                int lastPlus = beforeI.LastIndexOf('+');
                int lastMinus = beforeI.LastIndexOf('-');
                
                // Если есть знак и это не первый символ
                if ((lastPlus > 0 || lastMinus > 0) && !(beforeI.Length == 1 && (beforeI == "+" || beforeI == "-")))
                {
                    int splitIndex = Math.Max(lastPlus, lastMinus);
                    string realStr = beforeI.Substring(0, splitIndex);
                    string imagStr = beforeI.Substring(splitIndex);
                    
                    real = string.IsNullOrEmpty(realStr) ? 0 : double.Parse(realStr);
                    imag = ParseImaginaryPart(imagStr);
                }
                else
                {
                    // Вся часть до i — это мнимая часть
                    imag = ParseImaginaryPart(beforeI);
                }
            }
            
            // Парсим часть после i (действительная часть)
            if (!string.IsNullOrEmpty(afterI))
            {
                real += double.Parse(afterI);
            }
            
            return new ComplexNumber(real, imag);
        }
        
        // Нет i — это действительное число
        return new ComplexNumber(double.Parse(input), 0);
    }
    
    private static double ParseImaginaryPart(string imagStr)
    {
        if (string.IsNullOrEmpty(imagStr))
            return 1;
        if (imagStr == "+")
            return 1;
        if (imagStr == "-")
            return -1;
        return double.Parse(imagStr);
    }
    
    public static bool TryParse(string input, out ComplexNumber result)
    {
        try
        {
            result = Parse(input);
            return true;
        }
        catch
        {
            result = null;
            return false;
        }
    }
}

    public class ComplexCalculator
    {
        private readonly Dictionary<int, (string Name, Func<ComplexNumber, ComplexNumber, ComplexNumber> Operation)> _operations;
        
        public ComplexCalculator()
        {
            _operations = new Dictionary<int, (string, Func<ComplexNumber, ComplexNumber, ComplexNumber>)>
            {
                { 1, ("Сложение", (a, b) => a + b) },
                { 2, ("Вычитание", (a, b) => a - b) },
                { 3, ("Умножение", (a, b) => a * b) },
                { 4, ("Деление", (a, b) => a / b) }
            };
        }
        
        public void Run()
        {
            Console.WriteLine("╔════════════════════════════════════════╗");
            Console.WriteLine("║     Калькулятор комплексных чисел     ║");
            Console.WriteLine("╚════════════════════════════════════════╝");
            Console.WriteLine();
            
            bool continueRunning = true;
            
            while (continueRunning)
            {
                try
                {
                    Console.Write("Введите первое комплексное число (например: 3+4i, 2i, -5): ");
                    ComplexNumber num1 = ComplexParser.Parse(Console.ReadLine());
                    Console.WriteLine($"   → {num1}");
                    Console.WriteLine();
                    
                    Console.Write("Введите второе комплексное число: ");
                    ComplexNumber num2 = ComplexParser.Parse(Console.ReadLine());
                    Console.WriteLine($"   → {num2}");
                    Console.WriteLine();
                    
                    Console.WriteLine("Выберите операцию:");
                    Console.WriteLine("  1. Сложение (+)");
                    Console.WriteLine("  2. Вычитание (-)");
                    Console.WriteLine("  3. Умножение (*)");
                    Console.WriteLine("  4. Деление (/)");
                    Console.WriteLine("  5. Сравнение по модулю");
                    Console.WriteLine("  6. Показать модули чисел");
                    Console.WriteLine();
                    Console.Write("Ваш выбор: ");
                    
                    string choice = Console.ReadLine();
                    Console.WriteLine();
                    
                    switch (choice)
                    {
                        case "1":
                        case "2":
                        case "3":
                        case "4":
                            int op = int.Parse(choice);
                            var operation = _operations[op];
                            ComplexNumber result = operation.Operation(num1, num2);
                            Console.WriteLine($"Результат {operation.Name}: {num1} {GetSymbol(op)} {num2} = {result}");
                            break;
                        case "5":
                            ShowComparison(num1, num2);
                            break;
                        case "6":
                            ShowModuli(num1, num2);
                            break;
                        default:
                            Console.WriteLine("Неверный выбор!");
                            break;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка: Неверный формат числа!");
                }
                catch (DivideByZeroException ex)
                {
                    Console.WriteLine($"Ошибка: {ex.Message}");
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine($"Ошибка: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Непредвиденная ошибка: {ex.Message}");
                }
                
                Console.WriteLine();
                Console.Write("Продолжить? (y/n): ");
                string answer = Console.ReadLine()?.ToLower();
                continueRunning = answer == "y" || answer == "yes";
                Console.WriteLine();
            }
            
            Console.WriteLine("До свидания!");
        }
        
        private string GetSymbol(int operation)
        {
            return operation switch
            {
                1 => "+",
                2 => "-",
                3 => "*",
                4 => "/",
                _ => "?"
            };
        }
        
        private void ShowComparison(ComplexNumber a, ComplexNumber b)
        {
            double modA = a.Modulus();
            double modB = b.Modulus();
            
            Console.WriteLine($"Модуль {a} = {modA:F4}");
            Console.WriteLine($"Модуль {b} = {modB:F4}");
            Console.WriteLine();
            
            if (a.IsEqual(b))
                Console.WriteLine($"{a} ≡ {b} (модули равны)");
            else if (a.IsGreaterThan(b))
                Console.WriteLine($"{a} > {b} (модуль больше)");
            else if (a.IsLessThan(b))
                Console.WriteLine($"{a} < {b} (модуль меньше)");
        }
        
        private void ShowModuli(ComplexNumber a, ComplexNumber b)
        {
            Console.WriteLine($"|{a}| = {a.Modulus():F4}");
            Console.WriteLine($"|{b}| = {b.Modulus():F4}");
        }
    }
}
