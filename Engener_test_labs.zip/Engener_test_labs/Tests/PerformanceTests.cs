using System;
using System.Diagnostics;
using Xunit;
using Xunit.Abstractions;

namespace ComplexCalculator.Tests
{
    /// <summary>
    /// Тесты производительности для ЛР №5
    /// </summary>
    public class PerformanceTests
    {
        private readonly ITestOutputHelper _output;

        public PerformanceTests(ITestOutputHelper output)
        {
            _output = output;
        }

        #region Тесты производительности базовых операций

        [Fact]
        public void Performance_Addition_1000000Operations()
        {
            var num1 = new ComplexNumber(3, 4);
            var num2 = new ComplexNumber(5, 6);

            var sw = Stopwatch.StartNew();
            ComplexNumber result = num1;

            for (int i = 0; i < 1000000; i++)
            {
                result = result.Add(num2);
            }

            sw.Stop();
            _output.WriteLine($"1,000,000 сложений выполнено за {sw.ElapsedMilliseconds} мс");
            _output.WriteLine($"Среднее время на операцию: {sw.Elapsed.TotalMilliseconds / 1000000:F6} мс");

            // Проверяем, что операция выполняется достаточно быстро (< 1 секунды)
            Assert.True(sw.ElapsedMilliseconds < 1000,
                $"Операция заняла слишком много времени: {sw.ElapsedMilliseconds} мс");
        }

        [Fact]
        public void Performance_Multiplication_1000000Operations()
        {
            var num1 = new ComplexNumber(1.1, 1.1);
            var num2 = new ComplexNumber(0.9, 0.9);

            var sw = Stopwatch.StartNew();
            ComplexNumber result = num1;

            for (int i = 0; i < 1000000; i++)
            {
                result = result.Multiply(num2);
            }

            sw.Stop();
            _output.WriteLine($"1,000,000 умножений выполнено за {sw.ElapsedMilliseconds} мс");
            _output.WriteLine($"Среднее время на операцию: {sw.Elapsed.TotalMilliseconds / 1000000:F6} мс");

            Assert.True(sw.ElapsedMilliseconds < 1000);
        }

        [Fact]
        public void Performance_Division_100000Operations()
        {
            var num1 = new ComplexNumber(10, 20);
            var num2 = new ComplexNumber(2, 3);

            var sw = Stopwatch.StartNew();
            ComplexNumber result = num1;

            for (int i = 0; i < 100000; i++)
            {
                result = num1.Divide(num2);
            }

            sw.Stop();
            _output.WriteLine($"100,000 делений выполнено за {sw.ElapsedMilliseconds} мс");
            _output.WriteLine($"Среднее время на операцию: {sw.Elapsed.TotalMilliseconds / 100000:F6} мс");

            Assert.True(sw.ElapsedMilliseconds < 1000);
        }

        [Fact]
        public void Performance_Modulus_1000000Operations()
        {
            var num = new ComplexNumber(3, 4);

            var sw = Stopwatch.StartNew();
            double result = 0;

            for (int i = 0; i < 1000000; i++)
            {
                result = num.Modulus();
            }

            sw.Stop();
            _output.WriteLine($"1,000,000 вычислений модуля выполнено за {sw.ElapsedMilliseconds} мс");
            _output.WriteLine($"Среднее время на операцию: {sw.Elapsed.TotalMilliseconds / 1000000:F6} мс");

            Assert.True(sw.ElapsedMilliseconds < 500);
        }

        #endregion

        #region Тесты производительности операторов

        [Fact]
        public void Performance_OperatorAddition_1000000Operations()
        {
            var num1 = new ComplexNumber(3, 4);
            var num2 = new ComplexNumber(5, 6);

            var sw = Stopwatch.StartNew();
            ComplexNumber result = num1;

            for (int i = 0; i < 1000000; i++)
            {
                result = result + num2;
            }

            sw.Stop();
            _output.WriteLine($"1,000,000 операций '+' выполнено за {sw.ElapsedMilliseconds} мс");

            Assert.True(sw.ElapsedMilliseconds < 1000);
        }

        [Fact]
        public void Performance_OperatorMultiplication_1000000Operations()
        {
            var num1 = new ComplexNumber(1.1, 1.1);
            var num2 = new ComplexNumber(0.9, 0.9);

            var sw = Stopwatch.StartNew();
            ComplexNumber result = num1;

            for (int i = 0; i < 1000000; i++)
            {
                result = num1 * num2;
            }

            sw.Stop();
            _output.WriteLine($"1,000,000 операций '*' выполнено за {sw.ElapsedMilliseconds} мс");

            Assert.True(sw.ElapsedMilliseconds < 1000);
        }

        #endregion

        #region Тесты производительности парсинга

        [Fact]
        public void Performance_Parse_100000Operations()
        {
            var sw = Stopwatch.StartNew();

            for (int i = 0; i < 100000; i++)
            {
                var num = ComplexParser.Parse("3+4i");
            }

            sw.Stop();
            _output.WriteLine($"100,000 операций парсинга выполнено за {sw.ElapsedMilliseconds} мс");
            _output.WriteLine($"Среднее время на операцию: {sw.Elapsed.TotalMilliseconds / 100000:F6} мс");

            Assert.True(sw.ElapsedMilliseconds < 2000);
        }

        [Fact]
        public void Performance_ParseComplexFormats_50000Operations()
        {
            string[] formats = { "3+4i", "-5-6i", "7i", "-8i", "9", "-10+11i" };

            var sw = Stopwatch.StartNew();

            for (int i = 0; i < 50000; i++)
            {
                foreach (var format in formats)
                {
                    var num = ComplexParser.Parse(format);
                }
            }

            sw.Stop();
            _output.WriteLine($"300,000 операций парсинга различных форматов выполнено за {sw.ElapsedMilliseconds} мс");

            Assert.True(sw.ElapsedMilliseconds < 3000);
        }

        #endregion

        #region Тесты производительности сравнения

        [Fact]
        public void Performance_Comparison_1000000Operations()
        {
            var num1 = new ComplexNumber(3, 4);
            var num2 = new ComplexNumber(5, 6);

            var sw = Stopwatch.StartNew();
            bool result = false;

            for (int i = 0; i < 1000000; i++)
            {
                result = num1.IsGreaterThan(num2);
            }

            sw.Stop();
            _output.WriteLine($"1,000,000 операций сравнения выполнено за {sw.ElapsedMilliseconds} мс");

            Assert.True(sw.ElapsedMilliseconds < 1000);
        }

        #endregion

        #region Тесты производительности ToString

        [Fact]
        public void Performance_ToString_100000Operations()
        {
            var num = new ComplexNumber(3, 4);

            var sw = Stopwatch.StartNew();

            for (int i = 0; i < 100000; i++)
            {
                var str = num.ToString();
            }

            sw.Stop();
            _output.WriteLine($"100,000 операций ToString выполнено за {sw.ElapsedMilliseconds} мс");

            Assert.True(sw.ElapsedMilliseconds < 500);
        }

        #endregion

        #region Тесты производительности комплексных выражений

        [Fact]
        public void Performance_ComplexExpression_100000Operations()
        {
            var a = new ComplexNumber(1, 2);
            var b = new ComplexNumber(3, 4);
            var c = new ComplexNumber(5, 6);

            var sw = Stopwatch.StartNew();

            for (int i = 0; i < 100000; i++)
            {
                var result = (a + b) * c - a;
            }

            sw.Stop();
            _output.WriteLine($"100,000 комплексных выражений выполнено за {sw.ElapsedMilliseconds} мс");
            _output.WriteLine($"Среднее время на выражение: {sw.Elapsed.TotalMilliseconds / 100000:F6} мс");

            Assert.True(sw.ElapsedMilliseconds < 1000);
        }

        [Fact]
        public void Performance_ChainedOperations_50000Operations()
        {
            var a = ComplexParser.Parse("1+2i");
            var b = ComplexParser.Parse("3+4i");
            var c = ComplexParser.Parse("5+6i");
            var d = ComplexParser.Parse("7+8i");

            var sw = Stopwatch.StartNew();

            for (int i = 0; i < 50000; i++)
            {
                var result = ((a + b) * c) / d;
            }

            sw.Stop();
            _output.WriteLine($"50,000 цепочек операций выполнено за {sw.ElapsedMilliseconds} мс");

            Assert.True(sw.ElapsedMilliseconds < 1000);
        }

        #endregion

        #region Тесты производительности массовых операций

        [Fact]
        public void Performance_CreateManyObjects_100000Operations()
        {
            var sw = Stopwatch.StartNew();

            for (int i = 0; i < 100000; i++)
            {
                var num = new ComplexNumber(i, i + 1);
            }

            sw.Stop();
            _output.WriteLine($"100,000 объектов создано за {sw.ElapsedMilliseconds} мс");

            Assert.True(sw.ElapsedMilliseconds < 500);
        }

        [Fact]
        public void Performance_ArrayOperations_CalculateSum()
        {
            var numbers = new ComplexNumber[10000];
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = new ComplexNumber(i, i + 1);
            }

            var sw = Stopwatch.StartNew();
            ComplexNumber sum = new ComplexNumber(0, 0);

            for (int i = 0; i < numbers.Length; i++)
            {
                sum = sum.Add(numbers[i]);
            }

            sw.Stop();
            _output.WriteLine($"Сумма 10,000 чисел вычислена за {sw.ElapsedMilliseconds} мс");

            Assert.True(sw.ElapsedMilliseconds < 100);
        }

        [Fact]
        public void Performance_ArrayOperations_FindMaxModulus()
        {
            var numbers = new ComplexNumber[10000];
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = new ComplexNumber(i, i + 1);
            }

            var sw = Stopwatch.StartNew();
            ComplexNumber max = numbers[0];

            for (int i = 1; i < numbers.Length; i++)
            {
                if (numbers[i].IsGreaterThan(max))
                {
                    max = numbers[i];
                }
            }

            sw.Stop();
            _output.WriteLine($"Максимум из 10,000 чисел найден за {sw.ElapsedMilliseconds} мс");

            Assert.True(sw.ElapsedMilliseconds < 100);
        }

        #endregion

        #region Сравнительные тесты производительности

        [Fact]
        public void Performance_Compare_MethodVsOperator()
        {
            var num1 = new ComplexNumber(3, 4);
            var num2 = new ComplexNumber(5, 6);

            // Тест метода Add
            var sw1 = Stopwatch.StartNew();
            for (int i = 0; i < 1000000; i++)
            {
                var result = num1.Add(num2);
            }
            sw1.Stop();

            // Тест оператора +
            var sw2 = Stopwatch.StartNew();
            for (int i = 0; i < 1000000; i++)
            {
                var result = num1 + num2;
            }
            sw2.Stop();

            _output.WriteLine($"Метод Add: {sw1.ElapsedMilliseconds} мс");
            _output.WriteLine($"Оператор +: {sw2.ElapsedMilliseconds} мс");
            _output.WriteLine($"Разница: {Math.Abs(sw1.ElapsedMilliseconds - sw2.ElapsedMilliseconds)} мс");

            // Оба должны быть быстрыми
            Assert.True(sw1.ElapsedMilliseconds < 1000);
            Assert.True(sw2.ElapsedMilliseconds < 1000);
        }

        #endregion
    }
}
