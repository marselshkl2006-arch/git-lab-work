using System;
using Xunit;

namespace ComplexCalculator.Tests
{
    public class ComplexNumberTests
    {
        [Fact]
        public void Constructor_SetsRealAndImaginary()
        {
            var number = new ComplexNumber(3, 4);
            Assert.Equal(3, number.Real); // = 3
            Assert.Equal(4, number.Imaginary); // = 4
        }

        [Fact]
        public void Add_ReturnsCorrectSum()
        {
            var a = new ComplexNumber(3, 4);
            var b = new ComplexNumber(1, 2);
            var result = a.Add(b);
            Assert.Equal(4, result.Real);
            Assert.Equal(6, result.Imaginary);
        }

        [Fact]
        public void Subtract_ReturnsCorrectDifference()
        {
            var a = new ComplexNumber(5, 7);
            var b = new ComplexNumber(2, 3);
            var result = a.Subtract(b);
            Assert.Equal(3, result.Real);
            Assert.Equal(4, result.Imaginary);
        }

        [Fact]
        public void Multiply_ReturnsCorrectProduct()
        {
            var a = new ComplexNumber(2, 3);
            var b = new ComplexNumber(4, 5);
            var result = a.Multiply(b);
            Assert.Equal(-7, result.Real);
            Assert.Equal(22, result.Imaginary);
        }

        [Fact]
        public void Divide_ReturnsCorrectQuotient()
        {
            var a = new ComplexNumber(2, 3);
            var b = new ComplexNumber(4, 5);
            var result = a.Divide(b);
            Assert.Equal(23.0 / 41.0, result.Real, 6);
            Assert.Equal(2.0 / 41.0, result.Imaginary, 6);
        }

        [Fact]
        public void Divide_ByZero_ThrowsDivideByZeroException()
        {
            var a = new ComplexNumber(1, 0);
            var b = new ComplexNumber(0, 0);
            Assert.Throws<DivideByZeroException>(() => a.Divide(b));
        }

        [Fact]
        public void Modulus_ReturnsCorrectValue()
        {
            var number = new ComplexNumber(3, 4);
            Assert.Equal(5.0, number.Modulus());
        }

        [Fact]
        public void IsEqual_EqualModuli_ReturnsTrue()
        {
            var a = new ComplexNumber(3, 4);
            var b = new ComplexNumber(0, 5);
            Assert.True(a.IsEqual(b));
        }

        [Fact]
        public void IsEqual_UnequalModuli_ReturnsFalse()
        {
            var a = new ComplexNumber(3, 4);
            var b = new ComplexNumber(1, 1);
            Assert.False(a.IsEqual(b));
        }

        [Fact]
        public void IsGreaterThan_WhenGreater_ReturnsTrue()
        {
            var a = new ComplexNumber(4, 3);
            var b = new ComplexNumber(0, 3);
            Assert.True(a.IsGreaterThan(b));
            Assert.False(b.IsGreaterThan(a));
        }

        [Fact]
        public void IsLessThan_WhenLess_ReturnsTrue()
        {
            var a = new ComplexNumber(1, 1);
            var b = new ComplexNumber(2, 0);
            Assert.True(a.IsLessThan(b));
            Assert.False(b.IsLessThan(a));
        }

        [Theory]
        [InlineData(3, 4, "3+4i")]
        [InlineData(3, -4, "3-4i")]
        [InlineData(0, 5, "5i")]
        [InlineData(0, -5, "-5i")]
        [InlineData(5, 0, "5")]
        [InlineData(0, 0, "0")]
        [InlineData(-3, 4, "-3+4i")]
        [InlineData(-3, -4, "-3-4i")]
        public void ToString_ReturnsCorrectFormat(double real, double imaginary, string expected)
        {
            var number = new ComplexNumber(real, imaginary);
            Assert.Equal(expected, number.ToString());
        }

        [Fact]
        public void OperatorPlus_AddsTwoNumbers()
        {
            var a = new ComplexNumber(1, 2);
            var b = new ComplexNumber(3, 4);
            var result = a + b;
            Assert.Equal(4, result.Real);
            Assert.Equal(6, result.Imaginary);
        }

        [Fact]
        public void OperatorMinus_SubtractsTwoNumbers()
        {
            var a = new ComplexNumber(5, 7);
            var b = new ComplexNumber(2, 3);
            var result = a - b;
            Assert.Equal(3, result.Real);
            Assert.Equal(4, result.Imaginary);
        }

        [Fact]
        public void OperatorMultiply_MultipliesTwoNumbers()
        {
            var a = new ComplexNumber(2, 3);
            var b = new ComplexNumber(4, 5);
            var result = a * b;
            Assert.Equal(-7, result.Real);
            Assert.Equal(22, result.Imaginary);
        }

        [Fact]
        public void OperatorDivide_DividesTwoNumbers()
        {
            var a = new ComplexNumber(2, 3);
            var b = new ComplexNumber(4, 5);
            var result = a / b;
            Assert.Equal(23.0 / 41.0, result.Real, 6);
            Assert.Equal(2.0 / 41.0, result.Imaginary, 6);
        }
    }
}
