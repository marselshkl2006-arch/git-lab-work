using System;
using Xunit;

namespace ComplexCalculator.Tests
{
    /// <summary>
    /// Расширенные модульные тесты для ЛР №4
    /// </summary>
    public class ComplexNumberExtendedTests
    {
        #region Негативные тесты (проверка исключений)

        [Fact]
        public void Divide_ByZero_ThrowsDivideByZeroException()
        {
            var num = new ComplexNumber(5, 3);
            var zero = new ComplexNumber(0, 0);

            Assert.Throws<DivideByZeroException>(() => num.Divide(zero));
        }

        [Fact]
        public void Divide_ByZeroUsingOperator_ThrowsDivideByZeroException()
        {
            var num = new ComplexNumber(5, 3);
            var zero = new ComplexNumber(0, 0);

            Assert.Throws<DivideByZeroException>(() => num / zero);
        }

        #endregion

        #region Тесты валидации входных данных

        [Theory]
        [InlineData(double.NaN, 0)]
        [InlineData(0, double.NaN)]
        [InlineData(double.NaN, double.NaN)]
        public void Constructor_WithNaN_CreatesNumberWithNaN(double real, double imaginary)
        {
            var num = new ComplexNumber(real, imaginary);

            if (double.IsNaN(real))
                Assert.True(double.IsNaN(num.Real));
            if (double.IsNaN(imaginary))
                Assert.True(double.IsNaN(num.Imaginary));
        }

        [Theory]
        [InlineData(double.PositiveInfinity, 0)]
        [InlineData(0, double.PositiveInfinity)]
        [InlineData(double.NegativeInfinity, 0)]
        [InlineData(0, double.NegativeInfinity)]
        public void Constructor_WithInfinity_CreatesNumberWithInfinity(double real, double imaginary)
        {
            var num = new ComplexNumber(real, imaginary);

            Assert.Equal(real, num.Real);
            Assert.Equal(imaginary, num.Imaginary);
        }

        #endregion

        #region Параметризованные тесты операций

        [Theory]
        [InlineData(1, 2, 3, 4, 4, 6)]
        [InlineData(-1, -2, -3, -4, -4, -6)]
        [InlineData(0, 0, 5, 5, 5, 5)]
        [InlineData(100, 200, -50, -100, 50, 100)]
        public void Add_VariousInputs_ReturnsCorrectSum(
            double r1, double i1, double r2, double i2, double expectedR, double expectedI)
        {
            var num1 = new ComplexNumber(r1, i1);
            var num2 = new ComplexNumber(r2, i2);
            var result = num1.Add(num2);

            Assert.Equal(expectedR, result.Real);
            Assert.Equal(expectedI, result.Imaginary);
        }

        [Theory]
        [InlineData(5, 7, 2, 3, 3, 4)]
        [InlineData(0, 0, 1, 1, -1, -1)]
        [InlineData(10, 10, 10, 10, 0, 0)]
        [InlineData(-5, -7, -2, -3, -3, -4)]
        public void Subtract_VariousInputs_ReturnsCorrectDifference(
            double r1, double i1, double r2, double i2, double expectedR, double expectedI)
        {
            var num1 = new ComplexNumber(r1, i1);
            var num2 = new ComplexNumber(r2, i2);
            var result = num1.Subtract(num2);

            Assert.Equal(expectedR, result.Real);
            Assert.Equal(expectedI, result.Imaginary);
        }

        [Theory]
        [InlineData(1, 0, 1, 0, 1, 0)]
        [InlineData(0, 1, 0, 1, -1, 0)]
        [InlineData(2, 0, 3, 0, 6, 0)]
        [InlineData(0, 2, 0, 3, -6, 0)]
        [InlineData(1, 1, 1, 1, 0, 2)]
        public void Multiply_VariousInputs_ReturnsCorrectProduct(
            double r1, double i1, double r2, double i2, double expectedR, double expectedI)
        {
            var num1 = new ComplexNumber(r1, i1);
            var num2 = new ComplexNumber(r2, i2);
            var result = num1.Multiply(num2);

            Assert.Equal(expectedR, result.Real, 10);
            Assert.Equal(expectedI, result.Imaginary, 10);
        }

        #endregion

        #region Тесты модуля

        [Theory]
        [InlineData(3, 4, 5)]
        [InlineData(5, 12, 13)]
        [InlineData(8, 15, 17)]
        [InlineData(0, 0, 0)]
        [InlineData(1, 0, 1)]
        [InlineData(0, 1, 1)]
        public void Modulus_VariousInputs_ReturnsCorrectValue(
            double real, double imaginary, double expectedModulus)
        {
            var num = new ComplexNumber(real, imaginary);
            var modulus = num.Modulus();

            Assert.Equal(expectedModulus, modulus, 10);
        }

        [Fact]
        public void Modulus_NegativeComponents_ReturnsPositiveValue()
        {
            var num = new ComplexNumber(-3, -4);
            var modulus = num.Modulus();

            Assert.True(modulus > 0);
            Assert.Equal(5, modulus);
        }

        #endregion

        #region Тесты сравнения

        [Theory]
        [InlineData(3, 4, 0, 5, true)]
        [InlineData(5, 0, 3, 4, true)]
        [InlineData(1, 1, 1, 1, true)]
        public void IsEqual_EqualModuli_ReturnsTrue(
            double r1, double i1, double r2, double i2, bool expected)
        {
            var num1 = new ComplexNumber(r1, i1);
            var num2 = new ComplexNumber(r2, i2);

            Assert.Equal(expected, num1.IsEqual(num2));
        }

        [Theory]
        [InlineData(5, 0, 3, 0, true)]
        [InlineData(3, 4, 1, 1, true)]
        [InlineData(0, 5, 0, 3, true)]
        public void IsGreaterThan_FirstHasLargerModulus_ReturnsTrue(
            double r1, double i1, double r2, double i2, bool expected)
        {
            var num1 = new ComplexNumber(r1, i1);
            var num2 = new ComplexNumber(r2, i2);

            Assert.Equal(expected, num1.IsGreaterThan(num2));
        }

        [Theory]
        [InlineData(1, 0, 3, 0, true)]
        [InlineData(1, 1, 3, 4, true)]
        [InlineData(0, 3, 0, 5, true)]
        public void IsLessThan_FirstHasSmallerModulus_ReturnsTrue(
            double r1, double i1, double r2, double i2, bool expected)
        {
            var num1 = new ComplexNumber(r1, i1);
            var num2 = new ComplexNumber(r2, i2);

            Assert.Equal(expected, num1.IsLessThan(num2));
        }

        [Theory]
        [InlineData(5, 0, 3, 0, true)]
        [InlineData(3, 4, 3, 4, true)]
        [InlineData(3, 4, 0, 5, true)]
        public void IsGreaterOrEqual_ValidCases_ReturnsTrue(
            double r1, double i1, double r2, double i2, bool expected)
        {
            var num1 = new ComplexNumber(r1, i1);
            var num2 = new ComplexNumber(r2, i2);

            Assert.Equal(expected, num1.IsGreaterOrEqual(num2));
        }

        [Theory]
        [InlineData(1, 0, 3, 0, true)]
        [InlineData(3, 4, 3, 4, true)]
        [InlineData(3, 4, 0, 5, true)]
        public void IsLessOrEqual_ValidCases_ReturnsTrue(
            double r1, double i1, double r2, double i2, bool expected)
        {
            var num1 = new ComplexNumber(r1, i1);
            var num2 = new ComplexNumber(r2, i2);

            Assert.Equal(expected, num1.IsLessOrEqual(num2));
        }

        #endregion

        #region Тесты ToString

        [Theory]
        [InlineData(0, 1, "1i")]
        [InlineData(0, -1, "-1i")]
        [InlineData(1, 1, "1+1i")]
        [InlineData(1, -1, "1-1i")]
        [InlineData(0, 0, "0")]
        public void ToString_SpecialCases_ReturnsCorrectFormat(
            double real, double imaginary, string expected)
        {
            var num = new ComplexNumber(real, imaginary);
            Assert.Equal(expected, num.ToString());
        }

        #endregion

        #region Тесты коммутативности и ассоциативности

        [Fact]
        public void Add_IsCommutative()
        {
            var a = new ComplexNumber(2, 3);
            var b = new ComplexNumber(4, 5);

            var result1 = a.Add(b);
            var result2 = b.Add(a);

            Assert.Equal(result1.Real, result2.Real);
            Assert.Equal(result1.Imaginary, result2.Imaginary);
        }

        [Fact]
        public void Multiply_IsCommutative()
        {
            var a = new ComplexNumber(2, 3);
            var b = new ComplexNumber(4, 5);

            var result1 = a.Multiply(b);
            var result2 = b.Multiply(a);

            Assert.Equal(result1.Real, result2.Real, 10);
            Assert.Equal(result1.Imaginary, result2.Imaginary, 10);
        }

        [Fact]
        public void Add_IsAssociative()
        {
            var a = new ComplexNumber(1, 2);
            var b = new ComplexNumber(3, 4);
            var c = new ComplexNumber(5, 6);

            var result1 = (a.Add(b)).Add(c);
            var result2 = a.Add(b.Add(c));

            Assert.Equal(result1.Real, result2.Real, 10);
            Assert.Equal(result1.Imaginary, result2.Imaginary, 10);
        }

        [Fact]
        public void Multiply_IsAssociative()
        {
            var a = new ComplexNumber(1, 2);
            var b = new ComplexNumber(3, 4);
            var c = new ComplexNumber(5, 6);

            var result1 = (a.Multiply(b)).Multiply(c);
            var result2 = a.Multiply(b.Multiply(c));

            Assert.Equal(result1.Real, result2.Real, 10);
            Assert.Equal(result1.Imaginary, result2.Imaginary, 10);
        }

        [Fact]
        public void Multiply_DistributesOverAdd()
        {
            var a = new ComplexNumber(1, 2);
            var b = new ComplexNumber(3, 4);
            var c = new ComplexNumber(5, 6);

            var result1 = a.Multiply(b.Add(c));
            var result2 = a.Multiply(b).Add(a.Multiply(c));

            Assert.Equal(result1.Real, result2.Real, 10);
            Assert.Equal(result1.Imaginary, result2.Imaginary, 10);
        }

        #endregion

        #region Тесты нейтральных элементов

        [Fact]
        public void Add_WithAdditiveIdentity_ReturnsOriginal()
        {
            var num = new ComplexNumber(3, 4);
            var zero = new ComplexNumber(0, 0);

            var result = num.Add(zero);

            Assert.Equal(num.Real, result.Real);
            Assert.Equal(num.Imaginary, result.Imaginary);
        }

        [Fact]
        public void Multiply_WithMultiplicativeIdentity_ReturnsOriginal()
        {
            var num = new ComplexNumber(3, 4);
            var one = new ComplexNumber(1, 0);

            var result = num.Multiply(one);

            Assert.Equal(num.Real, result.Real, 10);
            Assert.Equal(num.Imaginary, result.Imaginary, 10);
        }

        #endregion

        #region Тесты обратных элементов

        [Fact]
        public void Add_ThenSubtractSame_ReturnsOriginal()
        {
            var num = new ComplexNumber(3, 4);
            var other = new ComplexNumber(5, 6);

            var result = num.Add(other).Subtract(other);

            Assert.Equal(num.Real, result.Real, 10);
            Assert.Equal(num.Imaginary, result.Imaginary, 10);
        }

        [Fact]
        public void Multiply_ThenDivideBySame_ReturnsOriginal()
        {
            var num = new ComplexNumber(3, 4);
            var other = new ComplexNumber(5, 6);

            var result = num.Multiply(other).Divide(other);

            Assert.Equal(num.Real, result.Real, 10);
            Assert.Equal(num.Imaginary, result.Imaginary, 10);
        }

        #endregion
    }
}
