using System;
using Xunit;

namespace ComplexCalculator.Tests
{
    public class ComplexParserTests
    {
        [Fact]
        public void Parse_StandardFormat_ReturnsCorrectNumber()
        {
            var result = ComplexParser.Parse("3+4i");
            Assert.Equal(3, result.Real);
            Assert.Equal(4, result.Imaginary);
        }

        [Fact]
        public void Parse_WithSpaces_ReturnsCorrectNumber()
        {
            var result = ComplexParser.Parse(" 3 + 4i ");
            Assert.Equal(3, result.Real);
            Assert.Equal(4, result.Imaginary);
        }

        [Fact]
        public void Parse_NegativeImaginaryOnly_ReturnsCorrectNumber()
        {
            var result = ComplexParser.Parse("-5i");
            Assert.Equal(0, result.Real);
            Assert.Equal(-5, result.Imaginary);
        }

        [Fact]
        public void Parse_PositiveImaginaryOnly_ReturnsCorrectNumber()
        {
            var result = ComplexParser.Parse("5i");
            Assert.Equal(0, result.Real);
            Assert.Equal(5, result.Imaginary);
        }

        [Fact]
        public void Parse_RealOnly_ReturnsNumberWithZeroImaginary()
        {
            var result = ComplexParser.Parse("7");
            Assert.Equal(7, result.Real);
            Assert.Equal(0, result.Imaginary);
        }

        [Fact]
        public void Parse_NegativeRealOnly_ReturnsCorrectNumber()
        {
            var result = ComplexParser.Parse("-7");
            Assert.Equal(-7, result.Real);
            Assert.Equal(0, result.Imaginary);
        }

        [Fact]
        public void Parse_EmptyString_ThrowsArgumentException()
        {
            Assert.Throws<ArgumentException>(() => ComplexParser.Parse(""));
        }

        [Fact]
        public void Parse_NullString_ThrowsArgumentException()
        {
            Assert.Throws<ArgumentException>(() => ComplexParser.Parse(null));
        }

        [Theory]
        [InlineData("i", 0, 1)]
        [InlineData("-i", 0, -1)]
        [InlineData("+i", 0, 1)]
        [InlineData("2i", 0, 2)]
        [InlineData("-2i", 0, -2)]
        [InlineData("3-4i", 3, -4)]
        [InlineData("-3+4i", -3, 4)]
        [InlineData("-3-4i", -3, -4)]
        [InlineData("0+0i", 0, 0)]
        [InlineData("0-0i", 0, 0)]
        public void Parse_VariousFormats_ReturnsCorrectNumber(string input, double expectedReal, double expectedImaginary)
        {
            var result = ComplexParser.Parse(input);
            Assert.Equal(expectedReal, result.Real);
            Assert.Equal(expectedImaginary, result.Imaginary);
        }

        [Fact]
        public void Parse_InvalidFormat_ThrowsFormatException()
        {
            Assert.Throws<FormatException>(() => ComplexParser.Parse("abc"));
            Assert.Throws<FormatException>(() => ComplexParser.Parse("3++4i"));
        }
    }
}
