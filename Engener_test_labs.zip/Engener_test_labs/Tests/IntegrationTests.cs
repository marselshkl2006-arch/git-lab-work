using System;
using Xunit;

namespace ComplexCalculator.Tests
{
    /// <summary>
    /// Интеграционные тесты для ЛР №5
    /// Проверяют взаимодействие между компонентами: Parser + ComplexNumber + операции
    /// </summary>
    public class IntegrationTests
    {
        #region Тесты парсинга и операций

        [Fact]
        public void ParseAndAdd_TwoComplexNumbers_ReturnsCorrectResult()
        {
            var num1 = ComplexParser.Parse("3+4i");
            var num2 = ComplexParser.Parse("1+2i");
            var result = num1.Add(num2);

            Assert.Equal(4, result.Real);
            Assert.Equal(6, result.Imaginary);
        }

        [Fact]
        public void ParseAndMultiply_ComplexNumbers_ReturnsCorrectResult()
        {
            var num1 = ComplexParser.Parse("2+3i");
            var num2 = ComplexParser.Parse("4+5i");
            var result = num1.Multiply(num2);

            Assert.Equal(-7, result.Real);
            Assert.Equal(22, result.Imaginary);
        }

        [Fact]
        public void ParseAndDivide_ComplexNumbers_ReturnsCorrectResult()
        {
            var num1 = ComplexParser.Parse("10+5i");
            var num2 = ComplexParser.Parse("2+1i");
            var result = num1.Divide(num2);

            Assert.Equal(5, result.Real, 10);
            Assert.Equal(0, result.Imaginary, 10);
        }

        #endregion

        #region Тесты цепочки операций

        [Fact]
        public void ChainedOperations_ParseAddMultiply_WorksCorrectly()
        {
            var a = ComplexParser.Parse("1+2i");
            var b = ComplexParser.Parse("3+4i");
            var c = ComplexParser.Parse("5+6i");

            var result = (a.Add(b)).Multiply(c);

            Assert.Equal(-16, result.Real);
            Assert.Equal(54, result.Imaginary);
        }

        [Fact]
        public void ChainedOperations_WithOperators_WorksCorrectly()
        {
            var a = ComplexParser.Parse("2+3i");
            var b = ComplexParser.Parse("1+1i");
            var c = ComplexParser.Parse("3+2i");

            // (2+3i) + (1+1i) = (3+4i)
            // (3+4i) * (3+2i) = (9+12i) + (6i+8i²) = (9+12i) + (6i-8) = (1+18i)
            // (1+18i) - (2+3i) = (-1+15i)
            var result = (a + b) * c - a;

            Assert.Equal(-1, result.Real);
            Assert.Equal(15, result.Imaginary);
        }

        [Fact]
        public void ComplexExpression_MultipleOperations_WorksCorrectly()
        {
            var a = ComplexParser.Parse("1+i");
            var b = ComplexParser.Parse("2+2i");
            var c = ComplexParser.Parse("1-i");

            // (1+i) * (2+2i) = (2+2i) + (2i+2i²) = (2+2i) + (2i-2) = (0+4i)
            // (0+4i) / (1-i) = ((0+4i)(1+i)) / (1²+1²) = (0+0i+4i+4i²) / 2 = (0+4i-4) / 2 = (-4+4i) / 2 = (-2+2i)
            var result = (a * b) / c;

            Assert.Equal(-2, result.Real, 10);
            Assert.Equal(2, result.Imaginary, 10);
        }

        #endregion

        #region Тесты парсинга различных форматов

        [Theory]
        [InlineData("3+4i", 3, 4)]
        [InlineData("3-4i", 3, -4)]
        [InlineData("-3+4i", -3, 4)]
        [InlineData("-3-4i", -3, -4)]
        [InlineData("5", 5, 0)]
        [InlineData("i", 0, 1)]
        [InlineData("-i", 0, -1)]
        [InlineData("2i", 0, 2)]
        public void ParseVariousFormats_ThenCalculateModulus_WorksCorrectly(
            string input, double expectedReal, double expectedImaginary)
        {
            var num = ComplexParser.Parse(input);

            Assert.Equal(expectedReal, num.Real);
            Assert.Equal(expectedImaginary, num.Imaginary);

            var expectedModulus = Math.Sqrt(expectedReal * expectedReal + expectedImaginary * expectedImaginary);
            Assert.Equal(expectedModulus, num.Modulus(), 10);
        }

        #endregion

        #region Тесты сравнения после операций

        [Fact]
        public void ParseAndCompare_ByModulus_WorksCorrectly()
        {
            var num1 = ComplexParser.Parse("3+4i");
            var num2 = ComplexParser.Parse("0+5i");

            Assert.True(num1.IsEqual(num2));
            Assert.False(num1.IsGreaterThan(num2));
            Assert.False(num1.IsLessThan(num2));
        }

        [Fact]
        public void OperationsAndComparison_WorkTogether()
        {
            var a = ComplexParser.Parse("1+1i");
            var b = ComplexParser.Parse("2+2i");

            var sum = a + b; // (3+3i), |z| = sqrt(18) ≈ 4.24
            var product = a * b; // (2+2i)+(2i+2i²) = (2+2i)+(2i-2) = (0+4i), |z| = 4

            // Модуль суммы больше модуля произведения
            Assert.True(sum.IsGreaterThan(product));
        }

        #endregion

        #region Тесты ToString после операций

        [Fact]
        public void ParseOperateToString_RoundTrip_WorksCorrectly()
        {
            var num1 = ComplexParser.Parse("3+4i");
            var num2 = ComplexParser.Parse("1+2i");

            var result = num1.Add(num2);
            var resultString = result.ToString();

            Assert.Equal("4+6i", resultString);
        }

        [Fact]
        public void MultipleOperations_ToString_FormatsCorrectly()
        {
            var a = ComplexParser.Parse("2+3i");
            var b = ComplexParser.Parse("1+1i");

            var result = a.Multiply(b);
            var resultString = result.ToString();

            Assert.Equal("-1+5i", resultString);
        }

        #endregion

        #region Тесты обработки ошибок

        [Fact]
        public void ParseInvalidInput_ThenTryOperation_HandlesGracefully()
        {
            Assert.Throws<ArgumentException>(() => ComplexParser.Parse(""));
            Assert.Throws<ArgumentException>(() => ComplexParser.Parse(null));
        }

        [Fact]
        public void ParseValidNumbers_DivideByZero_ThrowsException()
        {
            var num = ComplexParser.Parse("5+3i");
            var zero = ComplexParser.Parse("0");

            Assert.Throws<DivideByZeroException>(() => num.Divide(zero));
        }

        [Fact]
        public void TryParse_InvalidInput_ReturnsFalse()
        {
            bool success = ComplexParser.TryParse("invalid", out ComplexNumber result);

            Assert.False(success);
            Assert.Null(result);
        }

        [Fact]
        public void TryParse_ValidInput_ReturnsTrue()
        {
            bool success = ComplexParser.TryParse("3+4i", out ComplexNumber result);

            Assert.True(success);
            Assert.NotNull(result);
            Assert.Equal(3, result.Real);
            Assert.Equal(4, result.Imaginary);
        }

        #endregion

        #region Тесты математических свойств

        [Fact]
        public void Integration_CommutativeProperty_HoldsForAllOperations()
        {
            var a = ComplexParser.Parse("2+3i");
            var b = ComplexParser.Parse("4+5i");

            // Сложение коммутативно
            var sum1 = a + b;
            var sum2 = b + a;
            Assert.Equal(sum1.Real, sum2.Real);
            Assert.Equal(sum1.Imaginary, sum2.Imaginary);

            // Умножение коммутативно
            var prod1 = a * b;
            var prod2 = b * a;
            Assert.Equal(prod1.Real, prod2.Real, 10);
            Assert.Equal(prod1.Imaginary, prod2.Imaginary, 10);
        }

        [Fact]
        public void Integration_AssociativeProperty_HoldsForAddition()
        {
            var a = ComplexParser.Parse("1+2i");
            var b = ComplexParser.Parse("3+4i");
            var c = ComplexParser.Parse("5+6i");

            var result1 = (a + b) + c;
            var result2 = a + (b + c);

            Assert.Equal(result1.Real, result2.Real, 10);
            Assert.Equal(result1.Imaginary, result2.Imaginary, 10);
        }

        [Fact]
        public void Integration_DistributiveProperty_Holds()
        {
            var a = ComplexParser.Parse("2+3i");
            var b = ComplexParser.Parse("4+5i");
            var c = ComplexParser.Parse("6+7i");

            var result1 = a * (b + c);
            var result2 = (a * b) + (a * c);

            Assert.Equal(result1.Real, result2.Real, 10);
            Assert.Equal(result1.Imaginary, result2.Imaginary, 10);
        }

        #endregion

        #region Тесты реальных сценариев использования

        [Fact]
        public void RealWorldScenario_ElectricalImpedance_Calculation()
        {
            // Z1 = 3 + 4i Ом (сопротивление + реактивное сопротивление)
            // Z2 = 5 + 12i Ом
            var z1 = ComplexParser.Parse("3+4i");
            var z2 = ComplexParser.Parse("5+12i");

            // Последовательное соединение: Z_total = Z1 + Z2
            var zTotal = z1 + z2;

            Assert.Equal(8, zTotal.Real);
            Assert.Equal(16, zTotal.Imaginary);
            Assert.Equal(Math.Sqrt(320), zTotal.Modulus(), 10);
        }

        [Fact]
        public void RealWorldScenario_QuadraticEquation_ComplexRoots()
        {
            // Корни уравнения x² + 2x + 5 = 0
            // x = (-2 ± √(4-20)) / 2 = (-2 ± √(-16)) / 2 = -1 ± 2i
            var root1 = ComplexParser.Parse("-1+2i");
            var root2 = ComplexParser.Parse("-1-2i");

            // Проверка: сумма корней = -b/a = -2
            var sum = root1 + root2;
            Assert.Equal(-2, sum.Real);
            Assert.Equal(0, sum.Imaginary);

            // Произведение корней = c/a = 5
            var product = root1 * root2;
            Assert.Equal(5, product.Real, 10);
            Assert.Equal(0, product.Imaginary, 10);
        }

        #endregion
    }
}
