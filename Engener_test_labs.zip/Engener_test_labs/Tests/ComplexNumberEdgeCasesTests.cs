using System;
using Xunit;

namespace ComplexCalculator.Tests
{
    /// <summary>
    /// Тесты граничных случаев для ЛР №4
    /// </summary>
    public class ComplexNumberEdgeCasesTests
    {
        #region Тесты с нулевыми значениями

        [Fact]
        public void Add_WithZero_ReturnsOriginalNumber()
        {
            var num = new ComplexNumber(3, 4);
            var zero = new ComplexNumber(0, 0);
            var result = num.Add(zero);

            Assert.Equal(3, result.Real);
            Assert.Equal(4, result.Imaginary);
        }

        [Fact]
        public void Multiply_ByZero_ReturnsZero()
        {
            var num = new ComplexNumber(3, 4);
            var zero = new ComplexNumber(0, 0);
            var result = num.Multiply(zero);

            Assert.Equal(0, result.Real);
            Assert.Equal(0, result.Imaginary);
        }

        [Fact]
        public void Divide_ZeroByNumber_ReturnsZero()
        {
            var zero = new ComplexNumber(0, 0);
            var num = new ComplexNumber(3, 4);
            var result = zero.Divide(num);

            Assert.Equal(0, result.Real);
            Assert.Equal(0, result.Imaginary);
        }

        [Fact]
        public void Modulus_OfZero_ReturnsZero()
        {
            var zero = new ComplexNumber(0, 0);
            Assert.Equal(0, zero.Modulus());
        }

        #endregion

        #region Тесты с очень большими числами

        [Fact]
        public void Add_VeryLargeNumbers_DoesNotOverflow()
        {
            var num1 = new ComplexNumber(1e100, 1e100);
            var num2 = new ComplexNumber(1e100, 1e100);
            var result = num1.Add(num2);

            Assert.Equal(2e100, result.Real);
            Assert.Equal(2e100, result.Imaginary);
        }

        [Fact]
        public void Multiply_VeryLargeNumbers_HandlesCorrectly()
        {
            var num1 = new ComplexNumber(1e50, 0);
            var num2 = new ComplexNumber(1e50, 0);
            var result = num1.Multiply(num2);

            // Для очень больших чисел проверяем порядок величины
            Assert.True(result.Real > 9e99 && result.Real < 1.1e100);
            Assert.Equal(0, result.Imaginary);
        }

        [Fact]
        public void Modulus_VeryLargeNumber_ReturnsCorrectValue()
        {
            var num = new ComplexNumber(3e100, 4e100);
            var modulus = num.Modulus();

            Assert.Equal(5e100, modulus, 10);
        }

        #endregion

        #region Тесты с очень малыми числами

        [Fact]
        public void Add_VerySmallNumbers_MaintainsPrecision()
        {
            var num1 = new ComplexNumber(1e-100, 1e-100);
            var num2 = new ComplexNumber(1e-100, 1e-100);
            var result = num1.Add(num2);

            Assert.Equal(2e-100, result.Real, 15);
            Assert.Equal(2e-100, result.Imaginary, 15);
        }

        [Fact]
        public void Divide_ByVerySmallNumber_HandlesCorrectly()
        {
            var num1 = new ComplexNumber(1, 0);
            var num2 = new ComplexNumber(1e-10, 0);
            var result = num1.Divide(num2);

            Assert.Equal(1e10, result.Real, 5);
            Assert.Equal(0, result.Imaginary, 5);
        }

        [Fact]
        public void Modulus_VerySmallNumber_ReturnsCorrectValue()
        {
            var num = new ComplexNumber(3e-100, 4e-100);
            var modulus = num.Modulus();

            Assert.Equal(5e-100, modulus, 15);
        }

        #endregion

        #region Тесты с отрицательными числами

        [Fact]
        public void Add_NegativeNumbers_ReturnsCorrectResult()
        {
            var num1 = new ComplexNumber(-3, -4);
            var num2 = new ComplexNumber(-1, -2);
            var result = num1.Add(num2);

            Assert.Equal(-4, result.Real);
            Assert.Equal(-6, result.Imaginary);
        }

        [Fact]
        public void Multiply_NegativeNumbers_ReturnsCorrectResult()
        {
            var num1 = new ComplexNumber(-2, -3);
            var num2 = new ComplexNumber(-4, -5);
            var result = num1.Multiply(num2);

            Assert.Equal(-7, result.Real);
            Assert.Equal(22, result.Imaginary);
        }

        [Fact]
        public void Divide_NegativeNumbers_ReturnsCorrectResult()
        {
            var num1 = new ComplexNumber(-2, -3);
            var num2 = new ComplexNumber(-4, -5);
            var result = num1.Divide(num2);

            Assert.Equal(23.0 / 41.0, result.Real, 10);
            Assert.Equal(2.0 / 41.0, result.Imaginary, 10);
        }

        #endregion

        #region Тесты с чисто действительными числами

        [Fact]
        public void Add_PureRealNumbers_ReturnsRealNumber()
        {
            var num1 = new ComplexNumber(5, 0);
            var num2 = new ComplexNumber(3, 0);
            var result = num1.Add(num2);

            Assert.Equal(8, result.Real);
            Assert.Equal(0, result.Imaginary);
        }

        [Fact]
        public void Multiply_PureRealNumbers_ReturnsRealNumber()
        {
            var num1 = new ComplexNumber(5, 0);
            var num2 = new ComplexNumber(3, 0);
            var result = num1.Multiply(num2);

            Assert.Equal(15, result.Real);
            Assert.Equal(0, result.Imaginary);
        }

        [Fact]
        public void Divide_PureRealNumbers_ReturnsRealNumber()
        {
            var num1 = new ComplexNumber(10, 0);
            var num2 = new ComplexNumber(2, 0);
            var result = num1.Divide(num2);

            Assert.Equal(5, result.Real);
            Assert.Equal(0, result.Imaginary);
        }

        #endregion

        #region Тесты с чисто мнимыми числами

        [Fact]
        public void Add_PureImaginaryNumbers_ReturnsImaginaryNumber()
        {
            var num1 = new ComplexNumber(0, 5);
            var num2 = new ComplexNumber(0, 3);
            var result = num1.Add(num2);

            Assert.Equal(0, result.Real);
            Assert.Equal(8, result.Imaginary);
        }

        [Fact]
        public void Multiply_PureImaginaryNumbers_ReturnsRealNumber()
        {
            var num1 = new ComplexNumber(0, 2);
            var num2 = new ComplexNumber(0, 3);
            var result = num1.Multiply(num2);

            Assert.Equal(-6, result.Real);
            Assert.Equal(0, result.Imaginary);
        }

        [Fact]
        public void Divide_PureImaginaryNumbers_ReturnsRealNumber()
        {
            var num1 = new ComplexNumber(0, 6);
            var num2 = new ComplexNumber(0, 2);
            var result = num1.Divide(num2);

            Assert.Equal(3, result.Real);
            Assert.Equal(0, result.Imaginary);
        }

        #endregion

        #region Тесты точности вычислений

        [Fact]
        public void Multiply_ThenDivide_ReturnsOriginalNumber()
        {
            var num1 = new ComplexNumber(3, 4);
            var num2 = new ComplexNumber(5, 6);

            var multiplied = num1.Multiply(num2);
            var result = multiplied.Divide(num2);

            Assert.Equal(num1.Real, result.Real, 10);
            Assert.Equal(num1.Imaginary, result.Imaginary, 10);
        }

        [Fact]
        public void Add_ThenSubtract_ReturnsOriginalNumber()
        {
            var num1 = new ComplexNumber(3, 4);
            var num2 = new ComplexNumber(5, 6);

            var added = num1.Add(num2);
            var result = added.Subtract(num2);

            Assert.Equal(num1.Real, result.Real, 10);
            Assert.Equal(num1.Imaginary, result.Imaginary, 10);
        }

        [Fact]
        public void Modulus_AfterOperations_MaintainsPrecision()
        {
            var num = new ComplexNumber(3, 4);
            var doubled = num.Multiply(new ComplexNumber(2, 0));
            var halved = doubled.Divide(new ComplexNumber(2, 0));

            Assert.Equal(num.Modulus(), halved.Modulus(), 10);
        }

        #endregion

        #region Тесты сравнения

        [Fact]
        public void IsEqual_WithVeryCloseModuli_ReturnsTrue()
        {
            var num1 = new ComplexNumber(3, 4);
            var num2 = new ComplexNumber(3.0000001, 4);

            Assert.True(num1.IsEqual(num2));
        }

        [Fact]
        public void IsEqual_SameNumber_ReturnsTrue()
        {
            var num = new ComplexNumber(3, 4);

            Assert.True(num.IsEqual(num));
        }

        [Fact]
        public void IsGreaterThan_WithEqualModuli_ReturnsFalse()
        {
            var num1 = new ComplexNumber(3, 4);
            var num2 = new ComplexNumber(0, 5);

            Assert.False(num1.IsGreaterThan(num2));
        }

        #endregion

        #region Тесты операторов

        [Fact]
        public void Operators_ChainedOperations_WorkCorrectly()
        {
            var a = new ComplexNumber(1, 2);
            var b = new ComplexNumber(3, 4);
            var c = new ComplexNumber(5, 6);

            // (1+2i) + (3+4i) = (4+6i)
            // (4+6i) * (5+6i) = (20+30i) + (24i+36i²) = (20+30i) + (24i-36) = (-16+54i)
            var result = (a + b) * c;

            Assert.Equal(-16, result.Real);
            Assert.Equal(54, result.Imaginary);
        }

        [Fact]
        public void Operators_ComplexExpression_WorkCorrectly()
        {
            var a = new ComplexNumber(2, 3);
            var b = new ComplexNumber(4, 5);
            var c = new ComplexNumber(1, 1);

            // (2+3i) * (4+5i) = (8+15i²) + (10i+12i) = (8-15) + 22i = (-7+22i)
            // (-7+22i) / (1+1i) = ((-7+22i)(1-i)) / (1²+1²) = ((-7+7i)+(22i-22i²)) / 2
            //                   = (-7+7i+22i+22) / 2 = (15+29i) / 2 = (7.5+14.5i)
            var result = (a * b) / c;

            Assert.Equal(7.5, result.Real, 10);
            Assert.Equal(14.5, result.Imaginary, 10);
        }

        #endregion
    }
}
